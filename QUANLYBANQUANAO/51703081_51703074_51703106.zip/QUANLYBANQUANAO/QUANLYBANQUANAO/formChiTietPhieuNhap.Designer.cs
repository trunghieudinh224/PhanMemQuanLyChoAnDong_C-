﻿namespace QUANLYBANQUANAO
{
    partial class formChiTietPhieuNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formChiTietPhieuNhap));
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.panelPhai = new System.Windows.Forms.Panel();
            this.panelDuoi = new System.Windows.Forms.Panel();
            this.panelTrai = new System.Windows.Forms.Panel();
            this.labelMaNCC = new System.Windows.Forms.Label();
            this.labelNgayNhap = new System.Windows.Forms.Label();
            this.labelDiaChiNCC = new System.Windows.Forms.Label();
            this.labelSDTNCC = new System.Windows.Forms.Label();
            this.labelNCC = new System.Windows.Forms.Label();
            this.labelMaPhieu = new System.Windows.Forms.Label();
            this.listViewDSHN = new System.Windows.Forms.ListView();
            this.columnHeaderTenSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDanhMuc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelDiaChiNCC_Text = new System.Windows.Forms.Label();
            this.labelSDTNCC_Text = new System.Windows.Forms.Label();
            this.labelMaNCC_Text = new System.Windows.Forms.Label();
            this.labelMaPhieu_Text = new System.Windows.Forms.Label();
            this.labelNCC_Text = new System.Windows.Forms.Label();
            this.labelNgay_Text = new System.Windows.Forms.Label();
            this.buttonInPhieu = new System.Windows.Forms.Button();
            this.labelNVLapPhieu_Text = new System.Windows.Forms.Label();
            this.labelNVNhapHang_Text = new System.Windows.Forms.Label();
            this.labelTongPhieu_Text = new System.Windows.Forms.Label();
            this.labelTongPhieu = new System.Windows.Forms.Label();
            this.labelNVLapPhieu = new System.Windows.Forms.Label();
            this.labelNVNhanHang = new System.Windows.Forms.Label();
            this.dataGridViewDSPN = new System.Windows.Forms.DataGridView();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSPN)).BeginInit();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(654, 35);
            this.panelThanhTieuDe.TabIndex = 17;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(540, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 95;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(599, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 94;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 93;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(223, 23);
            this.labelTieuDeForm.TabIndex = 92;
            this.labelTieuDeForm.Text = "CHI TIẾT PHIẾU NHẬP";
            // 
            // panelPhai
            // 
            this.panelPhai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelPhai.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelPhai.Location = new System.Drawing.Point(648, 35);
            this.panelPhai.Name = "panelPhai";
            this.panelPhai.Size = new System.Drawing.Size(6, 619);
            this.panelPhai.TabIndex = 89;
            // 
            // panelDuoi
            // 
            this.panelDuoi.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDuoi.Location = new System.Drawing.Point(6, 654);
            this.panelDuoi.Name = "panelDuoi";
            this.panelDuoi.Size = new System.Drawing.Size(648, 6);
            this.panelDuoi.TabIndex = 88;
            // 
            // panelTrai
            // 
            this.panelTrai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelTrai.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTrai.Location = new System.Drawing.Point(0, 35);
            this.panelTrai.Name = "panelTrai";
            this.panelTrai.Size = new System.Drawing.Size(6, 625);
            this.panelTrai.TabIndex = 87;
            // 
            // labelMaNCC
            // 
            this.labelMaNCC.AutoSize = true;
            this.labelMaNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaNCC.Location = new System.Drawing.Point(395, 215);
            this.labelMaNCC.Name = "labelMaNCC";
            this.labelMaNCC.Size = new System.Drawing.Size(112, 26);
            this.labelMaNCC.TabIndex = 98;
            this.labelMaNCC.Text = "Mã NCC:";
            // 
            // labelNgayNhap
            // 
            this.labelNgayNhap.AutoSize = true;
            this.labelNgayNhap.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgayNhap.Location = new System.Drawing.Point(12, 40);
            this.labelNgayNhap.Name = "labelNgayNhap";
            this.labelNgayNhap.Size = new System.Drawing.Size(73, 26);
            this.labelNgayNhap.TabIndex = 95;
            this.labelNgayNhap.Text = "Ngày:";
            // 
            // labelDiaChiNCC
            // 
            this.labelDiaChiNCC.AutoSize = true;
            this.labelDiaChiNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiNCC.Location = new System.Drawing.Point(12, 250);
            this.labelDiaChiNCC.Name = "labelDiaChiNCC";
            this.labelDiaChiNCC.Size = new System.Drawing.Size(150, 26);
            this.labelDiaChiNCC.TabIndex = 93;
            this.labelDiaChiNCC.Text = "Địa chỉ NCC:";
            // 
            // labelSDTNCC
            // 
            this.labelSDTNCC.AutoSize = true;
            this.labelSDTNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDTNCC.Location = new System.Drawing.Point(12, 215);
            this.labelSDTNCC.Name = "labelSDTNCC";
            this.labelSDTNCC.Size = new System.Drawing.Size(122, 26);
            this.labelSDTNCC.TabIndex = 92;
            this.labelSDTNCC.Text = "SĐT NCC:";
            // 
            // labelNCC
            // 
            this.labelNCC.AutoSize = true;
            this.labelNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNCC.Location = new System.Drawing.Point(12, 180);
            this.labelNCC.Name = "labelNCC";
            this.labelNCC.Size = new System.Drawing.Size(159, 26);
            this.labelNCC.TabIndex = 91;
            this.labelNCC.Text = "Nhà cung cấp:";
            // 
            // labelMaPhieu
            // 
            this.labelMaPhieu.AutoSize = true;
            this.labelMaPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaPhieu.Location = new System.Drawing.Point(395, 40);
            this.labelMaPhieu.Name = "labelMaPhieu";
            this.labelMaPhieu.Size = new System.Drawing.Size(118, 26);
            this.labelMaPhieu.TabIndex = 90;
            this.labelMaPhieu.Text = "Mã phiếu:";
            // 
            // listViewDSHN
            // 
            this.listViewDSHN.AllowDrop = true;
            this.listViewDSHN.BackColor = System.Drawing.Color.DarkKhaki;
            this.listViewDSHN.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTenSP,
            this.columnHeaderDanhMuc,
            this.columnHeaderSoLuong,
            this.columnHeaderDonGia});
            this.listViewDSHN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewDSHN.HideSelection = false;
            this.listViewDSHN.Location = new System.Drawing.Point(9, 349);
            this.listViewDSHN.MultiSelect = false;
            this.listViewDSHN.Name = "listViewDSHN";
            this.listViewDSHN.Size = new System.Drawing.Size(634, 302);
            this.listViewDSHN.TabIndex = 99;
            this.listViewDSHN.UseCompatibleStateImageBehavior = false;
            this.listViewDSHN.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderTenSP
            // 
            this.columnHeaderTenSP.Text = "Tên sản phẩm";
            this.columnHeaderTenSP.Width = 200;
            // 
            // columnHeaderDanhMuc
            // 
            this.columnHeaderDanhMuc.Text = "Danh mục";
            this.columnHeaderDanhMuc.Width = 90;
            // 
            // columnHeaderSoLuong
            // 
            this.columnHeaderSoLuong.Text = "Số lượng";
            this.columnHeaderSoLuong.Width = 85;
            // 
            // columnHeaderDonGia
            // 
            this.columnHeaderDonGia.Text = "Đơn giá";
            this.columnHeaderDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderDonGia.Width = 96;
            // 
            // labelDiaChiNCC_Text
            // 
            this.labelDiaChiNCC_Text.AutoSize = true;
            this.labelDiaChiNCC_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiNCC_Text.Location = new System.Drawing.Point(160, 250);
            this.labelDiaChiNCC_Text.MaximumSize = new System.Drawing.Size(483, 54);
            this.labelDiaChiNCC_Text.MinimumSize = new System.Drawing.Size(483, 54);
            this.labelDiaChiNCC_Text.Name = "labelDiaChiNCC_Text";
            this.labelDiaChiNCC_Text.Size = new System.Drawing.Size(483, 54);
            this.labelDiaChiNCC_Text.TabIndex = 100;
            this.labelDiaChiNCC_Text.Text = "........";
            // 
            // labelSDTNCC_Text
            // 
            this.labelSDTNCC_Text.AutoSize = true;
            this.labelSDTNCC_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDTNCC_Text.Location = new System.Drawing.Point(132, 215);
            this.labelSDTNCC_Text.Name = "labelSDTNCC_Text";
            this.labelSDTNCC_Text.Size = new System.Drawing.Size(60, 25);
            this.labelSDTNCC_Text.TabIndex = 102;
            this.labelSDTNCC_Text.Text = "........";
            // 
            // labelMaNCC_Text
            // 
            this.labelMaNCC_Text.AutoSize = true;
            this.labelMaNCC_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaNCC_Text.Location = new System.Drawing.Point(508, 215);
            this.labelMaNCC_Text.Name = "labelMaNCC_Text";
            this.labelMaNCC_Text.Size = new System.Drawing.Size(60, 25);
            this.labelMaNCC_Text.TabIndex = 103;
            this.labelMaNCC_Text.Text = "........";
            // 
            // labelMaPhieu_Text
            // 
            this.labelMaPhieu_Text.AutoSize = true;
            this.labelMaPhieu_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaPhieu_Text.Location = new System.Drawing.Point(510, 40);
            this.labelMaPhieu_Text.Name = "labelMaPhieu_Text";
            this.labelMaPhieu_Text.Size = new System.Drawing.Size(60, 25);
            this.labelMaPhieu_Text.TabIndex = 104;
            this.labelMaPhieu_Text.Text = "........";
            // 
            // labelNCC_Text
            // 
            this.labelNCC_Text.AutoSize = true;
            this.labelNCC_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNCC_Text.Location = new System.Drawing.Point(177, 180);
            this.labelNCC_Text.Name = "labelNCC_Text";
            this.labelNCC_Text.Size = new System.Drawing.Size(60, 25);
            this.labelNCC_Text.TabIndex = 105;
            this.labelNCC_Text.Text = "........";
            // 
            // labelNgay_Text
            // 
            this.labelNgay_Text.AutoSize = true;
            this.labelNgay_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay_Text.Location = new System.Drawing.Point(91, 40);
            this.labelNgay_Text.Name = "labelNgay_Text";
            this.labelNgay_Text.Size = new System.Drawing.Size(60, 25);
            this.labelNgay_Text.TabIndex = 106;
            this.labelNgay_Text.Text = "........";
            // 
            // buttonInPhieu
            // 
            this.buttonInPhieu.BackColor = System.Drawing.Color.Red;
            this.buttonInPhieu.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonInPhieu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonInPhieu.Location = new System.Drawing.Point(503, 310);
            this.buttonInPhieu.Name = "buttonInPhieu";
            this.buttonInPhieu.Size = new System.Drawing.Size(143, 38);
            this.buttonInPhieu.TabIndex = 109;
            this.buttonInPhieu.Text = "In phiếu";
            this.buttonInPhieu.UseVisualStyleBackColor = false;
            this.buttonInPhieu.Click += new System.EventHandler(this.buttonInPhieu_Click);
            // 
            // labelNVLapPhieu_Text
            // 
            this.labelNVLapPhieu_Text.AutoSize = true;
            this.labelNVLapPhieu_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVLapPhieu_Text.Location = new System.Drawing.Point(166, 145);
            this.labelNVLapPhieu_Text.Name = "labelNVLapPhieu_Text";
            this.labelNVLapPhieu_Text.Size = new System.Drawing.Size(60, 25);
            this.labelNVLapPhieu_Text.TabIndex = 115;
            this.labelNVLapPhieu_Text.Text = "........";
            // 
            // labelNVNhapHang_Text
            // 
            this.labelNVNhapHang_Text.AutoSize = true;
            this.labelNVNhapHang_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVNhapHang_Text.Location = new System.Drawing.Point(179, 110);
            this.labelNVNhapHang_Text.Name = "labelNVNhapHang_Text";
            this.labelNVNhapHang_Text.Size = new System.Drawing.Size(60, 25);
            this.labelNVNhapHang_Text.TabIndex = 113;
            this.labelNVNhapHang_Text.Text = "........";
            // 
            // labelTongPhieu_Text
            // 
            this.labelTongPhieu_Text.AutoSize = true;
            this.labelTongPhieu_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongPhieu_Text.Location = new System.Drawing.Point(147, 75);
            this.labelTongPhieu_Text.Name = "labelTongPhieu_Text";
            this.labelTongPhieu_Text.Size = new System.Drawing.Size(60, 25);
            this.labelTongPhieu_Text.TabIndex = 114;
            this.labelTongPhieu_Text.Text = "........";
            // 
            // labelTongPhieu
            // 
            this.labelTongPhieu.AutoSize = true;
            this.labelTongPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongPhieu.Location = new System.Drawing.Point(12, 75);
            this.labelTongPhieu.Name = "labelTongPhieu";
            this.labelTongPhieu.Size = new System.Drawing.Size(135, 26);
            this.labelTongPhieu.TabIndex = 111;
            this.labelTongPhieu.Text = "Tổng phiếu:";
            // 
            // labelNVLapPhieu
            // 
            this.labelNVLapPhieu.AutoSize = true;
            this.labelNVLapPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVLapPhieu.Location = new System.Drawing.Point(12, 145);
            this.labelNVLapPhieu.Name = "labelNVLapPhieu";
            this.labelNVLapPhieu.Size = new System.Drawing.Size(155, 26);
            this.labelNVLapPhieu.TabIndex = 112;
            this.labelNVLapPhieu.Text = "NV lập phiếu:";
            // 
            // labelNVNhanHang
            // 
            this.labelNVNhanHang.AutoSize = true;
            this.labelNVNhanHang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVNhanHang.Location = new System.Drawing.Point(12, 110);
            this.labelNVNhanHang.Name = "labelNVNhanHang";
            this.labelNVNhanHang.Size = new System.Drawing.Size(167, 26);
            this.labelNVNhanHang.TabIndex = 110;
            this.labelNVNhanHang.Text = "NV nhận hàng:";
            // 
            // dataGridViewDSPN
            // 
            this.dataGridViewDSPN.AllowDrop = true;
            this.dataGridViewDSPN.AllowUserToAddRows = false;
            this.dataGridViewDSPN.AllowUserToDeleteRows = false;
            this.dataGridViewDSPN.AllowUserToResizeColumns = false;
            this.dataGridViewDSPN.AllowUserToResizeRows = false;
            this.dataGridViewDSPN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSPN.Location = new System.Drawing.Point(210, 462);
            this.dataGridViewDSPN.MultiSelect = false;
            this.dataGridViewDSPN.Name = "dataGridViewDSPN";
            this.dataGridViewDSPN.ReadOnly = true;
            this.dataGridViewDSPN.RowHeadersVisible = false;
            this.dataGridViewDSPN.RowHeadersWidth = 51;
            this.dataGridViewDSPN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewDSPN.RowTemplate.Height = 24;
            this.dataGridViewDSPN.Size = new System.Drawing.Size(240, 150);
            this.dataGridViewDSPN.TabIndex = 116;
            this.dataGridViewDSPN.Visible = false;
            // 
            // formChiTietPhieuNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(654, 660);
            this.Controls.Add(this.labelNVLapPhieu_Text);
            this.Controls.Add(this.labelNVNhapHang_Text);
            this.Controls.Add(this.labelTongPhieu_Text);
            this.Controls.Add(this.labelTongPhieu);
            this.Controls.Add(this.labelNVLapPhieu);
            this.Controls.Add(this.labelNVNhanHang);
            this.Controls.Add(this.buttonInPhieu);
            this.Controls.Add(this.labelNgay_Text);
            this.Controls.Add(this.labelNCC_Text);
            this.Controls.Add(this.labelMaNCC_Text);
            this.Controls.Add(this.labelMaPhieu_Text);
            this.Controls.Add(this.labelSDTNCC_Text);
            this.Controls.Add(this.labelDiaChiNCC_Text);
            this.Controls.Add(this.listViewDSHN);
            this.Controls.Add(this.labelMaNCC);
            this.Controls.Add(this.labelNgayNhap);
            this.Controls.Add(this.labelDiaChiNCC);
            this.Controls.Add(this.labelSDTNCC);
            this.Controls.Add(this.labelNCC);
            this.Controls.Add(this.labelMaPhieu);
            this.Controls.Add(this.panelPhai);
            this.Controls.Add(this.panelDuoi);
            this.Controls.Add(this.panelTrai);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.dataGridViewDSPN);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formChiTietPhieuNhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formChiTietPhieuNhap";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSPN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Panel panelPhai;
        private System.Windows.Forms.Panel panelDuoi;
        private System.Windows.Forms.Panel panelTrai;
        private System.Windows.Forms.Label labelMaNCC;
        private System.Windows.Forms.Label labelNgayNhap;
        private System.Windows.Forms.Label labelDiaChiNCC;
        private System.Windows.Forms.Label labelSDTNCC;
        private System.Windows.Forms.Label labelNCC;
        private System.Windows.Forms.Label labelMaPhieu;
        private System.Windows.Forms.ListView listViewDSHN;
        private System.Windows.Forms.Label labelDiaChiNCC_Text;
        private System.Windows.Forms.Label labelSDTNCC_Text;
        private System.Windows.Forms.Label labelMaNCC_Text;
        private System.Windows.Forms.Label labelMaPhieu_Text;
        private System.Windows.Forms.Label labelNCC_Text;
        private System.Windows.Forms.Label labelNgay_Text;
        private System.Windows.Forms.ColumnHeader columnHeaderTenSP;
        private System.Windows.Forms.ColumnHeader columnHeaderDanhMuc;
        private System.Windows.Forms.ColumnHeader columnHeaderSoLuong;
        private System.Windows.Forms.ColumnHeader columnHeaderDonGia;
        private System.Windows.Forms.Button buttonInPhieu;
        private System.Windows.Forms.Label labelNVLapPhieu_Text;
        private System.Windows.Forms.Label labelNVNhapHang_Text;
        private System.Windows.Forms.Label labelTongPhieu_Text;
        private System.Windows.Forms.Label labelTongPhieu;
        private System.Windows.Forms.Label labelNVLapPhieu;
        private System.Windows.Forms.Label labelNVNhanHang;
        private System.Windows.Forms.DataGridView dataGridViewDSPN;
    }
}