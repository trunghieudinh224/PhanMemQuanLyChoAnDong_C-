﻿namespace QUANLYBANQUANAO
{
    partial class formChiTietToaHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formChiTietToaHang));
            this.labelNgay_Text = new System.Windows.Forms.Label();
            this.labelNgay = new System.Windows.Forms.Label();
            this.labelGiamGia = new System.Windows.Forms.Label();
            this.labelSDT_Text = new System.Windows.Forms.Label();
            this.labelSDT = new System.Windows.Forms.Label();
            this.labelTenKhach_Text = new System.Windows.Forms.Label();
            this.labelTenKhach = new System.Windows.Forms.Label();
            this.labelKhachNo_Text = new System.Windows.Forms.Label();
            this.labelThanhToan_Text = new System.Windows.Forms.Label();
            this.labelGiamGia_Text = new System.Windows.Forms.Label();
            this.labelNhanVienLapToa_Text = new System.Windows.Forms.Label();
            this.labelTongToaHang_Text = new System.Windows.Forms.Label();
            this.labelThanhToan = new System.Windows.Forms.Label();
            this.labelKhachNo = new System.Windows.Forms.Label();
            this.labelNhanVienLapToa = new System.Windows.Forms.Label();
            this.labelTongToaHang = new System.Windows.Forms.Label();
            this.labelTongTra_Text = new System.Windows.Forms.Label();
            this.labelTongMua_Text = new System.Windows.Forms.Label();
            this.labelTongTra = new System.Windows.Forms.Label();
            this.labelTongMua = new System.Windows.Forms.Label();
            this.listViewTraHang = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listViewMuaHang = new System.Windows.Forms.ListView();
            this.columnHeaderTenSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderThanhTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dataGridViewTra = new System.Windows.Forms.DataGridView();
            this.ColumnTenSP_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSL_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DG_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TT_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewMua = new System.Windows.Forms.DataGridView();
            this.ColumnTenSP_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSL_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDonGia_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTT_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonXacNhan = new System.Windows.Forms.Button();
            this.labelIdToa_Text = new System.Windows.Forms.Label();
            this.labelIdToa = new System.Windows.Forms.Label();
            this.buttonIn = new System.Windows.Forms.Button();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.panelDuoi = new System.Windows.Forms.Panel();
            this.panelPhai = new System.Windows.Forms.Panel();
            this.panelTrai = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMua)).BeginInit();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.SuspendLayout();
            // 
            // labelNgay_Text
            // 
            this.labelNgay_Text.AutoSize = true;
            this.labelNgay_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay_Text.Location = new System.Drawing.Point(510, 83);
            this.labelNgay_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.Name = "labelNgay_Text";
            this.labelNgay_Text.Size = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.TabIndex = 127;
            this.labelNgay_Text.Text = "22/04/1999";
            this.labelNgay_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNgay
            // 
            this.labelNgay.AutoSize = true;
            this.labelNgay.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNgay.Location = new System.Drawing.Point(377, 83);
            this.labelNgay.Name = "labelNgay";
            this.labelNgay.Size = new System.Drawing.Size(102, 25);
            this.labelNgay.TabIndex = 126;
            this.labelNgay.Text = "Ngày lập:";
            // 
            // labelGiamGia
            // 
            this.labelGiamGia.AutoSize = true;
            this.labelGiamGia.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiamGia.ForeColor = System.Drawing.Color.DarkRed;
            this.labelGiamGia.Location = new System.Drawing.Point(377, 150);
            this.labelGiamGia.Name = "labelGiamGia";
            this.labelGiamGia.Size = new System.Drawing.Size(105, 25);
            this.labelGiamGia.TabIndex = 111;
            this.labelGiamGia.Text = "Giảm giá:";
            // 
            // labelSDT_Text
            // 
            this.labelSDT_Text.AutoSize = true;
            this.labelSDT_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT_Text.Location = new System.Drawing.Point(510, 115);
            this.labelSDT_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.Name = "labelSDT_Text";
            this.labelSDT_Text.Size = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.TabIndex = 123;
            this.labelSDT_Text.Text = "1234567891";
            this.labelSDT_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSDT
            // 
            this.labelSDT.AutoSize = true;
            this.labelSDT.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSDT.Location = new System.Drawing.Point(377, 115);
            this.labelSDT.Name = "labelSDT";
            this.labelSDT.Size = new System.Drawing.Size(60, 25);
            this.labelSDT.TabIndex = 122;
            this.labelSDT.Text = "SĐT:";
            // 
            // labelTenKhach_Text
            // 
            this.labelTenKhach_Text.AutoSize = true;
            this.labelTenKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhach_Text.Location = new System.Drawing.Point(135, 115);
            this.labelTenKhach_Text.MaximumSize = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.MinimumSize = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.Name = "labelTenKhach_Text";
            this.labelTenKhach_Text.Size = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.TabIndex = 121;
            this.labelTenKhach_Text.Text = "đinh trung hiếu";
            // 
            // labelTenKhach
            // 
            this.labelTenKhach.AutoSize = true;
            this.labelTenKhach.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhach.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTenKhach.Location = new System.Drawing.Point(12, 115);
            this.labelTenKhach.Name = "labelTenKhach";
            this.labelTenKhach.Size = new System.Drawing.Size(119, 25);
            this.labelTenKhach.TabIndex = 120;
            this.labelTenKhach.Text = "Tên khách:";
            // 
            // labelKhachNo_Text
            // 
            this.labelKhachNo_Text.AutoSize = true;
            this.labelKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo_Text.Location = new System.Drawing.Point(130, 185);
            this.labelKhachNo_Text.MaximumSize = new System.Drawing.Size(148, 25);
            this.labelKhachNo_Text.MinimumSize = new System.Drawing.Size(148, 25);
            this.labelKhachNo_Text.Name = "labelKhachNo_Text";
            this.labelKhachNo_Text.Size = new System.Drawing.Size(148, 25);
            this.labelKhachNo_Text.TabIndex = 119;
            this.labelKhachNo_Text.Text = "0 VND";
            // 
            // labelThanhToan_Text
            // 
            this.labelThanhToan_Text.AutoSize = true;
            this.labelThanhToan_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThanhToan_Text.Location = new System.Drawing.Point(518, 185);
            this.labelThanhToan_Text.MaximumSize = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.MinimumSize = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.Name = "labelThanhToan_Text";
            this.labelThanhToan_Text.Size = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.TabIndex = 118;
            this.labelThanhToan_Text.Text = "Credit Card";
            this.labelThanhToan_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelGiamGia_Text
            // 
            this.labelGiamGia_Text.AutoSize = true;
            this.labelGiamGia_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiamGia_Text.Location = new System.Drawing.Point(511, 150);
            this.labelGiamGia_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelGiamGia_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelGiamGia_Text.Name = "labelGiamGia_Text";
            this.labelGiamGia_Text.Size = new System.Drawing.Size(138, 25);
            this.labelGiamGia_Text.TabIndex = 117;
            this.labelGiamGia_Text.Text = "100000 ";
            this.labelGiamGia_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNhanVienLapToa_Text
            // 
            this.labelNhanVienLapToa_Text.AutoSize = true;
            this.labelNhanVienLapToa_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienLapToa_Text.Location = new System.Drawing.Point(170, 83);
            this.labelNhanVienLapToa_Text.Name = "labelNhanVienLapToa_Text";
            this.labelNhanVienLapToa_Text.Size = new System.Drawing.Size(127, 25);
            this.labelNhanVienLapToa_Text.TabIndex = 115;
            this.labelNhanVienLapToa_Text.Text = "tên nhân viên";
            // 
            // labelTongToaHang_Text
            // 
            this.labelTongToaHang_Text.AutoSize = true;
            this.labelTongToaHang_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaHang_Text.Location = new System.Drawing.Point(173, 150);
            this.labelTongToaHang_Text.MaximumSize = new System.Drawing.Size(160, 25);
            this.labelTongToaHang_Text.MinimumSize = new System.Drawing.Size(160, 25);
            this.labelTongToaHang_Text.Name = "labelTongToaHang_Text";
            this.labelTongToaHang_Text.Size = new System.Drawing.Size(160, 25);
            this.labelTongToaHang_Text.TabIndex = 116;
            this.labelTongToaHang_Text.Text = "1000000000 ";
            // 
            // labelThanhToan
            // 
            this.labelThanhToan.AutoSize = true;
            this.labelThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThanhToan.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThanhToan.Location = new System.Drawing.Point(377, 185);
            this.labelThanhToan.Name = "labelThanhToan";
            this.labelThanhToan.Size = new System.Drawing.Size(128, 25);
            this.labelThanhToan.TabIndex = 114;
            this.labelThanhToan.Text = "Thanh toán:";
            // 
            // labelKhachNo
            // 
            this.labelKhachNo.AutoSize = true;
            this.labelKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo.ForeColor = System.Drawing.Color.DarkRed;
            this.labelKhachNo.Location = new System.Drawing.Point(12, 185);
            this.labelKhachNo.Name = "labelKhachNo";
            this.labelKhachNo.Size = new System.Drawing.Size(112, 25);
            this.labelKhachNo.TabIndex = 113;
            this.labelKhachNo.Text = "Khách nợ:";
            // 
            // labelNhanVienLapToa
            // 
            this.labelNhanVienLapToa.AutoSize = true;
            this.labelNhanVienLapToa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienLapToa.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNhanVienLapToa.Location = new System.Drawing.Point(12, 83);
            this.labelNhanVienLapToa.Name = "labelNhanVienLapToa";
            this.labelNhanVienLapToa.Size = new System.Drawing.Size(157, 25);
            this.labelNhanVienLapToa.TabIndex = 112;
            this.labelNhanVienLapToa.Text = "Nhân viên lập: ";
            // 
            // labelTongToaHang
            // 
            this.labelTongToaHang.AutoSize = true;
            this.labelTongToaHang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaHang.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTongToaHang.Location = new System.Drawing.Point(12, 150);
            this.labelTongToaHang.Name = "labelTongToaHang";
            this.labelTongToaHang.Size = new System.Drawing.Size(155, 25);
            this.labelTongToaHang.TabIndex = 110;
            this.labelTongToaHang.Text = "Tổng toa hàng:";
            // 
            // labelTongTra_Text
            // 
            this.labelTongTra_Text.AutoSize = true;
            this.labelTongTra_Text.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTra_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongTra_Text.Location = new System.Drawing.Point(498, 491);
            this.labelTongTra_Text.MaximumSize = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.MinimumSize = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.Name = "labelTongTra_Text";
            this.labelTongTra_Text.Size = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.TabIndex = 109;
            this.labelTongTra_Text.Text = "1000000000 VND";
            this.labelTongTra_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongMua_Text
            // 
            this.labelTongMua_Text.AutoSize = true;
            this.labelTongMua_Text.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongMua_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongMua_Text.Location = new System.Drawing.Point(498, 223);
            this.labelTongMua_Text.MaximumSize = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.MinimumSize = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.Name = "labelTongMua_Text";
            this.labelTongMua_Text.Size = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.TabIndex = 108;
            this.labelTongMua_Text.Text = "1000000000 VND";
            this.labelTongMua_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongTra
            // 
            this.labelTongTra.AutoSize = true;
            this.labelTongTra.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTra.ForeColor = System.Drawing.Color.Black;
            this.labelTongTra.Location = new System.Drawing.Point(377, 489);
            this.labelTongTra.Name = "labelTongTra";
            this.labelTongTra.Size = new System.Drawing.Size(101, 25);
            this.labelTongTra.TabIndex = 107;
            this.labelTongTra.Text = "Tổng trả:";
            // 
            // labelTongMua
            // 
            this.labelTongMua.AutoSize = true;
            this.labelTongMua.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongMua.ForeColor = System.Drawing.Color.Black;
            this.labelTongMua.Location = new System.Drawing.Point(377, 221);
            this.labelTongMua.Name = "labelTongMua";
            this.labelTongMua.Size = new System.Drawing.Size(115, 25);
            this.labelTongMua.TabIndex = 106;
            this.labelTongMua.Text = "Tổng mua:";
            // 
            // listViewTraHang
            // 
            this.listViewTraHang.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewTraHang.BackColor = System.Drawing.Color.Chocolate;
            this.listViewTraHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewTraHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewTraHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewTraHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewTraHang.HideSelection = false;
            this.listViewTraHang.HoverSelection = true;
            this.listViewTraHang.Location = new System.Drawing.Point(18, 517);
            this.listViewTraHang.MultiSelect = false;
            this.listViewTraHang.Name = "listViewTraHang";
            this.listViewTraHang.Size = new System.Drawing.Size(632, 200);
            this.listViewTraHang.TabIndex = 105;
            this.listViewTraHang.UseCompatibleStateImageBehavior = false;
            this.listViewTraHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Tên sản phẩm";
            this.columnHeader1.Width = 199;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "SL";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 50;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Đơn giá";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Thành tiền";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 100;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(13, 489);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 25);
            this.label6.TabIndex = 104;
            this.label6.Text = "TRẢ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(13, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 25);
            this.label1.TabIndex = 103;
            this.label1.Text = "MUA";
            // 
            // listViewMuaHang
            // 
            this.listViewMuaHang.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewMuaHang.BackColor = System.Drawing.Color.Khaki;
            this.listViewMuaHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewMuaHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTenSP,
            this.columnHeaderSoLuong,
            this.columnHeaderDonGia,
            this.columnHeaderThanhTien});
            this.listViewMuaHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewMuaHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewMuaHang.HideSelection = false;
            this.listViewMuaHang.HoverSelection = true;
            this.listViewMuaHang.Location = new System.Drawing.Point(18, 247);
            this.listViewMuaHang.MultiSelect = false;
            this.listViewMuaHang.Name = "listViewMuaHang";
            this.listViewMuaHang.Size = new System.Drawing.Size(632, 231);
            this.listViewMuaHang.TabIndex = 98;
            this.listViewMuaHang.UseCompatibleStateImageBehavior = false;
            this.listViewMuaHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderTenSP
            // 
            this.columnHeaderTenSP.Text = "Tên sản phẩm";
            this.columnHeaderTenSP.Width = 199;
            // 
            // columnHeaderSoLuong
            // 
            this.columnHeaderSoLuong.Text = "SL";
            this.columnHeaderSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSoLuong.Width = 50;
            // 
            // columnHeaderDonGia
            // 
            this.columnHeaderDonGia.Text = "Đơn giá";
            this.columnHeaderDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderDonGia.Width = 100;
            // 
            // columnHeaderThanhTien
            // 
            this.columnHeaderThanhTien.Text = "Thành tiền";
            this.columnHeaderThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderThanhTien.Width = 100;
            // 
            // dataGridViewTra
            // 
            this.dataGridViewTra.AllowDrop = true;
            this.dataGridViewTra.AllowUserToAddRows = false;
            this.dataGridViewTra.AllowUserToDeleteRows = false;
            this.dataGridViewTra.AllowUserToResizeColumns = false;
            this.dataGridViewTra.AllowUserToResizeRows = false;
            this.dataGridViewTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTenSP_Tra,
            this.ColumnSL_Tra,
            this.DG_Tra,
            this.TT_Tra});
            this.dataGridViewTra.Location = new System.Drawing.Point(120, 565);
            this.dataGridViewTra.Name = "dataGridViewTra";
            this.dataGridViewTra.RowHeadersVisible = false;
            this.dataGridViewTra.RowHeadersWidth = 51;
            this.dataGridViewTra.RowTemplate.Height = 24;
            this.dataGridViewTra.Size = new System.Drawing.Size(294, 120);
            this.dataGridViewTra.TabIndex = 125;
            this.dataGridViewTra.Visible = false;
            // 
            // ColumnTenSP_Tra
            // 
            this.ColumnTenSP_Tra.DataPropertyName = "TenSP";
            this.ColumnTenSP_Tra.HeaderText = "Tên sản phẩm";
            this.ColumnTenSP_Tra.MinimumWidth = 6;
            this.ColumnTenSP_Tra.Name = "ColumnTenSP_Tra";
            this.ColumnTenSP_Tra.Width = 125;
            // 
            // ColumnSL_Tra
            // 
            this.ColumnSL_Tra.DataPropertyName = "SoLuong";
            this.ColumnSL_Tra.HeaderText = "Số lượng";
            this.ColumnSL_Tra.MinimumWidth = 6;
            this.ColumnSL_Tra.Name = "ColumnSL_Tra";
            this.ColumnSL_Tra.Width = 125;
            // 
            // DG_Tra
            // 
            this.DG_Tra.DataPropertyName = "GiaBan";
            this.DG_Tra.HeaderText = "Đơn giá";
            this.DG_Tra.MinimumWidth = 6;
            this.DG_Tra.Name = "DG_Tra";
            this.DG_Tra.Width = 125;
            // 
            // TT_Tra
            // 
            this.TT_Tra.DataPropertyName = "ThanhTien";
            this.TT_Tra.HeaderText = "Thành tiền";
            this.TT_Tra.MinimumWidth = 6;
            this.TT_Tra.Name = "TT_Tra";
            this.TT_Tra.Width = 125;
            // 
            // dataGridViewMua
            // 
            this.dataGridViewMua.AllowDrop = true;
            this.dataGridViewMua.AllowUserToAddRows = false;
            this.dataGridViewMua.AllowUserToDeleteRows = false;
            this.dataGridViewMua.AllowUserToResizeColumns = false;
            this.dataGridViewMua.AllowUserToResizeRows = false;
            this.dataGridViewMua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMua.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTenSP_Mua,
            this.ColumnSL_Mua,
            this.ColumnDonGia_Mua,
            this.ColumnTT_Mua});
            this.dataGridViewMua.Location = new System.Drawing.Point(143, 297);
            this.dataGridViewMua.Name = "dataGridViewMua";
            this.dataGridViewMua.RowHeadersVisible = false;
            this.dataGridViewMua.RowHeadersWidth = 51;
            this.dataGridViewMua.RowTemplate.Height = 24;
            this.dataGridViewMua.Size = new System.Drawing.Size(322, 150);
            this.dataGridViewMua.TabIndex = 124;
            this.dataGridViewMua.Visible = false;
            // 
            // ColumnTenSP_Mua
            // 
            this.ColumnTenSP_Mua.DataPropertyName = "TenSP";
            this.ColumnTenSP_Mua.HeaderText = "Tên sản phẩm";
            this.ColumnTenSP_Mua.MinimumWidth = 6;
            this.ColumnTenSP_Mua.Name = "ColumnTenSP_Mua";
            this.ColumnTenSP_Mua.Width = 125;
            // 
            // ColumnSL_Mua
            // 
            this.ColumnSL_Mua.DataPropertyName = "SoLuong";
            this.ColumnSL_Mua.HeaderText = "Số lượng";
            this.ColumnSL_Mua.MinimumWidth = 6;
            this.ColumnSL_Mua.Name = "ColumnSL_Mua";
            this.ColumnSL_Mua.Width = 125;
            // 
            // ColumnDonGia_Mua
            // 
            this.ColumnDonGia_Mua.DataPropertyName = "GiaBan";
            this.ColumnDonGia_Mua.HeaderText = "Đơn giá";
            this.ColumnDonGia_Mua.MinimumWidth = 6;
            this.ColumnDonGia_Mua.Name = "ColumnDonGia_Mua";
            this.ColumnDonGia_Mua.Width = 125;
            // 
            // ColumnTT_Mua
            // 
            this.ColumnTT_Mua.DataPropertyName = "ThanhTien";
            this.ColumnTT_Mua.HeaderText = "Thành tiền";
            this.ColumnTT_Mua.MinimumWidth = 6;
            this.ColumnTT_Mua.Name = "ColumnTT_Mua";
            this.ColumnTT_Mua.Width = 125;
            // 
            // buttonXacNhan
            // 
            this.buttonXacNhan.BackColor = System.Drawing.Color.Red;
            this.buttonXacNhan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXacNhan.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXacNhan.Location = new System.Drawing.Point(508, 717);
            this.buttonXacNhan.Name = "buttonXacNhan";
            this.buttonXacNhan.Size = new System.Drawing.Size(143, 41);
            this.buttonXacNhan.TabIndex = 128;
            this.buttonXacNhan.Text = "Xác nhận";
            this.buttonXacNhan.UseVisualStyleBackColor = false;
            this.buttonXacNhan.Click += new System.EventHandler(this.buttonXacNhan_Click);
            // 
            // labelIdToa_Text
            // 
            this.labelIdToa_Text.AutoSize = true;
            this.labelIdToa_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelIdToa_Text.Location = new System.Drawing.Point(99, 51);
            this.labelIdToa_Text.Name = "labelIdToa_Text";
            this.labelIdToa_Text.Size = new System.Drawing.Size(23, 25);
            this.labelIdToa_Text.TabIndex = 130;
            this.labelIdToa_Text.Text = "1";
            // 
            // labelIdToa
            // 
            this.labelIdToa.AutoSize = true;
            this.labelIdToa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelIdToa.ForeColor = System.Drawing.Color.DarkRed;
            this.labelIdToa.Location = new System.Drawing.Point(12, 51);
            this.labelIdToa.Name = "labelIdToa";
            this.labelIdToa.Size = new System.Drawing.Size(81, 25);
            this.labelIdToa.TabIndex = 129;
            this.labelIdToa.Text = "Id Toa:";
            // 
            // buttonIn
            // 
            this.buttonIn.BackColor = System.Drawing.Color.Red;
            this.buttonIn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonIn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonIn.Location = new System.Drawing.Point(362, 717);
            this.buttonIn.Name = "buttonIn";
            this.buttonIn.Size = new System.Drawing.Size(143, 41);
            this.buttonIn.TabIndex = 131;
            this.buttonIn.Text = "In toa";
            this.buttonIn.UseVisualStyleBackColor = false;
            this.buttonIn.Click += new System.EventHandler(this.buttonIn_Click);
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.label4);
            this.panelThanhTieuDe.Controls.Add(this.pictureBox1);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(665, 35);
            this.panelThanhTieuDe.TabIndex = 132;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(39, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 23);
            this.label4.TabIndex = 138;
            this.label4.Text = "CHI TIẾT TOA HÀNG";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 137;
            this.pictureBox1.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(556, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 134;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(612, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 133;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(-547, 70);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(211, 23);
            this.labelTieuDeForm.TabIndex = 91;
            this.labelTieuDeForm.Text = "QUẢN LÝ TOA HÀNG";
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(-582, 67);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 50;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // panelDuoi
            // 
            this.panelDuoi.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDuoi.Location = new System.Drawing.Point(6, 760);
            this.panelDuoi.Name = "panelDuoi";
            this.panelDuoi.Size = new System.Drawing.Size(653, 6);
            this.panelDuoi.TabIndex = 135;
            // 
            // panelPhai
            // 
            this.panelPhai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelPhai.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelPhai.Location = new System.Drawing.Point(659, 35);
            this.panelPhai.Name = "panelPhai";
            this.panelPhai.Size = new System.Drawing.Size(6, 731);
            this.panelPhai.TabIndex = 134;
            // 
            // panelTrai
            // 
            this.panelTrai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelTrai.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTrai.Location = new System.Drawing.Point(0, 35);
            this.panelTrai.Name = "panelTrai";
            this.panelTrai.Size = new System.Drawing.Size(6, 731);
            this.panelTrai.TabIndex = 133;
            // 
            // formChiTietToaHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(665, 766);
            this.Controls.Add(this.panelDuoi);
            this.Controls.Add(this.panelPhai);
            this.Controls.Add(this.panelTrai);
            this.Controls.Add(this.labelTieuDeForm);
            this.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.Controls.Add(this.buttonIn);
            this.Controls.Add(this.labelIdToa_Text);
            this.Controls.Add(this.labelIdToa);
            this.Controls.Add(this.buttonXacNhan);
            this.Controls.Add(this.labelNgay_Text);
            this.Controls.Add(this.labelNgay);
            this.Controls.Add(this.labelGiamGia);
            this.Controls.Add(this.labelSDT_Text);
            this.Controls.Add(this.labelSDT);
            this.Controls.Add(this.labelTenKhach_Text);
            this.Controls.Add(this.labelTenKhach);
            this.Controls.Add(this.labelKhachNo_Text);
            this.Controls.Add(this.labelThanhToan_Text);
            this.Controls.Add(this.labelGiamGia_Text);
            this.Controls.Add(this.labelNhanVienLapToa_Text);
            this.Controls.Add(this.labelTongToaHang_Text);
            this.Controls.Add(this.labelThanhToan);
            this.Controls.Add(this.labelKhachNo);
            this.Controls.Add(this.labelNhanVienLapToa);
            this.Controls.Add(this.labelTongToaHang);
            this.Controls.Add(this.labelTongTra_Text);
            this.Controls.Add(this.labelTongMua_Text);
            this.Controls.Add(this.labelTongTra);
            this.Controls.Add(this.labelTongMua);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.listViewMuaHang);
            this.Controls.Add(this.listViewTraHang);
            this.Controls.Add(this.dataGridViewMua);
            this.Controls.Add(this.dataGridViewTra);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formChiTietToaHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formChiTietToaHang";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMua)).EndInit();
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelNgay_Text;
        private System.Windows.Forms.Label labelNgay;
        private System.Windows.Forms.Label labelGiamGia;
        private System.Windows.Forms.Label labelSDT_Text;
        private System.Windows.Forms.Label labelSDT;
        private System.Windows.Forms.Label labelTenKhach_Text;
        private System.Windows.Forms.Label labelTenKhach;
        private System.Windows.Forms.Label labelKhachNo_Text;
        private System.Windows.Forms.Label labelThanhToan_Text;
        private System.Windows.Forms.Label labelGiamGia_Text;
        private System.Windows.Forms.Label labelNhanVienLapToa_Text;
        private System.Windows.Forms.Label labelTongToaHang_Text;
        private System.Windows.Forms.Label labelThanhToan;
        private System.Windows.Forms.Label labelKhachNo;
        private System.Windows.Forms.Label labelNhanVienLapToa;
        private System.Windows.Forms.Label labelTongToaHang;
        private System.Windows.Forms.Label labelTongTra_Text;
        private System.Windows.Forms.Label labelTongMua_Text;
        private System.Windows.Forms.Label labelTongTra;
        private System.Windows.Forms.Label labelTongMua;
        private System.Windows.Forms.ListView listViewTraHang;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listViewMuaHang;
        private System.Windows.Forms.ColumnHeader columnHeaderTenSP;
        private System.Windows.Forms.ColumnHeader columnHeaderSoLuong;
        private System.Windows.Forms.ColumnHeader columnHeaderDonGia;
        private System.Windows.Forms.ColumnHeader columnHeaderThanhTien;
        private System.Windows.Forms.DataGridView dataGridViewTra;
        private System.Windows.Forms.DataGridView dataGridViewMua;
        private System.Windows.Forms.Button buttonXacNhan;
        private System.Windows.Forms.Label labelIdToa_Text;
        private System.Windows.Forms.Label labelIdToa;
        private System.Windows.Forms.Button buttonIn;
        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenSP_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSL_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDonGia_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTT_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenSP_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSL_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn DG_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn TT_Tra;
        private System.Windows.Forms.Panel panelDuoi;
        private System.Windows.Forms.Panel panelPhai;
        private System.Windows.Forms.Panel panelTrai;
    }
}