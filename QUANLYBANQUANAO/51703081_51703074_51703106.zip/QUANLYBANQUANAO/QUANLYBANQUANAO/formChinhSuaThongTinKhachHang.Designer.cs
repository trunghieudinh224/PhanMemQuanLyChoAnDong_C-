﻿namespace QUANLYBANQUANAO
{
    partial class formChinhSuaThongTinKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formChinhSuaThongTinKhachHang));
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.panelCapNhat = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.buttonCapNhat = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxSDTThayDoi = new System.Windows.Forms.TextBox();
            this.textBoxDiaChiThayDoi = new System.Windows.Forms.TextBox();
            this.textBoxTenKhachThayDoi = new System.Windows.Forms.TextBox();
            this.textBoxDiaChiHienTai = new System.Windows.Forms.TextBox();
            this.textBoxSDTHienTai = new System.Windows.Forms.TextBox();
            this.textBoxTenHienTai = new System.Windows.Forms.TextBox();
            this.labelDiaChi = new System.Windows.Forms.Label();
            this.labelSDTKH = new System.Windows.Forms.Label();
            this.labelTENKH = new System.Windows.Forms.Label();
            this.pictureBoxCheckCapNhat = new System.Windows.Forms.PictureBox();
            this.panelThem = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonThemMoi = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxSDTMoi = new System.Windows.Forms.TextBox();
            this.textBoxDiaChiMoi = new System.Windows.Forms.TextBox();
            this.textBoxTenMoi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBoxCheckThemMoi = new System.Windows.Forms.PictureBox();
            this.timerCheckCapNhat = new System.Windows.Forms.Timer(this.components);
            this.timerCheckThemMoi = new System.Windows.Forms.Timer(this.components);
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.panelCapNhat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckCapNhat)).BeginInit();
            this.panelThem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckThemMoi)).BeginInit();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            resources.ApplyResources(this.panelThanhTieuDe, "panelThanhTieuDe");
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // labelTieuDeForm
            // 
            resources.ApplyResources(this.labelTieuDeForm, "labelTieuDeForm");
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.buttonAn, "buttonAn");
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.buttonX, "buttonX");
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Name = "buttonX";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.pictureBoxIconThanhTieuDe, "pictureBoxIconThanhTieuDe");
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // panelCapNhat
            // 
            this.panelCapNhat.Controls.Add(this.pictureBox5);
            this.panelCapNhat.Controls.Add(this.pictureBox4);
            this.panelCapNhat.Controls.Add(this.pictureBox3);
            this.panelCapNhat.Controls.Add(this.buttonCapNhat);
            this.panelCapNhat.Controls.Add(this.label3);
            this.panelCapNhat.Controls.Add(this.label2);
            this.panelCapNhat.Controls.Add(this.textBoxSDTThayDoi);
            this.panelCapNhat.Controls.Add(this.textBoxDiaChiThayDoi);
            this.panelCapNhat.Controls.Add(this.textBoxTenKhachThayDoi);
            this.panelCapNhat.Controls.Add(this.textBoxDiaChiHienTai);
            this.panelCapNhat.Controls.Add(this.textBoxSDTHienTai);
            this.panelCapNhat.Controls.Add(this.textBoxTenHienTai);
            this.panelCapNhat.Controls.Add(this.labelDiaChi);
            this.panelCapNhat.Controls.Add(this.labelSDTKH);
            this.panelCapNhat.Controls.Add(this.labelTENKH);
            this.panelCapNhat.Controls.Add(this.pictureBoxCheckCapNhat);
            resources.ApplyResources(this.panelCapNhat, "panelCapNhat");
            this.panelCapNhat.Name = "panelCapNhat";
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // buttonCapNhat
            // 
            this.buttonCapNhat.BackColor = System.Drawing.Color.DarkRed;
            resources.ApplyResources(this.buttonCapNhat, "buttonCapNhat");
            this.buttonCapNhat.FlatAppearance.BorderSize = 0;
            this.buttonCapNhat.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhat.Name = "buttonCapNhat";
            this.buttonCapNhat.UseVisualStyleBackColor = false;
            this.buttonCapNhat.Click += new System.EventHandler(this.buttonCapNhat_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Name = "label2";
            // 
            // textBoxSDTThayDoi
            // 
            resources.ApplyResources(this.textBoxSDTThayDoi, "textBoxSDTThayDoi");
            this.textBoxSDTThayDoi.Name = "textBoxSDTThayDoi";
            // 
            // textBoxDiaChiThayDoi
            // 
            resources.ApplyResources(this.textBoxDiaChiThayDoi, "textBoxDiaChiThayDoi");
            this.textBoxDiaChiThayDoi.Name = "textBoxDiaChiThayDoi";
            // 
            // textBoxTenKhachThayDoi
            // 
            resources.ApplyResources(this.textBoxTenKhachThayDoi, "textBoxTenKhachThayDoi");
            this.textBoxTenKhachThayDoi.Name = "textBoxTenKhachThayDoi";
            // 
            // textBoxDiaChiHienTai
            // 
            this.textBoxDiaChiHienTai.BackColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.textBoxDiaChiHienTai, "textBoxDiaChiHienTai");
            this.textBoxDiaChiHienTai.Name = "textBoxDiaChiHienTai";
            this.textBoxDiaChiHienTai.ReadOnly = true;
            // 
            // textBoxSDTHienTai
            // 
            this.textBoxSDTHienTai.BackColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.textBoxSDTHienTai, "textBoxSDTHienTai");
            this.textBoxSDTHienTai.Name = "textBoxSDTHienTai";
            this.textBoxSDTHienTai.ReadOnly = true;
            // 
            // textBoxTenHienTai
            // 
            this.textBoxTenHienTai.BackColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.textBoxTenHienTai, "textBoxTenHienTai");
            this.textBoxTenHienTai.Name = "textBoxTenHienTai";
            this.textBoxTenHienTai.ReadOnly = true;
            // 
            // labelDiaChi
            // 
            resources.ApplyResources(this.labelDiaChi, "labelDiaChi");
            this.labelDiaChi.ForeColor = System.Drawing.Color.Black;
            this.labelDiaChi.Name = "labelDiaChi";
            // 
            // labelSDTKH
            // 
            resources.ApplyResources(this.labelSDTKH, "labelSDTKH");
            this.labelSDTKH.ForeColor = System.Drawing.Color.Black;
            this.labelSDTKH.Name = "labelSDTKH";
            // 
            // labelTENKH
            // 
            resources.ApplyResources(this.labelTENKH, "labelTENKH");
            this.labelTENKH.ForeColor = System.Drawing.Color.Black;
            this.labelTENKH.Name = "labelTENKH";
            // 
            // pictureBoxCheckCapNhat
            // 
            resources.ApplyResources(this.pictureBoxCheckCapNhat, "pictureBoxCheckCapNhat");
            this.pictureBoxCheckCapNhat.Name = "pictureBoxCheckCapNhat";
            this.pictureBoxCheckCapNhat.TabStop = false;
            // 
            // panelThem
            // 
            this.panelThem.Controls.Add(this.label5);
            this.panelThem.Controls.Add(this.buttonThemMoi);
            this.panelThem.Controls.Add(this.pictureBox1);
            this.panelThem.Controls.Add(this.label6);
            this.panelThem.Controls.Add(this.textBoxSDTMoi);
            this.panelThem.Controls.Add(this.textBoxDiaChiMoi);
            this.panelThem.Controls.Add(this.textBoxTenMoi);
            this.panelThem.Controls.Add(this.label8);
            this.panelThem.Controls.Add(this.label7);
            this.panelThem.Controls.Add(this.label9);
            this.panelThem.Controls.Add(this.label10);
            this.panelThem.Controls.Add(this.pictureBoxCheckThemMoi);
            resources.ApplyResources(this.panelThem, "panelThem");
            this.panelThem.Name = "panelThem";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Name = "label5";
            // 
            // buttonThemMoi
            // 
            this.buttonThemMoi.BackColor = System.Drawing.Color.DarkRed;
            resources.ApplyResources(this.buttonThemMoi, "buttonThemMoi");
            this.buttonThemMoi.FlatAppearance.BorderSize = 0;
            this.buttonThemMoi.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemMoi.Name = "buttonThemMoi";
            this.buttonThemMoi.UseVisualStyleBackColor = false;
            this.buttonThemMoi.Click += new System.EventHandler(this.buttonThemMoi_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Name = "label6";
            // 
            // textBoxSDTMoi
            // 
            resources.ApplyResources(this.textBoxSDTMoi, "textBoxSDTMoi");
            this.textBoxSDTMoi.Name = "textBoxSDTMoi";
            // 
            // textBoxDiaChiMoi
            // 
            resources.ApplyResources(this.textBoxDiaChiMoi, "textBoxDiaChiMoi");
            this.textBoxDiaChiMoi.Name = "textBoxDiaChiMoi";
            // 
            // textBoxTenMoi
            // 
            resources.ApplyResources(this.textBoxTenMoi, "textBoxTenMoi");
            this.textBoxTenMoi.Name = "textBoxTenMoi";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Name = "label7";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Name = "label10";
            // 
            // pictureBoxCheckThemMoi
            // 
            resources.ApplyResources(this.pictureBoxCheckThemMoi, "pictureBoxCheckThemMoi");
            this.pictureBoxCheckThemMoi.Name = "pictureBoxCheckThemMoi";
            this.pictureBoxCheckThemMoi.TabStop = false;
            // 
            // timerCheckCapNhat
            // 
            this.timerCheckCapNhat.Interval = 1500;
            this.timerCheckCapNhat.Tick += new System.EventHandler(this.timerCheckCapNhat_Tick);
            // 
            // timerCheckThemMoi
            // 
            this.timerCheckThemMoi.Interval = 1500;
            this.timerCheckThemMoi.Tick += new System.EventHandler(this.timerCheckThemMoi_Tick);
            // 
            // formChinhSuaThongTinKhachHang
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.Controls.Add(this.panelThem);
            this.Controls.Add(this.panelCapNhat);
            this.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.Controls.Add(this.panelThanhTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formChinhSuaThongTinKhachHang";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.panelCapNhat.ResumeLayout(false);
            this.panelCapNhat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckCapNhat)).EndInit();
            this.panelThem.ResumeLayout(false);
            this.panelThem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckThemMoi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Panel panelCapNhat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxSDTThayDoi;
        private System.Windows.Forms.TextBox textBoxDiaChiThayDoi;
        private System.Windows.Forms.TextBox textBoxTenKhachThayDoi;
        private System.Windows.Forms.TextBox textBoxDiaChiHienTai;
        private System.Windows.Forms.TextBox textBoxSDTHienTai;
        private System.Windows.Forms.TextBox textBoxTenHienTai;
        private System.Windows.Forms.Label labelDiaChi;
        private System.Windows.Forms.Label labelSDTKH;
        private System.Windows.Forms.Label labelTENKH;
        private System.Windows.Forms.Panel panelThem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxSDTMoi;
        private System.Windows.Forms.TextBox textBoxDiaChiMoi;
        private System.Windows.Forms.TextBox textBoxTenMoi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buttonThemMoi;
        private System.Windows.Forms.PictureBox pictureBoxCheckThemMoi;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button buttonCapNhat;
        private System.Windows.Forms.PictureBox pictureBoxCheckCapNhat;
        private System.Windows.Forms.Timer timerCheckCapNhat;
        private System.Windows.Forms.Timer timerCheckThemMoi;
    }
}