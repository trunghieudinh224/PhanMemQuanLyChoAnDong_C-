﻿namespace QUANLYBANQUANAO
{
    partial class formQuanLyDoanhThuBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formQuanLyDoanhThuBanHang));
            this.panelDoanhThuThang = new System.Windows.Forms.Panel();
            this.panelThangMau = new System.Windows.Forms.Panel();
            this.dataGridViewHangTra = new System.Windows.Forms.DataGridView();
            this.panelCotY = new System.Windows.Forms.Panel();
            this.labelSLBieuDoThang = new System.Windows.Forms.Label();
            this.panelCotX = new System.Windows.Forms.Panel();
            this.dataGridViewThang = new System.Windows.Forms.DataGridView();
            this.labelSLsp6T = new System.Windows.Forms.Label();
            this.labelSLsp5T = new System.Windows.Forms.Label();
            this.labelSLsp4T = new System.Windows.Forms.Label();
            this.labelSLsp3T = new System.Windows.Forms.Label();
            this.labelSLsp2T = new System.Windows.Forms.Label();
            this.labelSLsp1T = new System.Windows.Forms.Label();
            this.labelsp5Thang = new System.Windows.Forms.Label();
            this.labelsp6Thang = new System.Windows.Forms.Label();
            this.labelsp3Thang = new System.Windows.Forms.Label();
            this.labelsp4Thang = new System.Windows.Forms.Label();
            this.labelsp1Thang = new System.Windows.Forms.Label();
            this.panelsp4T = new System.Windows.Forms.Panel();
            this.panelsp3T = new System.Windows.Forms.Panel();
            this.panelsp6T = new System.Windows.Forms.Panel();
            this.panelsp2T = new System.Windows.Forms.Panel();
            this.panelsp5T = new System.Windows.Forms.Panel();
            this.panelsp1T = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.labelsp2Thang = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxTongKetThang = new System.Windows.Forms.GroupBox();
            this.dateTimePickerThang = new System.Windows.Forms.DateTimePicker();
            this.labelLaiTuSPBanDuocTrongThang = new System.Windows.Forms.Label();
            this.labelLaiTuSPBanDuocTrongThang_Text = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.labelSLSPDaBanTrongThang = new System.Windows.Forms.Label();
            this.labelSLSPDaBanTrongThang_Text = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.labelTongGiamGiaThang = new System.Windows.Forms.Label();
            this.labelTongGiamGiaThang_Text = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.labelLoiNhuan = new System.Windows.Forms.Label();
            this.labelLoiNhuan_Text = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labelSLSPNhapKhoTrongThang = new System.Windows.Forms.Label();
            this.labelSLSPNhapKhoTrongThang_Text = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.labelTongTienNhapKhoTrongThang = new System.Windows.Forms.Label();
            this.labelTongTienNhapKhoTrongThang_Text = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelSLSPKhachTraThang = new System.Windows.Forms.Label();
            this.labelSLSPKhachTraThang_Text = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelTongLuongNV = new System.Windows.Forms.Label();
            this.labelTongLuongNV_Text = new System.Windows.Forms.Label();
            this.labelSLToaTrongThang = new System.Windows.Forms.Label();
            this.labelThang = new System.Windows.Forms.Label();
            this.labelKhachNoNoKhachTrongThang = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.labelKhachNoNoKhachTrongThang_Text = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.labelTongDoanhThuTrongThang = new System.Windows.Forms.Label();
            this.labelTongDoanhThuTrongThang_Text = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.labelSLToaTrongThang_Text = new System.Windows.Forms.Label();
            this.labelThang12 = new System.Windows.Forms.Label();
            this.labelThang11 = new System.Windows.Forms.Label();
            this.labelThang10 = new System.Windows.Forms.Label();
            this.panelThang12 = new System.Windows.Forms.Panel();
            this.panelThang8 = new System.Windows.Forms.Panel();
            this.labelNgay = new System.Windows.Forms.Label();
            this.panelThang11 = new System.Windows.Forms.Panel();
            this.panelThang4 = new System.Windows.Forms.Panel();
            this.panelThang7 = new System.Windows.Forms.Panel();
            this.panelThang10 = new System.Windows.Forms.Panel();
            this.groupBoxTKSP1 = new System.Windows.Forms.GroupBox();
            this.panelNgay = new System.Windows.Forms.Panel();
            this.labelChuThichTKSP1 = new System.Windows.Forms.Label();
            this.labelsp4 = new System.Windows.Forms.Label();
            this.labelsp3 = new System.Windows.Forms.Label();
            this.labelsp2 = new System.Windows.Forms.Label();
            this.labelsp1 = new System.Windows.Forms.Label();
            this.panelsp4 = new System.Windows.Forms.Panel();
            this.panelsp3 = new System.Windows.Forms.Panel();
            this.panelsp2 = new System.Windows.Forms.Panel();
            this.panelsp1 = new System.Windows.Forms.Panel();
            this.labelSLsp4 = new System.Windows.Forms.Label();
            this.labelSLsp3 = new System.Windows.Forms.Label();
            this.labelSLsp2 = new System.Windows.Forms.Label();
            this.labelSLsp1 = new System.Windows.Forms.Label();
            this.labelNoKhach = new System.Windows.Forms.Label();
            this.labelNoKhach_Text = new System.Windows.Forms.Label();
            this.labelKhachNo = new System.Windows.Forms.Label();
            this.labelKhachNo_Text = new System.Windows.Forms.Label();
            this.labelTongGiamGia = new System.Windows.Forms.Label();
            this.labelTongGiamGia_Text = new System.Windows.Forms.Label();
            this.labelTongDoanhThu = new System.Windows.Forms.Label();
            this.labelTongDoanhThu_Text = new System.Windows.Forms.Label();
            this.labelSLToa = new System.Windows.Forms.Label();
            this.labelSLToa_Text = new System.Windows.Forms.Label();
            this.labelDSTTN = new System.Windows.Forms.Label();
            this.panelThang9 = new System.Windows.Forms.Panel();
            this.labelTongTienNhapKho = new System.Windows.Forms.Label();
            this.labelTongTienNhapKho_Text = new System.Windows.Forms.Label();
            this.panelThang3 = new System.Windows.Forms.Panel();
            this.panelThang6 = new System.Windows.Forms.Panel();
            this.labelSLSPDaBan = new System.Windows.Forms.Label();
            this.labelSLSPDaBan_Text = new System.Windows.Forms.Label();
            this.labelLaiTuSPBanDuoc = new System.Windows.Forms.Label();
            this.labelLaiTuSPBanDuoc_Text = new System.Windows.Forms.Label();
            this.panelThang2 = new System.Windows.Forms.Panel();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.panelThang5 = new System.Windows.Forms.Panel();
            this.panelThang1 = new System.Windows.Forms.Panel();
            this.labelDTThang12 = new System.Windows.Forms.Label();
            this.labelDTThang11 = new System.Windows.Forms.Label();
            this.labelDTThang10 = new System.Windows.Forms.Label();
            this.labelDTThang9 = new System.Windows.Forms.Label();
            this.labelDTThang8 = new System.Windows.Forms.Label();
            this.labelDTThang7 = new System.Windows.Forms.Label();
            this.labelDTThang6 = new System.Windows.Forms.Label();
            this.labelDTThang5 = new System.Windows.Forms.Label();
            this.labelDTThang4 = new System.Windows.Forms.Label();
            this.labelDTThang3 = new System.Windows.Forms.Label();
            this.labelSLSPKhachTra = new System.Windows.Forms.Label();
            this.labelSLSPKhachTra_Text = new System.Windows.Forms.Label();
            this.labelDTThang2 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelThang7 = new System.Windows.Forms.Label();
            this.labelDTThang1 = new System.Windows.Forms.Label();
            this.dataGridViewDSTTN = new System.Windows.Forms.DataGridView();
            this.TenKhachHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongToa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TienGiamGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelThang8 = new System.Windows.Forms.Label();
            this.labelThang1 = new System.Windows.Forms.Label();
            this.dataGridViewTKSP1 = new System.Windows.Forms.DataGridView();
            this.labelThang3 = new System.Windows.Forms.Label();
            this.labelThang2 = new System.Windows.Forms.Label();
            this.dataGridViewSL = new System.Windows.Forms.DataGridView();
            this.dateTimePickerNgay1 = new System.Windows.Forms.DateTimePicker();
            this.labelTongKetNgay = new System.Windows.Forms.Label();
            this.labelSLSPNhapKho = new System.Windows.Forms.Label();
            this.labelSLSPNhapKho_Text = new System.Windows.Forms.Label();
            this.labelThang9 = new System.Windows.Forms.Label();
            this.labelThang6 = new System.Windows.Forms.Label();
            this.labelThang5 = new System.Windows.Forms.Label();
            this.labelThang4 = new System.Windows.Forms.Label();
            this.labelSLSPDaBanNam = new System.Windows.Forms.Label();
            this.groupBoxBanHang = new System.Windows.Forms.GroupBox();
            this.labelLoiNhuanBHNam = new System.Windows.Forms.Label();
            this.labelLoiNhuanBHNam_Text = new System.Windows.Forms.Label();
            this.labelSLSPTra = new System.Windows.Forms.Label();
            this.labelSLSPTra_Text = new System.Windows.Forms.Label();
            this.labelSLSPDaBanNam_Text = new System.Windows.Forms.Label();
            this.groupBoxNhapKhoLuong = new System.Windows.Forms.GroupBox();
            this.labelLuongNV = new System.Windows.Forms.Label();
            this.labelLuongNV_Text = new System.Windows.Forms.Label();
            this.labelTienNhapKhoNam = new System.Windows.Forms.Label();
            this.labelTienNhapKhoNam_Text = new System.Windows.Forms.Label();
            this.labelSLSPNhapNam = new System.Windows.Forms.Label();
            this.labelSLSPNhapNam_Text = new System.Windows.Forms.Label();
            this.labelNoKhachNam = new System.Windows.Forms.Label();
            this.labelNoKhachNam_Text = new System.Windows.Forms.Label();
            this.labelKhachNoNam = new System.Windows.Forms.Label();
            this.groupBoxLuong = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.labelTongDTNam = new System.Windows.Forms.Label();
            this.labelTongLoiNhuanCaNam = new System.Windows.Forms.Label();
            this.labelTongGiamGiaNam = new System.Windows.Forms.Label();
            this.labelTongGiamGiaNam_Text = new System.Windows.Forms.Label();
            this.labelTongDTNam_Text = new System.Windows.Forms.Label();
            this.labelKhachNoNam_Text = new System.Windows.Forms.Label();
            this.groupBoxTKNam = new System.Windows.Forms.GroupBox();
            this.panelNam = new System.Windows.Forms.Panel();
            this.dateTimePickerNam = new System.Windows.Forms.DateTimePicker();
            this.panelTest = new System.Windows.Forms.Panel();
            this.dataGridViewNam = new System.Windows.Forms.DataGridView();
            this.groupBoxBieuDoTangTruongHangThang = new System.Windows.Forms.GroupBox();
            this.labelNam = new System.Windows.Forms.Label();
            this.panelDoanhThuNgay = new System.Windows.Forms.Panel();
            this.panelNgayMau = new System.Windows.Forms.Panel();
            this.buttonNam = new System.Windows.Forms.Button();
            this.buttonDoanhThuTrongNgay = new System.Windows.Forms.Button();
            this.buttonDoanhThuThang = new System.Windows.Forms.Button();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.panelDoanhThuThang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHangTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThang)).BeginInit();
            this.groupBoxTongKetThang.SuspendLayout();
            this.groupBoxTKSP1.SuspendLayout();
            this.panelNgay.SuspendLayout();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSTTN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTKSP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSL)).BeginInit();
            this.groupBoxBanHang.SuspendLayout();
            this.groupBoxNhapKhoLuong.SuspendLayout();
            this.groupBoxLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxTKNam.SuspendLayout();
            this.panelNam.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNam)).BeginInit();
            this.groupBoxBieuDoTangTruongHangThang.SuspendLayout();
            this.panelDoanhThuNgay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDoanhThuThang
            // 
            this.panelDoanhThuThang.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panelDoanhThuThang.Controls.Add(this.panelThangMau);
            this.panelDoanhThuThang.Controls.Add(this.dataGridViewHangTra);
            this.panelDoanhThuThang.Controls.Add(this.panelCotY);
            this.panelDoanhThuThang.Controls.Add(this.labelSLBieuDoThang);
            this.panelDoanhThuThang.Controls.Add(this.panelCotX);
            this.panelDoanhThuThang.Controls.Add(this.dataGridViewThang);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp6T);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp5T);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp4T);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp3T);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp2T);
            this.panelDoanhThuThang.Controls.Add(this.labelSLsp1T);
            this.panelDoanhThuThang.Controls.Add(this.labelsp5Thang);
            this.panelDoanhThuThang.Controls.Add(this.labelsp6Thang);
            this.panelDoanhThuThang.Controls.Add(this.labelsp3Thang);
            this.panelDoanhThuThang.Controls.Add(this.labelsp4Thang);
            this.panelDoanhThuThang.Controls.Add(this.labelsp1Thang);
            this.panelDoanhThuThang.Controls.Add(this.panelsp4T);
            this.panelDoanhThuThang.Controls.Add(this.panelsp3T);
            this.panelDoanhThuThang.Controls.Add(this.panelsp6T);
            this.panelDoanhThuThang.Controls.Add(this.panelsp2T);
            this.panelDoanhThuThang.Controls.Add(this.panelsp5T);
            this.panelDoanhThuThang.Controls.Add(this.panelsp1T);
            this.panelDoanhThuThang.Controls.Add(this.label10);
            this.panelDoanhThuThang.Controls.Add(this.labelsp2Thang);
            this.panelDoanhThuThang.Controls.Add(this.label5);
            this.panelDoanhThuThang.Controls.Add(this.groupBoxTongKetThang);
            this.panelDoanhThuThang.Location = new System.Drawing.Point(258, 35);
            this.panelDoanhThuThang.Name = "panelDoanhThuThang";
            this.panelDoanhThuThang.Size = new System.Drawing.Size(979, 550);
            this.panelDoanhThuThang.TabIndex = 80;
            this.panelDoanhThuThang.Visible = false;
            // 
            // panelThangMau
            // 
            this.panelThangMau.BackColor = System.Drawing.Color.DarkCyan;
            this.panelThangMau.Location = new System.Drawing.Point(894, 321);
            this.panelThangMau.Name = "panelThangMau";
            this.panelThangMau.Size = new System.Drawing.Size(70, 180);
            this.panelThangMau.TabIndex = 115;
            this.panelThangMau.Visible = false;
            // 
            // dataGridViewHangTra
            // 
            this.dataGridViewHangTra.AllowDrop = true;
            this.dataGridViewHangTra.AllowUserToAddRows = false;
            this.dataGridViewHangTra.AllowUserToDeleteRows = false;
            this.dataGridViewHangTra.AllowUserToOrderColumns = true;
            this.dataGridViewHangTra.AllowUserToResizeColumns = false;
            this.dataGridViewHangTra.AllowUserToResizeRows = false;
            this.dataGridViewHangTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewHangTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHangTra.Location = new System.Drawing.Point(677, 267);
            this.dataGridViewHangTra.MultiSelect = false;
            this.dataGridViewHangTra.Name = "dataGridViewHangTra";
            this.dataGridViewHangTra.ReadOnly = true;
            this.dataGridViewHangTra.RowHeadersVisible = false;
            this.dataGridViewHangTra.RowHeadersWidth = 51;
            this.dataGridViewHangTra.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewHangTra.RowTemplate.Height = 30;
            this.dataGridViewHangTra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHangTra.Size = new System.Drawing.Size(49, 12);
            this.dataGridViewHangTra.TabIndex = 134;
            this.dataGridViewHangTra.Visible = false;
            // 
            // panelCotY
            // 
            this.panelCotY.BackColor = System.Drawing.Color.Black;
            this.panelCotY.Location = new System.Drawing.Point(39, 291);
            this.panelCotY.Name = "panelCotY";
            this.panelCotY.Size = new System.Drawing.Size(2, 210);
            this.panelCotY.TabIndex = 117;
            // 
            // labelSLBieuDoThang
            // 
            this.labelSLBieuDoThang.AutoSize = true;
            this.labelSLBieuDoThang.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLBieuDoThang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLBieuDoThang.ForeColor = System.Drawing.Color.Black;
            this.labelSLBieuDoThang.Location = new System.Drawing.Point(10, 290);
            this.labelSLBieuDoThang.Name = "labelSLBieuDoThang";
            this.labelSLBieuDoThang.Size = new System.Drawing.Size(32, 21);
            this.labelSLBieuDoThang.TabIndex = 134;
            this.labelSLBieuDoThang.Text = "SL";
            this.labelSLBieuDoThang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelCotX
            // 
            this.panelCotX.BackColor = System.Drawing.Color.Black;
            this.panelCotX.Location = new System.Drawing.Point(39, 501);
            this.panelCotX.Name = "panelCotX";
            this.panelCotX.Size = new System.Drawing.Size(930, 2);
            this.panelCotX.TabIndex = 116;
            // 
            // dataGridViewThang
            // 
            this.dataGridViewThang.AllowDrop = true;
            this.dataGridViewThang.AllowUserToAddRows = false;
            this.dataGridViewThang.AllowUserToDeleteRows = false;
            this.dataGridViewThang.AllowUserToOrderColumns = true;
            this.dataGridViewThang.AllowUserToResizeColumns = false;
            this.dataGridViewThang.AllowUserToResizeRows = false;
            this.dataGridViewThang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewThang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewThang.Location = new System.Drawing.Point(604, 267);
            this.dataGridViewThang.MultiSelect = false;
            this.dataGridViewThang.Name = "dataGridViewThang";
            this.dataGridViewThang.ReadOnly = true;
            this.dataGridViewThang.RowHeadersVisible = false;
            this.dataGridViewThang.RowHeadersWidth = 51;
            this.dataGridViewThang.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewThang.RowTemplate.Height = 30;
            this.dataGridViewThang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewThang.Size = new System.Drawing.Size(49, 12);
            this.dataGridViewThang.TabIndex = 133;
            this.dataGridViewThang.Visible = false;
            // 
            // labelSLsp6T
            // 
            this.labelSLsp6T.AutoSize = true;
            this.labelSLsp6T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp6T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp6T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp6T.Location = new System.Drawing.Point(831, 297);
            this.labelSLsp6T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp6T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp6T.Name = "labelSLsp6T";
            this.labelSLsp6T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp6T.TabIndex = 128;
            this.labelSLsp6T.Text = "100";
            this.labelSLsp6T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSLsp5T
            // 
            this.labelSLsp5T.AutoSize = true;
            this.labelSLsp5T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp5T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp5T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp5T.Location = new System.Drawing.Point(681, 297);
            this.labelSLsp5T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp5T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp5T.Name = "labelSLsp5T";
            this.labelSLsp5T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp5T.TabIndex = 127;
            this.labelSLsp5T.Text = "100";
            this.labelSLsp5T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSLsp4T
            // 
            this.labelSLsp4T.AutoSize = true;
            this.labelSLsp4T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp4T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp4T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp4T.Location = new System.Drawing.Point(531, 297);
            this.labelSLsp4T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp4T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp4T.Name = "labelSLsp4T";
            this.labelSLsp4T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp4T.TabIndex = 126;
            this.labelSLsp4T.Text = "100";
            this.labelSLsp4T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSLsp3T
            // 
            this.labelSLsp3T.AutoSize = true;
            this.labelSLsp3T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp3T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp3T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp3T.Location = new System.Drawing.Point(381, 297);
            this.labelSLsp3T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp3T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp3T.Name = "labelSLsp3T";
            this.labelSLsp3T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp3T.TabIndex = 125;
            this.labelSLsp3T.Text = "100";
            this.labelSLsp3T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSLsp2T
            // 
            this.labelSLsp2T.AutoSize = true;
            this.labelSLsp2T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp2T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp2T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp2T.Location = new System.Drawing.Point(232, 297);
            this.labelSLsp2T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp2T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp2T.Name = "labelSLsp2T";
            this.labelSLsp2T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp2T.TabIndex = 124;
            this.labelSLsp2T.Text = "100";
            this.labelSLsp2T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSLsp1T
            // 
            this.labelSLsp1T.AutoSize = true;
            this.labelSLsp1T.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLsp1T.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp1T.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp1T.Location = new System.Drawing.Point(81, 297);
            this.labelSLsp1T.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp1T.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp1T.Name = "labelSLsp1T";
            this.labelSLsp1T.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp1T.TabIndex = 123;
            this.labelSLsp1T.Text = "100";
            this.labelSLsp1T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelsp5Thang
            // 
            this.labelsp5Thang.AutoSize = true;
            this.labelsp5Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp5Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp5Thang.Location = new System.Drawing.Point(655, 505);
            this.labelsp5Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp5Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp5Thang.Name = "labelsp5Thang";
            this.labelsp5Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp5Thang.TabIndex = 128;
            this.labelsp5Thang.Text = "a s s s ừ f ư ư";
            this.labelsp5Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelsp6Thang
            // 
            this.labelsp6Thang.AutoSize = true;
            this.labelsp6Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp6Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp6Thang.Location = new System.Drawing.Point(804, 505);
            this.labelsp6Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp6Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp6Thang.Name = "labelsp6Thang";
            this.labelsp6Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp6Thang.TabIndex = 129;
            this.labelsp6Thang.Text = "a s s s ừ f ư ư";
            this.labelsp6Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelsp3Thang
            // 
            this.labelsp3Thang.AutoSize = true;
            this.labelsp3Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp3Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp3Thang.Location = new System.Drawing.Point(354, 505);
            this.labelsp3Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp3Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp3Thang.Name = "labelsp3Thang";
            this.labelsp3Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp3Thang.TabIndex = 126;
            this.labelsp3Thang.Text = "a s s s ừ f ư ư";
            this.labelsp3Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelsp4Thang
            // 
            this.labelsp4Thang.AutoSize = true;
            this.labelsp4Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp4Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp4Thang.Location = new System.Drawing.Point(502, 505);
            this.labelsp4Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp4Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp4Thang.Name = "labelsp4Thang";
            this.labelsp4Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp4Thang.TabIndex = 127;
            this.labelsp4Thang.Text = "a s s s ừ f ư ư";
            this.labelsp4Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelsp1Thang
            // 
            this.labelsp1Thang.AutoSize = true;
            this.labelsp1Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp1Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp1Thang.Location = new System.Drawing.Point(55, 505);
            this.labelsp1Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp1Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp1Thang.Name = "labelsp1Thang";
            this.labelsp1Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp1Thang.TabIndex = 124;
            this.labelsp1Thang.Text = "a s s s ừ f ư ư";
            this.labelsp1Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelsp4T
            // 
            this.panelsp4T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp4T.Location = new System.Drawing.Point(518, 321);
            this.panelsp4T.Name = "panelsp4T";
            this.panelsp4T.Size = new System.Drawing.Size(70, 180);
            this.panelsp4T.TabIndex = 116;
            // 
            // panelsp3T
            // 
            this.panelsp3T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp3T.Location = new System.Drawing.Point(368, 321);
            this.panelsp3T.Name = "panelsp3T";
            this.panelsp3T.Size = new System.Drawing.Size(70, 180);
            this.panelsp3T.TabIndex = 115;
            // 
            // panelsp6T
            // 
            this.panelsp6T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp6T.Location = new System.Drawing.Point(818, 321);
            this.panelsp6T.Name = "panelsp6T";
            this.panelsp6T.Size = new System.Drawing.Size(70, 180);
            this.panelsp6T.TabIndex = 118;
            // 
            // panelsp2T
            // 
            this.panelsp2T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp2T.Location = new System.Drawing.Point(218, 321);
            this.panelsp2T.Name = "panelsp2T";
            this.panelsp2T.Size = new System.Drawing.Size(70, 180);
            this.panelsp2T.TabIndex = 114;
            // 
            // panelsp5T
            // 
            this.panelsp5T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp5T.Location = new System.Drawing.Point(668, 321);
            this.panelsp5T.Name = "panelsp5T";
            this.panelsp5T.Size = new System.Drawing.Size(70, 180);
            this.panelsp5T.TabIndex = 117;
            // 
            // panelsp1T
            // 
            this.panelsp1T.BackColor = System.Drawing.Color.DarkCyan;
            this.panelsp1T.Location = new System.Drawing.Point(68, 321);
            this.panelsp1T.Name = "panelsp1T";
            this.panelsp1T.Size = new System.Drawing.Size(70, 180);
            this.panelsp1T.TabIndex = 113;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.ForeColor = System.Drawing.Color.DarkRed;
            this.label10.Location = new System.Drawing.Point(13, 255);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(585, 26);
            this.label10.TabIndex = 112;
            this.label10.Text = "CÁC SẢN PHẨM BÁN CHẠY NHẤT TRONG THÁNG";
            // 
            // labelsp2Thang
            // 
            this.labelsp2Thang.AutoSize = true;
            this.labelsp2Thang.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp2Thang.ForeColor = System.Drawing.Color.Black;
            this.labelsp2Thang.Location = new System.Drawing.Point(202, 505);
            this.labelsp2Thang.MaximumSize = new System.Drawing.Size(100, 46);
            this.labelsp2Thang.MinimumSize = new System.Drawing.Size(100, 46);
            this.labelsp2Thang.Name = "labelsp2Thang";
            this.labelsp2Thang.Size = new System.Drawing.Size(100, 46);
            this.labelsp2Thang.TabIndex = 125;
            this.labelsp2Thang.Text = "a s s s ừ f ư ư";
            this.labelsp2Thang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(910, 505);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 21);
            this.label5.TabIndex = 135;
            this.label5.Text = "Tên SP";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBoxTongKetThang
            // 
            this.groupBoxTongKetThang.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBoxTongKetThang.Controls.Add(this.dateTimePickerThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelLaiTuSPBanDuocTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelLaiTuSPBanDuocTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label22);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPDaBanTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPDaBanTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label21);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongGiamGiaThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongGiamGiaThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label36);
            this.groupBoxTongKetThang.Controls.Add(this.labelLoiNhuan);
            this.groupBoxTongKetThang.Controls.Add(this.labelLoiNhuan_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label18);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPNhapKhoTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPNhapKhoTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label20);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongTienNhapKhoTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongTienNhapKhoTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label9);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPKhachTraThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLSPKhachTraThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label14);
            this.groupBoxTongKetThang.Controls.Add(this.label6);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongLuongNV);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongLuongNV_Text);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLToaTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelKhachNoNoKhachTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.label34);
            this.groupBoxTongKetThang.Controls.Add(this.labelKhachNoNoKhachTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label37);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongDoanhThuTrongThang);
            this.groupBoxTongKetThang.Controls.Add(this.labelTongDoanhThuTrongThang_Text);
            this.groupBoxTongKetThang.Controls.Add(this.label35);
            this.groupBoxTongKetThang.Controls.Add(this.labelSLToaTrongThang_Text);
            this.groupBoxTongKetThang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxTongKetThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxTongKetThang.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxTongKetThang.Location = new System.Drawing.Point(5, 8);
            this.groupBoxTongKetThang.Name = "groupBoxTongKetThang";
            this.groupBoxTongKetThang.Size = new System.Drawing.Size(970, 231);
            this.groupBoxTongKetThang.TabIndex = 111;
            this.groupBoxTongKetThang.TabStop = false;
            this.groupBoxTongKetThang.Text = "TỔNG KẾT THÁNG";
            this.groupBoxTongKetThang.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxTongKetThang_Paint);
            // 
            // dateTimePickerThang
            // 
            this.dateTimePickerThang.CustomFormat = "dd/MM/yyyy";
            this.dateTimePickerThang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerThang.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThang.Location = new System.Drawing.Point(93, 40);
            this.dateTimePickerThang.Name = "dateTimePickerThang";
            this.dateTimePickerThang.ShowUpDown = true;
            this.dateTimePickerThang.Size = new System.Drawing.Size(200, 30);
            this.dateTimePickerThang.TabIndex = 160;
            this.dateTimePickerThang.ValueChanged += new System.EventHandler(this.dateTimePickerThang_ValueChanged);
            // 
            // labelLaiTuSPBanDuocTrongThang
            // 
            this.labelLaiTuSPBanDuocTrongThang.AutoSize = true;
            this.labelLaiTuSPBanDuocTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLaiTuSPBanDuocTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelLaiTuSPBanDuocTrongThang.Location = new System.Drawing.Point(515, 164);
            this.labelLaiTuSPBanDuocTrongThang.Name = "labelLaiTuSPBanDuocTrongThang";
            this.labelLaiTuSPBanDuocTrongThang.Size = new System.Drawing.Size(203, 26);
            this.labelLaiTuSPBanDuocTrongThang.TabIndex = 157;
            this.labelLaiTuSPBanDuocTrongThang.Text = "Tiền lãi từ SP bán:";
            // 
            // labelLaiTuSPBanDuocTrongThang_Text
            // 
            this.labelLaiTuSPBanDuocTrongThang_Text.AutoSize = true;
            this.labelLaiTuSPBanDuocTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLaiTuSPBanDuocTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelLaiTuSPBanDuocTrongThang_Text.Location = new System.Drawing.Point(776, 164);
            this.labelLaiTuSPBanDuocTrongThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelLaiTuSPBanDuocTrongThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelLaiTuSPBanDuocTrongThang_Text.Name = "labelLaiTuSPBanDuocTrongThang_Text";
            this.labelLaiTuSPBanDuocTrongThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelLaiTuSPBanDuocTrongThang_Text.TabIndex = 158;
            this.labelLaiTuSPBanDuocTrongThang_Text.Text = "0";
            this.labelLaiTuSPBanDuocTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(895, 164);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 27);
            this.label22.TabIndex = 159;
            this.label22.Text = "VNĐ";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPDaBanTrongThang
            // 
            this.labelSLSPDaBanTrongThang.AutoSize = true;
            this.labelSLSPDaBanTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBanTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPDaBanTrongThang.Location = new System.Drawing.Point(515, 194);
            this.labelSLSPDaBanTrongThang.Name = "labelSLSPDaBanTrongThang";
            this.labelSLSPDaBanTrongThang.Size = new System.Drawing.Size(226, 26);
            this.labelSLSPDaBanTrongThang.TabIndex = 154;
            this.labelSLSPDaBanTrongThang.Text = "SL sản phẩm đã bán:";
            // 
            // labelSLSPDaBanTrongThang_Text
            // 
            this.labelSLSPDaBanTrongThang_Text.AutoSize = true;
            this.labelSLSPDaBanTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBanTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPDaBanTrongThang_Text.Location = new System.Drawing.Point(776, 194);
            this.labelSLSPDaBanTrongThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPDaBanTrongThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPDaBanTrongThang_Text.Name = "labelSLSPDaBanTrongThang_Text";
            this.labelSLSPDaBanTrongThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelSLSPDaBanTrongThang_Text.TabIndex = 155;
            this.labelSLSPDaBanTrongThang_Text.Text = "0";
            this.labelSLSPDaBanTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(895, 194);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 27);
            this.label21.TabIndex = 156;
            this.label21.Text = "SP";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongGiamGiaThang
            // 
            this.labelTongGiamGiaThang.AutoSize = true;
            this.labelTongGiamGiaThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGiaThang.ForeColor = System.Drawing.Color.Black;
            this.labelTongGiamGiaThang.Location = new System.Drawing.Point(515, 104);
            this.labelTongGiamGiaThang.Name = "labelTongGiamGiaThang";
            this.labelTongGiamGiaThang.Size = new System.Drawing.Size(165, 26);
            this.labelTongGiamGiaThang.TabIndex = 148;
            this.labelTongGiamGiaThang.Text = "Tổng giảm giá:";
            // 
            // labelTongGiamGiaThang_Text
            // 
            this.labelTongGiamGiaThang_Text.AutoSize = true;
            this.labelTongGiamGiaThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGiaThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongGiamGiaThang_Text.Location = new System.Drawing.Point(776, 104);
            this.labelTongGiamGiaThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelTongGiamGiaThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelTongGiamGiaThang_Text.Name = "labelTongGiamGiaThang_Text";
            this.labelTongGiamGiaThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelTongGiamGiaThang_Text.TabIndex = 149;
            this.labelTongGiamGiaThang_Text.Text = "0";
            this.labelTongGiamGiaThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(895, 104);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(62, 27);
            this.label36.TabIndex = 150;
            this.label36.Text = "VNĐ";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelLoiNhuan
            // 
            this.labelLoiNhuan.AutoSize = true;
            this.labelLoiNhuan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiNhuan.ForeColor = System.Drawing.Color.Red;
            this.labelLoiNhuan.Location = new System.Drawing.Point(14, 194);
            this.labelLoiNhuan.Name = "labelLoiNhuan";
            this.labelLoiNhuan.Size = new System.Drawing.Size(126, 26);
            this.labelLoiNhuan.TabIndex = 145;
            this.labelLoiNhuan.Text = "Lợi nhuận:";
            // 
            // labelLoiNhuan_Text
            // 
            this.labelLoiNhuan_Text.AutoSize = true;
            this.labelLoiNhuan_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiNhuan_Text.ForeColor = System.Drawing.Color.Red;
            this.labelLoiNhuan_Text.Location = new System.Drawing.Point(257, 194);
            this.labelLoiNhuan_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelLoiNhuan_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelLoiNhuan_Text.Name = "labelLoiNhuan_Text";
            this.labelLoiNhuan_Text.Size = new System.Drawing.Size(195, 27);
            this.labelLoiNhuan_Text.TabIndex = 146;
            this.labelLoiNhuan_Text.Text = "0";
            this.labelLoiNhuan_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(446, 194);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 26);
            this.label18.TabIndex = 147;
            this.label18.Text = "VNĐ";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPNhapKhoTrongThang
            // 
            this.labelSLSPNhapKhoTrongThang.AutoSize = true;
            this.labelSLSPNhapKhoTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapKhoTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPNhapKhoTrongThang.Location = new System.Drawing.Point(515, 74);
            this.labelSLSPNhapKhoTrongThang.Name = "labelSLSPNhapKhoTrongThang";
            this.labelSLSPNhapKhoTrongThang.Size = new System.Drawing.Size(252, 26);
            this.labelSLSPNhapKhoTrongThang.TabIndex = 142;
            this.labelSLSPNhapKhoTrongThang.Text = "SL sản phẩm nhập kho:";
            // 
            // labelSLSPNhapKhoTrongThang_Text
            // 
            this.labelSLSPNhapKhoTrongThang_Text.AutoSize = true;
            this.labelSLSPNhapKhoTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapKhoTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPNhapKhoTrongThang_Text.Location = new System.Drawing.Point(776, 74);
            this.labelSLSPNhapKhoTrongThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPNhapKhoTrongThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPNhapKhoTrongThang_Text.Name = "labelSLSPNhapKhoTrongThang_Text";
            this.labelSLSPNhapKhoTrongThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelSLSPNhapKhoTrongThang_Text.TabIndex = 143;
            this.labelSLSPNhapKhoTrongThang_Text.Text = "0";
            this.labelSLSPNhapKhoTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(895, 74);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 27);
            this.label20.TabIndex = 144;
            this.label20.Text = "SP";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongTienNhapKhoTrongThang
            // 
            this.labelTongTienNhapKhoTrongThang.AutoSize = true;
            this.labelTongTienNhapKhoTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienNhapKhoTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelTongTienNhapKhoTrongThang.Location = new System.Drawing.Point(515, 44);
            this.labelTongTienNhapKhoTrongThang.Name = "labelTongTienNhapKhoTrongThang";
            this.labelTongTienNhapKhoTrongThang.Size = new System.Drawing.Size(218, 26);
            this.labelTongTienNhapKhoTrongThang.TabIndex = 139;
            this.labelTongTienNhapKhoTrongThang.Text = "Tổng tiền nhập kho:";
            // 
            // labelTongTienNhapKhoTrongThang_Text
            // 
            this.labelTongTienNhapKhoTrongThang_Text.AutoSize = true;
            this.labelTongTienNhapKhoTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienNhapKhoTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongTienNhapKhoTrongThang_Text.Location = new System.Drawing.Point(776, 44);
            this.labelTongTienNhapKhoTrongThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelTongTienNhapKhoTrongThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelTongTienNhapKhoTrongThang_Text.Name = "labelTongTienNhapKhoTrongThang_Text";
            this.labelTongTienNhapKhoTrongThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelTongTienNhapKhoTrongThang_Text.TabIndex = 140;
            this.labelTongTienNhapKhoTrongThang_Text.Text = "0";
            this.labelTongTienNhapKhoTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(895, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 27);
            this.label9.TabIndex = 141;
            this.label9.Text = "VNĐ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPKhachTraThang
            // 
            this.labelSLSPKhachTraThang.AutoSize = true;
            this.labelSLSPKhachTraThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPKhachTraThang.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPKhachTraThang.Location = new System.Drawing.Point(515, 134);
            this.labelSLSPKhachTraThang.Name = "labelSLSPKhachTraThang";
            this.labelSLSPKhachTraThang.Size = new System.Drawing.Size(256, 26);
            this.labelSLSPKhachTraThang.TabIndex = 133;
            this.labelSLSPKhachTraThang.Text = "SL sản phẩm khách trả:";
            // 
            // labelSLSPKhachTraThang_Text
            // 
            this.labelSLSPKhachTraThang_Text.AutoSize = true;
            this.labelSLSPKhachTraThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPKhachTraThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPKhachTraThang_Text.Location = new System.Drawing.Point(776, 134);
            this.labelSLSPKhachTraThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPKhachTraThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelSLSPKhachTraThang_Text.Name = "labelSLSPKhachTraThang_Text";
            this.labelSLSPKhachTraThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelSLSPKhachTraThang_Text.TabIndex = 134;
            this.labelSLSPKhachTraThang_Text.Text = "0";
            this.labelSLSPKhachTraThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(895, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 27);
            this.label14.TabIndex = 135;
            this.label14.Text = "SP";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(446, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 27);
            this.label6.TabIndex = 126;
            this.label6.Text = "Toa";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongLuongNV
            // 
            this.labelTongLuongNV.AutoSize = true;
            this.labelTongLuongNV.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongLuongNV.ForeColor = System.Drawing.Color.Black;
            this.labelTongLuongNV.Location = new System.Drawing.Point(14, 134);
            this.labelTongLuongNV.Name = "labelTongLuongNV";
            this.labelTongLuongNV.Size = new System.Drawing.Size(242, 26);
            this.labelTongLuongNV.TabIndex = 91;
            this.labelTongLuongNV.Text = "Tổng lương nhân viên:";
            // 
            // labelTongLuongNV_Text
            // 
            this.labelTongLuongNV_Text.AutoSize = true;
            this.labelTongLuongNV_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongLuongNV_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongLuongNV_Text.Location = new System.Drawing.Point(327, 134);
            this.labelTongLuongNV_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelTongLuongNV_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelTongLuongNV_Text.Name = "labelTongLuongNV_Text";
            this.labelTongLuongNV_Text.Size = new System.Drawing.Size(125, 27);
            this.labelTongLuongNV_Text.TabIndex = 92;
            this.labelTongLuongNV_Text.Text = "0";
            this.labelTongLuongNV_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLToaTrongThang
            // 
            this.labelSLToaTrongThang.AutoSize = true;
            this.labelSLToaTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLToaTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelSLToaTrongThang.Location = new System.Drawing.Point(14, 74);
            this.labelSLToaTrongThang.Name = "labelSLToaTrongThang";
            this.labelSLToaTrongThang.Size = new System.Drawing.Size(154, 26);
            this.labelSLToaTrongThang.TabIndex = 83;
            this.labelSLToaTrongThang.Text = "Số lượng toa: ";
            // 
            // labelThang
            // 
            this.labelThang.AutoSize = true;
            this.labelThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang.ForeColor = System.Drawing.Color.Black;
            this.labelThang.Location = new System.Drawing.Point(13, 44);
            this.labelThang.Name = "labelThang";
            this.labelThang.Size = new System.Drawing.Size(85, 26);
            this.labelThang.TabIndex = 82;
            this.labelThang.Text = "Tháng:";
            // 
            // labelKhachNoNoKhachTrongThang
            // 
            this.labelKhachNoNoKhachTrongThang.AutoSize = true;
            this.labelKhachNoNoKhachTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNoNoKhachTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNoNoKhachTrongThang.Location = new System.Drawing.Point(14, 164);
            this.labelKhachNoNoKhachTrongThang.Name = "labelKhachNoNoKhachTrongThang";
            this.labelKhachNoNoKhachTrongThang.Size = new System.Drawing.Size(225, 26);
            this.labelKhachNoNoKhachTrongThang.TabIndex = 89;
            this.labelKhachNoNoKhachTrongThang.Text = "Khách nợ/Nợ khách:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(446, 134);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(62, 27);
            this.label34.TabIndex = 96;
            this.label34.Text = "VNĐ";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachNoNoKhachTrongThang_Text
            // 
            this.labelKhachNoNoKhachTrongThang_Text.AutoSize = true;
            this.labelKhachNoNoKhachTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNoNoKhachTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNoNoKhachTrongThang_Text.Location = new System.Drawing.Point(237, 164);
            this.labelKhachNoNoKhachTrongThang_Text.MaximumSize = new System.Drawing.Size(215, 27);
            this.labelKhachNoNoKhachTrongThang_Text.MinimumSize = new System.Drawing.Size(215, 27);
            this.labelKhachNoNoKhachTrongThang_Text.Name = "labelKhachNoNoKhachTrongThang_Text";
            this.labelKhachNoNoKhachTrongThang_Text.Size = new System.Drawing.Size(215, 27);
            this.labelKhachNoNoKhachTrongThang_Text.TabIndex = 90;
            this.labelKhachNoNoKhachTrongThang_Text.Text = "10000000/10000000";
            this.labelKhachNoNoKhachTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(446, 104);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(62, 27);
            this.label37.TabIndex = 93;
            this.label37.Text = "VNĐ";
            this.label37.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongDoanhThuTrongThang
            // 
            this.labelTongDoanhThuTrongThang.AutoSize = true;
            this.labelTongDoanhThuTrongThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDoanhThuTrongThang.ForeColor = System.Drawing.Color.Black;
            this.labelTongDoanhThuTrongThang.Location = new System.Drawing.Point(14, 104);
            this.labelTongDoanhThuTrongThang.Name = "labelTongDoanhThuTrongThang";
            this.labelTongDoanhThuTrongThang.Size = new System.Drawing.Size(181, 26);
            this.labelTongDoanhThuTrongThang.TabIndex = 85;
            this.labelTongDoanhThuTrongThang.Text = "Tổng doanh thu:";
            // 
            // labelTongDoanhThuTrongThang_Text
            // 
            this.labelTongDoanhThuTrongThang_Text.AutoSize = true;
            this.labelTongDoanhThuTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDoanhThuTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongDoanhThuTrongThang_Text.Location = new System.Drawing.Point(327, 104);
            this.labelTongDoanhThuTrongThang_Text.MaximumSize = new System.Drawing.Size(125, 27);
            this.labelTongDoanhThuTrongThang_Text.MinimumSize = new System.Drawing.Size(125, 27);
            this.labelTongDoanhThuTrongThang_Text.Name = "labelTongDoanhThuTrongThang_Text";
            this.labelTongDoanhThuTrongThang_Text.Size = new System.Drawing.Size(125, 27);
            this.labelTongDoanhThuTrongThang_Text.TabIndex = 86;
            this.labelTongDoanhThuTrongThang_Text.Text = "0";
            this.labelTongDoanhThuTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(446, 164);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 27);
            this.label35.TabIndex = 95;
            this.label35.Text = "VNĐ";
            this.label35.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLToaTrongThang_Text
            // 
            this.labelSLToaTrongThang_Text.AutoSize = true;
            this.labelSLToaTrongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLToaTrongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLToaTrongThang_Text.Location = new System.Drawing.Point(397, 74);
            this.labelSLToaTrongThang_Text.MaximumSize = new System.Drawing.Size(55, 27);
            this.labelSLToaTrongThang_Text.MinimumSize = new System.Drawing.Size(55, 27);
            this.labelSLToaTrongThang_Text.Name = "labelSLToaTrongThang_Text";
            this.labelSLToaTrongThang_Text.Size = new System.Drawing.Size(55, 27);
            this.labelSLToaTrongThang_Text.TabIndex = 84;
            this.labelSLToaTrongThang_Text.Text = "0";
            this.labelSLToaTrongThang_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelThang12
            // 
            this.labelThang12.AutoSize = true;
            this.labelThang12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang12.ForeColor = System.Drawing.Color.Black;
            this.labelThang12.Location = new System.Drawing.Point(5, 474);
            this.labelThang12.Name = "labelThang12";
            this.labelThang12.Size = new System.Drawing.Size(88, 23);
            this.labelThang12.TabIndex = 131;
            this.labelThang12.Text = "Tháng 12";
            // 
            // labelThang11
            // 
            this.labelThang11.AutoSize = true;
            this.labelThang11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang11.ForeColor = System.Drawing.Color.Black;
            this.labelThang11.Location = new System.Drawing.Point(5, 434);
            this.labelThang11.Name = "labelThang11";
            this.labelThang11.Size = new System.Drawing.Size(87, 23);
            this.labelThang11.TabIndex = 130;
            this.labelThang11.Text = "Tháng 11";
            // 
            // labelThang10
            // 
            this.labelThang10.AutoSize = true;
            this.labelThang10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang10.ForeColor = System.Drawing.Color.Black;
            this.labelThang10.Location = new System.Drawing.Point(5, 394);
            this.labelThang10.Name = "labelThang10";
            this.labelThang10.Size = new System.Drawing.Size(88, 23);
            this.labelThang10.TabIndex = 129;
            this.labelThang10.Text = "Tháng 10";
            // 
            // panelThang12
            // 
            this.panelThang12.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang12.Location = new System.Drawing.Point(93, 472);
            this.panelThang12.Name = "panelThang12";
            this.panelThang12.Size = new System.Drawing.Size(310, 25);
            this.panelThang12.TabIndex = 119;
            // 
            // panelThang8
            // 
            this.panelThang8.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang8.Location = new System.Drawing.Point(93, 312);
            this.panelThang8.Name = "panelThang8";
            this.panelThang8.Size = new System.Drawing.Size(310, 25);
            this.panelThang8.TabIndex = 115;
            // 
            // labelNgay
            // 
            this.labelNgay.AutoSize = true;
            this.labelNgay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay.Location = new System.Drawing.Point(3, 8);
            this.labelNgay.Name = "labelNgay";
            this.labelNgay.Size = new System.Drawing.Size(73, 26);
            this.labelNgay.TabIndex = 42;
            this.labelNgay.Text = "Ngày:";
            // 
            // panelThang11
            // 
            this.panelThang11.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang11.Location = new System.Drawing.Point(93, 432);
            this.panelThang11.Name = "panelThang11";
            this.panelThang11.Size = new System.Drawing.Size(310, 25);
            this.panelThang11.TabIndex = 117;
            // 
            // panelThang4
            // 
            this.panelThang4.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang4.Location = new System.Drawing.Point(93, 152);
            this.panelThang4.Name = "panelThang4";
            this.panelThang4.Size = new System.Drawing.Size(310, 25);
            this.panelThang4.TabIndex = 111;
            // 
            // panelThang7
            // 
            this.panelThang7.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang7.Location = new System.Drawing.Point(93, 272);
            this.panelThang7.Name = "panelThang7";
            this.panelThang7.Size = new System.Drawing.Size(310, 25);
            this.panelThang7.TabIndex = 113;
            // 
            // panelThang10
            // 
            this.panelThang10.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang10.Location = new System.Drawing.Point(93, 392);
            this.panelThang10.Name = "panelThang10";
            this.panelThang10.Size = new System.Drawing.Size(310, 25);
            this.panelThang10.TabIndex = 118;
            // 
            // groupBoxTKSP1
            // 
            this.groupBoxTKSP1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBoxTKSP1.Controls.Add(this.panelNgay);
            this.groupBoxTKSP1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxTKSP1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxTKSP1.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxTKSP1.Location = new System.Drawing.Point(463, 6);
            this.groupBoxTKSP1.Name = "groupBoxTKSP1";
            this.groupBoxTKSP1.Size = new System.Drawing.Size(509, 301);
            this.groupBoxTKSP1.TabIndex = 60;
            this.groupBoxTKSP1.TabStop = false;
            this.groupBoxTKSP1.Text = "THỐNG KÊ SẢN PHẨM";
            this.groupBoxTKSP1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxTKSP1_Paint);
            // 
            // panelNgay
            // 
            this.panelNgay.Controls.Add(this.labelChuThichTKSP1);
            this.panelNgay.Controls.Add(this.labelsp4);
            this.panelNgay.Controls.Add(this.labelsp3);
            this.panelNgay.Controls.Add(this.labelsp2);
            this.panelNgay.Controls.Add(this.labelsp1);
            this.panelNgay.Controls.Add(this.panelsp4);
            this.panelNgay.Controls.Add(this.panelsp3);
            this.panelNgay.Controls.Add(this.panelsp2);
            this.panelNgay.Controls.Add(this.panelsp1);
            this.panelNgay.Controls.Add(this.labelSLsp4);
            this.panelNgay.Controls.Add(this.labelSLsp3);
            this.panelNgay.Controls.Add(this.labelSLsp2);
            this.panelNgay.Controls.Add(this.labelSLsp1);
            this.panelNgay.Location = new System.Drawing.Point(8, 27);
            this.panelNgay.Name = "panelNgay";
            this.panelNgay.Size = new System.Drawing.Size(495, 265);
            this.panelNgay.TabIndex = 101;
            // 
            // labelChuThichTKSP1
            // 
            this.labelChuThichTKSP1.AutoSize = true;
            this.labelChuThichTKSP1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelChuThichTKSP1.ForeColor = System.Drawing.Color.Black;
            this.labelChuThichTKSP1.Location = new System.Drawing.Point(190, 235);
            this.labelChuThichTKSP1.Name = "labelChuThichTKSP1";
            this.labelChuThichTKSP1.Size = new System.Drawing.Size(217, 21);
            this.labelChuThichTKSP1.TabIndex = 113;
            this.labelChuThichTKSP1.Text = "4 sản phẩm bán chạy nhất";
            this.labelChuThichTKSP1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelsp4
            // 
            this.labelsp4.AutoSize = true;
            this.labelsp4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp4.ForeColor = System.Drawing.Color.Black;
            this.labelsp4.Location = new System.Drawing.Point(6, 184);
            this.labelsp4.MaximumSize = new System.Drawing.Size(125, 48);
            this.labelsp4.MinimumSize = new System.Drawing.Size(125, 48);
            this.labelsp4.Name = "labelsp4";
            this.labelsp4.Size = new System.Drawing.Size(125, 48);
            this.labelsp4.TabIndex = 108;
            this.labelsp4.Text = "sản phẩm 4";
            // 
            // labelsp3
            // 
            this.labelsp3.AutoSize = true;
            this.labelsp3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp3.ForeColor = System.Drawing.Color.Black;
            this.labelsp3.Location = new System.Drawing.Point(6, 125);
            this.labelsp3.MaximumSize = new System.Drawing.Size(125, 48);
            this.labelsp3.MinimumSize = new System.Drawing.Size(125, 48);
            this.labelsp3.Name = "labelsp3";
            this.labelsp3.Size = new System.Drawing.Size(125, 48);
            this.labelsp3.TabIndex = 107;
            this.labelsp3.Text = "sản phẩm 3";
            // 
            // labelsp2
            // 
            this.labelsp2.AutoSize = true;
            this.labelsp2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp2.ForeColor = System.Drawing.Color.Black;
            this.labelsp2.Location = new System.Drawing.Point(6, 66);
            this.labelsp2.MaximumSize = new System.Drawing.Size(125, 48);
            this.labelsp2.MinimumSize = new System.Drawing.Size(125, 48);
            this.labelsp2.Name = "labelsp2";
            this.labelsp2.Size = new System.Drawing.Size(125, 48);
            this.labelsp2.TabIndex = 106;
            this.labelsp2.Text = "sản phẩm 2";
            // 
            // labelsp1
            // 
            this.labelsp1.AutoSize = true;
            this.labelsp1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelsp1.ForeColor = System.Drawing.Color.Black;
            this.labelsp1.Location = new System.Drawing.Point(6, 7);
            this.labelsp1.MaximumSize = new System.Drawing.Size(125, 48);
            this.labelsp1.MinimumSize = new System.Drawing.Size(125, 48);
            this.labelsp1.Name = "labelsp1";
            this.labelsp1.Size = new System.Drawing.Size(125, 48);
            this.labelsp1.TabIndex = 105;
            this.labelsp1.Text = "sản phẩm 1";
            // 
            // panelsp4
            // 
            this.panelsp4.BackColor = System.Drawing.Color.LightBlue;
            this.panelsp4.Location = new System.Drawing.Point(145, 184);
            this.panelsp4.Name = "panelsp4";
            this.panelsp4.Size = new System.Drawing.Size(300, 38);
            this.panelsp4.TabIndex = 104;
            // 
            // panelsp3
            // 
            this.panelsp3.BackColor = System.Drawing.Color.LightBlue;
            this.panelsp3.Location = new System.Drawing.Point(145, 125);
            this.panelsp3.Name = "panelsp3";
            this.panelsp3.Size = new System.Drawing.Size(300, 38);
            this.panelsp3.TabIndex = 102;
            // 
            // panelsp2
            // 
            this.panelsp2.BackColor = System.Drawing.Color.LightBlue;
            this.panelsp2.Location = new System.Drawing.Point(145, 66);
            this.panelsp2.MaximumSize = new System.Drawing.Size(300, 38);
            this.panelsp2.Name = "panelsp2";
            this.panelsp2.Size = new System.Drawing.Size(300, 38);
            this.panelsp2.TabIndex = 103;
            // 
            // panelsp1
            // 
            this.panelsp1.BackColor = System.Drawing.Color.LightBlue;
            this.panelsp1.Location = new System.Drawing.Point(145, 7);
            this.panelsp1.Name = "panelsp1";
            this.panelsp1.Size = new System.Drawing.Size(300, 38);
            this.panelsp1.TabIndex = 101;
            // 
            // labelSLsp4
            // 
            this.labelSLsp4.AutoSize = true;
            this.labelSLsp4.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp4.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp4.Location = new System.Drawing.Point(444, 194);
            this.labelSLsp4.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp4.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp4.Name = "labelSLsp4";
            this.labelSLsp4.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp4.TabIndex = 112;
            this.labelSLsp4.Text = "0";
            this.labelSLsp4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLsp3
            // 
            this.labelSLsp3.AutoSize = true;
            this.labelSLsp3.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp3.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp3.Location = new System.Drawing.Point(444, 135);
            this.labelSLsp3.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp3.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp3.Name = "labelSLsp3";
            this.labelSLsp3.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp3.TabIndex = 111;
            this.labelSLsp3.Text = "0";
            this.labelSLsp3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLsp2
            // 
            this.labelSLsp2.AutoSize = true;
            this.labelSLsp2.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp2.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp2.Location = new System.Drawing.Point(444, 76);
            this.labelSLsp2.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp2.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp2.Name = "labelSLsp2";
            this.labelSLsp2.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp2.TabIndex = 110;
            this.labelSLsp2.Text = "0";
            this.labelSLsp2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLsp1
            // 
            this.labelSLsp1.AutoSize = true;
            this.labelSLsp1.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLsp1.ForeColor = System.Drawing.Color.Black;
            this.labelSLsp1.Location = new System.Drawing.Point(444, 17);
            this.labelSLsp1.MaximumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp1.MinimumSize = new System.Drawing.Size(45, 21);
            this.labelSLsp1.Name = "labelSLsp1";
            this.labelSLsp1.Size = new System.Drawing.Size(45, 21);
            this.labelSLsp1.TabIndex = 109;
            this.labelSLsp1.Text = "0";
            this.labelSLsp1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNoKhach
            // 
            this.labelNoKhach.AutoSize = true;
            this.labelNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhach.Location = new System.Drawing.Point(3, 158);
            this.labelNoKhach.Name = "labelNoKhach";
            this.labelNoKhach.Size = new System.Drawing.Size(118, 26);
            this.labelNoKhach.TabIndex = 57;
            this.labelNoKhach.Text = "Nợ khách:";
            // 
            // labelNoKhach_Text
            // 
            this.labelNoKhach_Text.AutoSize = true;
            this.labelNoKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhach_Text.Location = new System.Drawing.Point(217, 158);
            this.labelNoKhach_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelNoKhach_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelNoKhach_Text.Name = "labelNoKhach_Text";
            this.labelNoKhach_Text.Size = new System.Drawing.Size(195, 27);
            this.labelNoKhach_Text.TabIndex = 58;
            this.labelNoKhach_Text.Text = "0";
            this.labelNoKhach_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachNo
            // 
            this.labelKhachNo.AutoSize = true;
            this.labelKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo.Location = new System.Drawing.Point(3, 128);
            this.labelKhachNo.Name = "labelKhachNo";
            this.labelKhachNo.Size = new System.Drawing.Size(120, 26);
            this.labelKhachNo.TabIndex = 55;
            this.labelKhachNo.Text = "Khách nợ:";
            // 
            // labelKhachNo_Text
            // 
            this.labelKhachNo_Text.AutoSize = true;
            this.labelKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo_Text.Location = new System.Drawing.Point(217, 128);
            this.labelKhachNo_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelKhachNo_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelKhachNo_Text.Name = "labelKhachNo_Text";
            this.labelKhachNo_Text.Size = new System.Drawing.Size(195, 27);
            this.labelKhachNo_Text.TabIndex = 56;
            this.labelKhachNo_Text.Text = "0";
            this.labelKhachNo_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongGiamGia
            // 
            this.labelTongGiamGia.AutoSize = true;
            this.labelTongGiamGia.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGia.Location = new System.Drawing.Point(3, 98);
            this.labelTongGiamGia.Name = "labelTongGiamGia";
            this.labelTongGiamGia.Size = new System.Drawing.Size(165, 26);
            this.labelTongGiamGia.TabIndex = 53;
            this.labelTongGiamGia.Text = "Tổng giảm giá:";
            // 
            // labelTongGiamGia_Text
            // 
            this.labelTongGiamGia_Text.AutoSize = true;
            this.labelTongGiamGia_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGia_Text.Location = new System.Drawing.Point(217, 98);
            this.labelTongGiamGia_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelTongGiamGia_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelTongGiamGia_Text.Name = "labelTongGiamGia_Text";
            this.labelTongGiamGia_Text.Size = new System.Drawing.Size(195, 27);
            this.labelTongGiamGia_Text.TabIndex = 54;
            this.labelTongGiamGia_Text.Text = "0";
            this.labelTongGiamGia_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongDoanhThu
            // 
            this.labelTongDoanhThu.AutoSize = true;
            this.labelTongDoanhThu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDoanhThu.Location = new System.Drawing.Point(3, 68);
            this.labelTongDoanhThu.Name = "labelTongDoanhThu";
            this.labelTongDoanhThu.Size = new System.Drawing.Size(181, 26);
            this.labelTongDoanhThu.TabIndex = 51;
            this.labelTongDoanhThu.Text = "Tổng doanh thu:";
            // 
            // labelTongDoanhThu_Text
            // 
            this.labelTongDoanhThu_Text.AutoSize = true;
            this.labelTongDoanhThu_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDoanhThu_Text.Location = new System.Drawing.Point(217, 68);
            this.labelTongDoanhThu_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelTongDoanhThu_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelTongDoanhThu_Text.Name = "labelTongDoanhThu_Text";
            this.labelTongDoanhThu_Text.Size = new System.Drawing.Size(195, 27);
            this.labelTongDoanhThu_Text.TabIndex = 52;
            this.labelTongDoanhThu_Text.Text = "0";
            this.labelTongDoanhThu_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLToa
            // 
            this.labelSLToa.AutoSize = true;
            this.labelSLToa.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLToa.Location = new System.Drawing.Point(3, 38);
            this.labelSLToa.Name = "labelSLToa";
            this.labelSLToa.Size = new System.Drawing.Size(154, 26);
            this.labelSLToa.TabIndex = 44;
            this.labelSLToa.Text = "Số lượng toa: ";
            // 
            // labelSLToa_Text
            // 
            this.labelSLToa_Text.AutoSize = true;
            this.labelSLToa_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLToa_Text.Location = new System.Drawing.Point(307, 37);
            this.labelSLToa_Text.MaximumSize = new System.Drawing.Size(105, 27);
            this.labelSLToa_Text.MinimumSize = new System.Drawing.Size(105, 27);
            this.labelSLToa_Text.Name = "labelSLToa_Text";
            this.labelSLToa_Text.Size = new System.Drawing.Size(105, 27);
            this.labelSLToa_Text.TabIndex = 45;
            this.labelSLToa_Text.Text = "0";
            this.labelSLToa_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelDSTTN
            // 
            this.labelDSTTN.AutoSize = true;
            this.labelDSTTN.BackColor = System.Drawing.Color.Transparent;
            this.labelDSTTN.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDSTTN.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDSTTN.Location = new System.Drawing.Point(3, 198);
            this.labelDSTTN.Name = "labelDSTTN";
            this.labelDSTTN.Size = new System.Drawing.Size(377, 26);
            this.labelDSTTN.TabIndex = 49;
            this.labelDSTTN.Text = "DANH SÁCH TOA TRONG NGÀY";
            // 
            // panelThang9
            // 
            this.panelThang9.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang9.Location = new System.Drawing.Point(93, 352);
            this.panelThang9.Name = "panelThang9";
            this.panelThang9.Size = new System.Drawing.Size(310, 25);
            this.panelThang9.TabIndex = 116;
            // 
            // labelTongTienNhapKho
            // 
            this.labelTongTienNhapKho.AutoSize = true;
            this.labelTongTienNhapKho.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienNhapKho.Location = new System.Drawing.Point(467, 430);
            this.labelTongTienNhapKho.Name = "labelTongTienNhapKho";
            this.labelTongTienNhapKho.Size = new System.Drawing.Size(218, 26);
            this.labelTongTienNhapKho.TabIndex = 79;
            this.labelTongTienNhapKho.Text = "Tổng tiền nhập kho:";
            // 
            // labelTongTienNhapKho_Text
            // 
            this.labelTongTienNhapKho_Text.AutoSize = true;
            this.labelTongTienNhapKho_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienNhapKho_Text.Location = new System.Drawing.Point(750, 430);
            this.labelTongTienNhapKho_Text.MaximumSize = new System.Drawing.Size(175, 27);
            this.labelTongTienNhapKho_Text.MinimumSize = new System.Drawing.Size(175, 27);
            this.labelTongTienNhapKho_Text.Name = "labelTongTienNhapKho_Text";
            this.labelTongTienNhapKho_Text.Size = new System.Drawing.Size(175, 27);
            this.labelTongTienNhapKho_Text.TabIndex = 80;
            this.labelTongTienNhapKho_Text.Text = "0";
            this.labelTongTienNhapKho_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panelThang3
            // 
            this.panelThang3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang3.Location = new System.Drawing.Point(93, 112);
            this.panelThang3.Name = "panelThang3";
            this.panelThang3.Size = new System.Drawing.Size(310, 25);
            this.panelThang3.TabIndex = 109;
            // 
            // panelThang6
            // 
            this.panelThang6.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang6.Location = new System.Drawing.Point(93, 232);
            this.panelThang6.Name = "panelThang6";
            this.panelThang6.Size = new System.Drawing.Size(310, 25);
            this.panelThang6.TabIndex = 114;
            // 
            // labelSLSPDaBan
            // 
            this.labelSLSPDaBan.AutoSize = true;
            this.labelSLSPDaBan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBan.Location = new System.Drawing.Point(467, 490);
            this.labelSLSPDaBan.Name = "labelSLSPDaBan";
            this.labelSLSPDaBan.Size = new System.Drawing.Size(226, 26);
            this.labelSLSPDaBan.TabIndex = 69;
            this.labelSLSPDaBan.Text = "SL sản phẩm đã bán:";
            // 
            // labelSLSPDaBan_Text
            // 
            this.labelSLSPDaBan_Text.AutoSize = true;
            this.labelSLSPDaBan_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBan_Text.Location = new System.Drawing.Point(750, 490);
            this.labelSLSPDaBan_Text.MaximumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPDaBan_Text.MinimumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPDaBan_Text.Name = "labelSLSPDaBan_Text";
            this.labelSLSPDaBan_Text.Size = new System.Drawing.Size(175, 27);
            this.labelSLSPDaBan_Text.TabIndex = 70;
            this.labelSLSPDaBan_Text.Text = "0";
            this.labelSLSPDaBan_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelLaiTuSPBanDuoc
            // 
            this.labelLaiTuSPBanDuoc.AutoSize = true;
            this.labelLaiTuSPBanDuoc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLaiTuSPBanDuoc.Location = new System.Drawing.Point(467, 520);
            this.labelLaiTuSPBanDuoc.Name = "labelLaiTuSPBanDuoc";
            this.labelLaiTuSPBanDuoc.Size = new System.Drawing.Size(217, 26);
            this.labelLaiTuSPBanDuoc.TabIndex = 67;
            this.labelLaiTuSPBanDuoc.Text = "Lãi từ SP bán được:";
            // 
            // labelLaiTuSPBanDuoc_Text
            // 
            this.labelLaiTuSPBanDuoc_Text.AutoSize = true;
            this.labelLaiTuSPBanDuoc_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLaiTuSPBanDuoc_Text.Location = new System.Drawing.Point(750, 520);
            this.labelLaiTuSPBanDuoc_Text.MaximumSize = new System.Drawing.Size(175, 27);
            this.labelLaiTuSPBanDuoc_Text.MinimumSize = new System.Drawing.Size(175, 27);
            this.labelLaiTuSPBanDuoc_Text.Name = "labelLaiTuSPBanDuoc_Text";
            this.labelLaiTuSPBanDuoc_Text.Size = new System.Drawing.Size(175, 27);
            this.labelLaiTuSPBanDuoc_Text.TabIndex = 68;
            this.labelLaiTuSPBanDuoc_Text.Text = "0";
            this.labelLaiTuSPBanDuoc_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panelThang2
            // 
            this.panelThang2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang2.Location = new System.Drawing.Point(93, 72);
            this.panelThang2.Name = "panelThang2";
            this.panelThang2.Size = new System.Drawing.Size(310, 25);
            this.panelThang2.TabIndex = 110;
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(1236, 35);
            this.panelThanhTieuDe.TabIndex = 81;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(225, 23);
            this.labelTieuDeForm.TabIndex = 92;
            this.labelTieuDeForm.Text = "QUẢN LÝ DOANH THU";
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(1127, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(1182, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // panelThang5
            // 
            this.panelThang5.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang5.Location = new System.Drawing.Point(93, 192);
            this.panelThang5.Name = "panelThang5";
            this.panelThang5.Size = new System.Drawing.Size(310, 25);
            this.panelThang5.TabIndex = 112;
            // 
            // panelThang1
            // 
            this.panelThang1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelThang1.Location = new System.Drawing.Point(93, 32);
            this.panelThang1.Name = "panelThang1";
            this.panelThang1.Size = new System.Drawing.Size(310, 25);
            this.panelThang1.TabIndex = 108;
            // 
            // labelDTThang12
            // 
            this.labelDTThang12.AutoSize = true;
            this.labelDTThang12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang12.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang12.Location = new System.Drawing.Point(411, 472);
            this.labelDTThang12.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang12.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang12.Name = "labelDTThang12";
            this.labelDTThang12.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang12.TabIndex = 143;
            this.labelDTThang12.Text = "0";
            this.labelDTThang12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang11
            // 
            this.labelDTThang11.AutoSize = true;
            this.labelDTThang11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang11.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang11.Location = new System.Drawing.Point(411, 432);
            this.labelDTThang11.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang11.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang11.Name = "labelDTThang11";
            this.labelDTThang11.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang11.TabIndex = 142;
            this.labelDTThang11.Text = "0";
            this.labelDTThang11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang10
            // 
            this.labelDTThang10.AutoSize = true;
            this.labelDTThang10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang10.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang10.Location = new System.Drawing.Point(411, 392);
            this.labelDTThang10.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang10.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang10.Name = "labelDTThang10";
            this.labelDTThang10.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang10.TabIndex = 141;
            this.labelDTThang10.Text = "0";
            this.labelDTThang10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang9
            // 
            this.labelDTThang9.AutoSize = true;
            this.labelDTThang9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang9.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang9.Location = new System.Drawing.Point(411, 352);
            this.labelDTThang9.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang9.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang9.Name = "labelDTThang9";
            this.labelDTThang9.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang9.TabIndex = 140;
            this.labelDTThang9.Text = "0";
            this.labelDTThang9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang8
            // 
            this.labelDTThang8.AutoSize = true;
            this.labelDTThang8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang8.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang8.Location = new System.Drawing.Point(411, 312);
            this.labelDTThang8.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang8.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang8.Name = "labelDTThang8";
            this.labelDTThang8.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang8.TabIndex = 139;
            this.labelDTThang8.Text = "0";
            this.labelDTThang8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang7
            // 
            this.labelDTThang7.AutoSize = true;
            this.labelDTThang7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang7.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang7.Location = new System.Drawing.Point(411, 272);
            this.labelDTThang7.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang7.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang7.Name = "labelDTThang7";
            this.labelDTThang7.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang7.TabIndex = 138;
            this.labelDTThang7.Text = "0";
            this.labelDTThang7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang6
            // 
            this.labelDTThang6.AutoSize = true;
            this.labelDTThang6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang6.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang6.Location = new System.Drawing.Point(411, 232);
            this.labelDTThang6.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang6.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang6.Name = "labelDTThang6";
            this.labelDTThang6.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang6.TabIndex = 137;
            this.labelDTThang6.Text = "0";
            this.labelDTThang6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang5
            // 
            this.labelDTThang5.AutoSize = true;
            this.labelDTThang5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang5.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang5.Location = new System.Drawing.Point(411, 192);
            this.labelDTThang5.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang5.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang5.Name = "labelDTThang5";
            this.labelDTThang5.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang5.TabIndex = 136;
            this.labelDTThang5.Text = "0";
            this.labelDTThang5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang4
            // 
            this.labelDTThang4.AutoSize = true;
            this.labelDTThang4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang4.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang4.Location = new System.Drawing.Point(411, 152);
            this.labelDTThang4.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang4.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang4.Name = "labelDTThang4";
            this.labelDTThang4.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang4.TabIndex = 135;
            this.labelDTThang4.Text = "0";
            this.labelDTThang4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDTThang3
            // 
            this.labelDTThang3.AutoSize = true;
            this.labelDTThang3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang3.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang3.Location = new System.Drawing.Point(411, 112);
            this.labelDTThang3.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang3.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang3.Name = "labelDTThang3";
            this.labelDTThang3.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang3.TabIndex = 134;
            this.labelDTThang3.Text = "0";
            this.labelDTThang3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelSLSPKhachTra
            // 
            this.labelSLSPKhachTra.AutoSize = true;
            this.labelSLSPKhachTra.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPKhachTra.Location = new System.Drawing.Point(467, 460);
            this.labelSLSPKhachTra.Name = "labelSLSPKhachTra";
            this.labelSLSPKhachTra.Size = new System.Drawing.Size(256, 26);
            this.labelSLSPKhachTra.TabIndex = 82;
            this.labelSLSPKhachTra.Text = "SL sản phẩm khách trả:";
            // 
            // labelSLSPKhachTra_Text
            // 
            this.labelSLSPKhachTra_Text.AutoSize = true;
            this.labelSLSPKhachTra_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPKhachTra_Text.Location = new System.Drawing.Point(750, 460);
            this.labelSLSPKhachTra_Text.MaximumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPKhachTra_Text.MinimumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPKhachTra_Text.Name = "labelSLSPKhachTra_Text";
            this.labelSLSPKhachTra_Text.Size = new System.Drawing.Size(175, 27);
            this.labelSLSPKhachTra_Text.TabIndex = 83;
            this.labelSLSPKhachTra_Text.Text = "0";
            this.labelSLSPKhachTra_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelDTThang2
            // 
            this.labelDTThang2.AutoSize = true;
            this.labelDTThang2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang2.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang2.Location = new System.Drawing.Point(411, 72);
            this.labelDTThang2.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang2.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang2.Name = "labelDTThang2";
            this.labelDTThang2.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang2.TabIndex = 133;
            this.labelDTThang2.Text = "0";
            this.labelDTThang2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TenSP";
            this.dataGridViewTextBoxColumn1.HeaderText = "Tên SP";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "SoLuong";
            this.dataGridViewTextBoxColumn2.HeaderText = "SL";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // labelThang7
            // 
            this.labelThang7.AutoSize = true;
            this.labelThang7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang7.ForeColor = System.Drawing.Color.Black;
            this.labelThang7.Location = new System.Drawing.Point(5, 274);
            this.labelThang7.Name = "labelThang7";
            this.labelThang7.Size = new System.Drawing.Size(78, 23);
            this.labelThang7.TabIndex = 126;
            this.labelThang7.Text = "Tháng 7";
            // 
            // labelDTThang1
            // 
            this.labelDTThang1.AutoSize = true;
            this.labelDTThang1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDTThang1.ForeColor = System.Drawing.Color.Black;
            this.labelDTThang1.Location = new System.Drawing.Point(411, 32);
            this.labelDTThang1.MaximumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang1.MinimumSize = new System.Drawing.Size(177, 22);
            this.labelDTThang1.Name = "labelDTThang1";
            this.labelDTThang1.Size = new System.Drawing.Size(177, 22);
            this.labelDTThang1.TabIndex = 132;
            this.labelDTThang1.Text = "0";
            this.labelDTThang1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dataGridViewDSTTN
            // 
            this.dataGridViewDSTTN.AllowDrop = true;
            this.dataGridViewDSTTN.AllowUserToAddRows = false;
            this.dataGridViewDSTTN.AllowUserToOrderColumns = true;
            this.dataGridViewDSTTN.AllowUserToResizeColumns = false;
            this.dataGridViewDSTTN.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDSTTN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewDSTTN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSTTN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TenKhachHang,
            this.TongToa,
            this.KhachNo,
            this.NoKhach,
            this.TienGiamGia});
            this.dataGridViewDSTTN.Location = new System.Drawing.Point(5, 229);
            this.dataGridViewDSTTN.MultiSelect = false;
            this.dataGridViewDSTTN.Name = "dataGridViewDSTTN";
            this.dataGridViewDSTTN.ReadOnly = true;
            this.dataGridViewDSTTN.RowHeadersVisible = false;
            this.dataGridViewDSTTN.RowHeadersWidth = 51;
            this.dataGridViewDSTTN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewDSTTN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewDSTTN.RowTemplate.Height = 30;
            this.dataGridViewDSTTN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSTTN.Size = new System.Drawing.Size(444, 318);
            this.dataGridViewDSTTN.TabIndex = 46;
            // 
            // TenKhachHang
            // 
            this.TenKhachHang.DataPropertyName = "TenKhachHang";
            this.TenKhachHang.HeaderText = "Tên khách hàng";
            this.TenKhachHang.MinimumWidth = 6;
            this.TenKhachHang.Name = "TenKhachHang";
            this.TenKhachHang.ReadOnly = true;
            this.TenKhachHang.Width = 125;
            // 
            // TongToa
            // 
            this.TongToa.DataPropertyName = "TongToa";
            dataGridViewCellStyle7.Format = "C0";
            dataGridViewCellStyle7.NullValue = null;
            this.TongToa.DefaultCellStyle = dataGridViewCellStyle7;
            this.TongToa.HeaderText = "Tổng toa";
            this.TongToa.MinimumWidth = 6;
            this.TongToa.Name = "TongToa";
            this.TongToa.ReadOnly = true;
            this.TongToa.Width = 125;
            // 
            // KhachNo
            // 
            this.KhachNo.DataPropertyName = "KhachNo";
            dataGridViewCellStyle8.Format = "C0";
            dataGridViewCellStyle8.NullValue = null;
            this.KhachNo.DefaultCellStyle = dataGridViewCellStyle8;
            this.KhachNo.HeaderText = "Khách nợ";
            this.KhachNo.MinimumWidth = 6;
            this.KhachNo.Name = "KhachNo";
            this.KhachNo.ReadOnly = true;
            this.KhachNo.Width = 125;
            // 
            // NoKhach
            // 
            this.NoKhach.DataPropertyName = "NoKhach";
            dataGridViewCellStyle9.Format = "C0";
            dataGridViewCellStyle9.NullValue = null;
            this.NoKhach.DefaultCellStyle = dataGridViewCellStyle9;
            this.NoKhach.HeaderText = "Nợ khách";
            this.NoKhach.MinimumWidth = 6;
            this.NoKhach.Name = "NoKhach";
            this.NoKhach.ReadOnly = true;
            this.NoKhach.Width = 125;
            // 
            // TienGiamGia
            // 
            this.TienGiamGia.DataPropertyName = "TienGiamGia";
            dataGridViewCellStyle10.Format = "C0";
            dataGridViewCellStyle10.NullValue = null;
            this.TienGiamGia.DefaultCellStyle = dataGridViewCellStyle10;
            this.TienGiamGia.HeaderText = "Tiền giảm giá";
            this.TienGiamGia.MinimumWidth = 6;
            this.TienGiamGia.Name = "TienGiamGia";
            this.TienGiamGia.ReadOnly = true;
            this.TienGiamGia.Width = 125;
            // 
            // labelThang8
            // 
            this.labelThang8.AutoSize = true;
            this.labelThang8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang8.ForeColor = System.Drawing.Color.Black;
            this.labelThang8.Location = new System.Drawing.Point(5, 314);
            this.labelThang8.Name = "labelThang8";
            this.labelThang8.Size = new System.Drawing.Size(78, 23);
            this.labelThang8.TabIndex = 127;
            this.labelThang8.Text = "Tháng 8";
            // 
            // labelThang1
            // 
            this.labelThang1.AutoSize = true;
            this.labelThang1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang1.ForeColor = System.Drawing.Color.Black;
            this.labelThang1.Location = new System.Drawing.Point(5, 34);
            this.labelThang1.Name = "labelThang1";
            this.labelThang1.Size = new System.Drawing.Size(78, 23);
            this.labelThang1.TabIndex = 120;
            this.labelThang1.Text = "Tháng 1";
            // 
            // dataGridViewTKSP1
            // 
            this.dataGridViewTKSP1.AllowDrop = true;
            this.dataGridViewTKSP1.AllowUserToAddRows = false;
            this.dataGridViewTKSP1.AllowUserToOrderColumns = true;
            this.dataGridViewTKSP1.AllowUserToResizeColumns = false;
            this.dataGridViewTKSP1.AllowUserToResizeRows = false;
            this.dataGridViewTKSP1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTKSP1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTKSP1.Location = new System.Drawing.Point(360, 11);
            this.dataGridViewTKSP1.MultiSelect = false;
            this.dataGridViewTKSP1.Name = "dataGridViewTKSP1";
            this.dataGridViewTKSP1.ReadOnly = true;
            this.dataGridViewTKSP1.RowHeadersVisible = false;
            this.dataGridViewTKSP1.RowHeadersWidth = 51;
            this.dataGridViewTKSP1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewTKSP1.RowTemplate.Height = 30;
            this.dataGridViewTKSP1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTKSP1.Size = new System.Drawing.Size(52, 26);
            this.dataGridViewTKSP1.TabIndex = 61;
            this.dataGridViewTKSP1.Visible = false;
            // 
            // labelThang3
            // 
            this.labelThang3.AutoSize = true;
            this.labelThang3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang3.ForeColor = System.Drawing.Color.Black;
            this.labelThang3.Location = new System.Drawing.Point(5, 114);
            this.labelThang3.Name = "labelThang3";
            this.labelThang3.Size = new System.Drawing.Size(78, 23);
            this.labelThang3.TabIndex = 122;
            this.labelThang3.Text = "Tháng 3";
            // 
            // labelThang2
            // 
            this.labelThang2.AutoSize = true;
            this.labelThang2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang2.ForeColor = System.Drawing.Color.Black;
            this.labelThang2.Location = new System.Drawing.Point(5, 74);
            this.labelThang2.Name = "labelThang2";
            this.labelThang2.Size = new System.Drawing.Size(78, 23);
            this.labelThang2.TabIndex = 121;
            this.labelThang2.Text = "Tháng 2";
            // 
            // dataGridViewSL
            // 
            this.dataGridViewSL.AllowDrop = true;
            this.dataGridViewSL.AllowUserToAddRows = false;
            this.dataGridViewSL.AllowUserToOrderColumns = true;
            this.dataGridViewSL.AllowUserToResizeColumns = false;
            this.dataGridViewSL.AllowUserToResizeRows = false;
            this.dataGridViewSL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dataGridViewSL.Location = new System.Drawing.Point(281, 11);
            this.dataGridViewSL.MultiSelect = false;
            this.dataGridViewSL.Name = "dataGridViewSL";
            this.dataGridViewSL.ReadOnly = true;
            this.dataGridViewSL.RowHeadersVisible = false;
            this.dataGridViewSL.RowHeadersWidth = 51;
            this.dataGridViewSL.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewSL.RowTemplate.Height = 30;
            this.dataGridViewSL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSL.Size = new System.Drawing.Size(70, 26);
            this.dataGridViewSL.TabIndex = 62;
            this.dataGridViewSL.Visible = false;
            // 
            // dateTimePickerNgay1
            // 
            this.dateTimePickerNgay1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerNgay1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerNgay1.Location = new System.Drawing.Point(82, 7);
            this.dateTimePickerNgay1.Name = "dateTimePickerNgay1";
            this.dateTimePickerNgay1.Size = new System.Drawing.Size(177, 27);
            this.dateTimePickerNgay1.TabIndex = 78;
            this.dateTimePickerNgay1.Value = new System.DateTime(2020, 2, 15, 0, 0, 0, 0);
            this.dateTimePickerNgay1.ValueChanged += new System.EventHandler(this.dateTimePickerNgay1_ValueChanged);
            // 
            // labelTongKetNgay
            // 
            this.labelTongKetNgay.AutoSize = true;
            this.labelTongKetNgay.BackColor = System.Drawing.Color.Transparent;
            this.labelTongKetNgay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongKetNgay.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTongKetNgay.Location = new System.Drawing.Point(467, 370);
            this.labelTongKetNgay.Name = "labelTongKetNgay";
            this.labelTongKetNgay.Size = new System.Drawing.Size(212, 26);
            this.labelTongKetNgay.TabIndex = 76;
            this.labelTongKetNgay.Text = "TỔNG KẾT NGÀY";
            // 
            // labelSLSPNhapKho
            // 
            this.labelSLSPNhapKho.AutoSize = true;
            this.labelSLSPNhapKho.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapKho.Location = new System.Drawing.Point(467, 400);
            this.labelSLSPNhapKho.Name = "labelSLSPNhapKho";
            this.labelSLSPNhapKho.Size = new System.Drawing.Size(252, 26);
            this.labelSLSPNhapKho.TabIndex = 71;
            this.labelSLSPNhapKho.Text = "SL sản phẩm nhập kho:";
            // 
            // labelSLSPNhapKho_Text
            // 
            this.labelSLSPNhapKho_Text.AutoSize = true;
            this.labelSLSPNhapKho_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapKho_Text.Location = new System.Drawing.Point(750, 400);
            this.labelSLSPNhapKho_Text.MaximumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPNhapKho_Text.MinimumSize = new System.Drawing.Size(175, 27);
            this.labelSLSPNhapKho_Text.Name = "labelSLSPNhapKho_Text";
            this.labelSLSPNhapKho_Text.Size = new System.Drawing.Size(175, 27);
            this.labelSLSPNhapKho_Text.TabIndex = 72;
            this.labelSLSPNhapKho_Text.Text = "0";
            this.labelSLSPNhapKho_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelThang9
            // 
            this.labelThang9.AutoSize = true;
            this.labelThang9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang9.ForeColor = System.Drawing.Color.Black;
            this.labelThang9.Location = new System.Drawing.Point(5, 354);
            this.labelThang9.Name = "labelThang9";
            this.labelThang9.Size = new System.Drawing.Size(78, 23);
            this.labelThang9.TabIndex = 128;
            this.labelThang9.Text = "Tháng 9";
            // 
            // labelThang6
            // 
            this.labelThang6.AutoSize = true;
            this.labelThang6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang6.ForeColor = System.Drawing.Color.Black;
            this.labelThang6.Location = new System.Drawing.Point(5, 234);
            this.labelThang6.Name = "labelThang6";
            this.labelThang6.Size = new System.Drawing.Size(78, 23);
            this.labelThang6.TabIndex = 125;
            this.labelThang6.Text = "Tháng 6";
            // 
            // labelThang5
            // 
            this.labelThang5.AutoSize = true;
            this.labelThang5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang5.ForeColor = System.Drawing.Color.Black;
            this.labelThang5.Location = new System.Drawing.Point(5, 194);
            this.labelThang5.Name = "labelThang5";
            this.labelThang5.Size = new System.Drawing.Size(78, 23);
            this.labelThang5.TabIndex = 124;
            this.labelThang5.Text = "Tháng 5";
            // 
            // labelThang4
            // 
            this.labelThang4.AutoSize = true;
            this.labelThang4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThang4.ForeColor = System.Drawing.Color.Black;
            this.labelThang4.Location = new System.Drawing.Point(5, 154);
            this.labelThang4.Name = "labelThang4";
            this.labelThang4.Size = new System.Drawing.Size(78, 23);
            this.labelThang4.TabIndex = 123;
            this.labelThang4.Text = "Tháng 4";
            // 
            // labelSLSPDaBanNam
            // 
            this.labelSLSPDaBanNam.AutoSize = true;
            this.labelSLSPDaBanNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBanNam.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPDaBanNam.Location = new System.Drawing.Point(2, 30);
            this.labelSLSPDaBanNam.Name = "labelSLSPDaBanNam";
            this.labelSLSPDaBanNam.Size = new System.Drawing.Size(112, 25);
            this.labelSLSPDaBanNam.TabIndex = 243;
            this.labelSLSPDaBanNam.Text = "SLSP bán:";
            // 
            // groupBoxBanHang
            // 
            this.groupBoxBanHang.Controls.Add(this.labelLoiNhuanBHNam);
            this.groupBoxBanHang.Controls.Add(this.labelLoiNhuanBHNam_Text);
            this.groupBoxBanHang.Controls.Add(this.labelSLSPTra);
            this.groupBoxBanHang.Controls.Add(this.labelSLSPTra_Text);
            this.groupBoxBanHang.Controls.Add(this.labelSLSPDaBanNam);
            this.groupBoxBanHang.Controls.Add(this.labelSLSPDaBanNam_Text);
            this.groupBoxBanHang.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxBanHang.Location = new System.Drawing.Point(16, 0);
            this.groupBoxBanHang.Name = "groupBoxBanHang";
            this.groupBoxBanHang.Size = new System.Drawing.Size(360, 124);
            this.groupBoxBanHang.TabIndex = 232;
            this.groupBoxBanHang.TabStop = false;
            this.groupBoxBanHang.Text = "BÁN HÀNG";
            this.groupBoxBanHang.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxBanHang_Paint);
            // 
            // labelLoiNhuanBHNam
            // 
            this.labelLoiNhuanBHNam.AutoSize = true;
            this.labelLoiNhuanBHNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiNhuanBHNam.ForeColor = System.Drawing.Color.Black;
            this.labelLoiNhuanBHNam.Location = new System.Drawing.Point(2, 90);
            this.labelLoiNhuanBHNam.Name = "labelLoiNhuanBHNam";
            this.labelLoiNhuanBHNam.Size = new System.Drawing.Size(155, 25);
            this.labelLoiNhuanBHNam.TabIndex = 251;
            this.labelLoiNhuanBHNam.Text = "Lợi nhuận BH:";
            // 
            // labelLoiNhuanBHNam_Text
            // 
            this.labelLoiNhuanBHNam_Text.AutoSize = true;
            this.labelLoiNhuanBHNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiNhuanBHNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelLoiNhuanBHNam_Text.Location = new System.Drawing.Point(161, 90);
            this.labelLoiNhuanBHNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelLoiNhuanBHNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelLoiNhuanBHNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelLoiNhuanBHNam_Text.Name = "labelLoiNhuanBHNam_Text";
            this.labelLoiNhuanBHNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelLoiNhuanBHNam_Text.TabIndex = 249;
            this.labelLoiNhuanBHNam_Text.Text = "0";
            this.labelLoiNhuanBHNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPTra
            // 
            this.labelSLSPTra.AutoSize = true;
            this.labelSLSPTra.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPTra.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPTra.Location = new System.Drawing.Point(2, 60);
            this.labelSLSPTra.Name = "labelSLSPTra";
            this.labelSLSPTra.Size = new System.Drawing.Size(104, 25);
            this.labelSLSPTra.TabIndex = 244;
            this.labelSLSPTra.Text = "SLSP trả:";
            // 
            // labelSLSPTra_Text
            // 
            this.labelSLSPTra_Text.AutoSize = true;
            this.labelSLSPTra_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPTra_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPTra_Text.Location = new System.Drawing.Point(161, 60);
            this.labelSLSPTra_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelSLSPTra_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPTra_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPTra_Text.Name = "labelSLSPTra_Text";
            this.labelSLSPTra_Text.Size = new System.Drawing.Size(195, 27);
            this.labelSLSPTra_Text.TabIndex = 245;
            this.labelSLSPTra_Text.Text = "0";
            this.labelSLSPTra_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPDaBanNam_Text
            // 
            this.labelSLSPDaBanNam_Text.AutoSize = true;
            this.labelSLSPDaBanNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPDaBanNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPDaBanNam_Text.Location = new System.Drawing.Point(161, 30);
            this.labelSLSPDaBanNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelSLSPDaBanNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPDaBanNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPDaBanNam_Text.Name = "labelSLSPDaBanNam_Text";
            this.labelSLSPDaBanNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelSLSPDaBanNam_Text.TabIndex = 236;
            this.labelSLSPDaBanNam_Text.Text = "0";
            this.labelSLSPDaBanNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBoxNhapKhoLuong
            // 
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelLuongNV);
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelLuongNV_Text);
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelTienNhapKhoNam);
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelTienNhapKhoNam_Text);
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelSLSPNhapNam);
            this.groupBoxNhapKhoLuong.Controls.Add(this.labelSLSPNhapNam_Text);
            this.groupBoxNhapKhoLuong.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxNhapKhoLuong.Location = new System.Drawing.Point(16, 149);
            this.groupBoxNhapKhoLuong.Name = "groupBoxNhapKhoLuong";
            this.groupBoxNhapKhoLuong.Size = new System.Drawing.Size(360, 124);
            this.groupBoxNhapKhoLuong.TabIndex = 244;
            this.groupBoxNhapKhoLuong.TabStop = false;
            this.groupBoxNhapKhoLuong.Text = "NHẬP KHO - LƯƠNG";
            this.groupBoxNhapKhoLuong.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxNhapKhoLuong_Paint);
            // 
            // labelLuongNV
            // 
            this.labelLuongNV.AutoSize = true;
            this.labelLuongNV.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongNV.ForeColor = System.Drawing.Color.Black;
            this.labelLuongNV.Location = new System.Drawing.Point(2, 90);
            this.labelLuongNV.Name = "labelLuongNV";
            this.labelLuongNV.Size = new System.Drawing.Size(117, 25);
            this.labelLuongNV.TabIndex = 243;
            this.labelLuongNV.Text = "Lương NV:";
            // 
            // labelLuongNV_Text
            // 
            this.labelLuongNV_Text.AutoSize = true;
            this.labelLuongNV_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongNV_Text.ForeColor = System.Drawing.Color.Black;
            this.labelLuongNV_Text.Location = new System.Drawing.Point(161, 90);
            this.labelLuongNV_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelLuongNV_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelLuongNV_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelLuongNV_Text.Name = "labelLuongNV_Text";
            this.labelLuongNV_Text.Size = new System.Drawing.Size(195, 27);
            this.labelLuongNV_Text.TabIndex = 244;
            this.labelLuongNV_Text.Text = "0";
            this.labelLuongNV_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTienNhapKhoNam
            // 
            this.labelTienNhapKhoNam.AutoSize = true;
            this.labelTienNhapKhoNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienNhapKhoNam.ForeColor = System.Drawing.Color.Black;
            this.labelTienNhapKhoNam.Location = new System.Drawing.Point(2, 30);
            this.labelTienNhapKhoNam.Name = "labelTienNhapKhoNam";
            this.labelTienNhapKhoNam.Size = new System.Drawing.Size(156, 25);
            this.labelTienNhapKhoNam.TabIndex = 240;
            this.labelTienNhapKhoNam.Text = "Tiền nhập kho:";
            // 
            // labelTienNhapKhoNam_Text
            // 
            this.labelTienNhapKhoNam_Text.AutoSize = true;
            this.labelTienNhapKhoNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienNhapKhoNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTienNhapKhoNam_Text.Location = new System.Drawing.Point(161, 30);
            this.labelTienNhapKhoNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelTienNhapKhoNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelTienNhapKhoNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelTienNhapKhoNam_Text.Name = "labelTienNhapKhoNam_Text";
            this.labelTienNhapKhoNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelTienNhapKhoNam_Text.TabIndex = 241;
            this.labelTienNhapKhoNam_Text.Text = "0";
            this.labelTienNhapKhoNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSPNhapNam
            // 
            this.labelSLSPNhapNam.AutoSize = true;
            this.labelSLSPNhapNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapNam.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPNhapNam.Location = new System.Drawing.Point(2, 60);
            this.labelSLSPNhapNam.Name = "labelSLSPNhapNam";
            this.labelSLSPNhapNam.Size = new System.Drawing.Size(124, 25);
            this.labelSLSPNhapNam.TabIndex = 213;
            this.labelSLSPNhapNam.Text = "SLSP nhập:";
            // 
            // labelSLSPNhapNam_Text
            // 
            this.labelSLSPNhapNam_Text.AutoSize = true;
            this.labelSLSPNhapNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSPNhapNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLSPNhapNam_Text.Location = new System.Drawing.Point(161, 60);
            this.labelSLSPNhapNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelSLSPNhapNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPNhapNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelSLSPNhapNam_Text.Name = "labelSLSPNhapNam_Text";
            this.labelSLSPNhapNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelSLSPNhapNam_Text.TabIndex = 216;
            this.labelSLSPNhapNam_Text.Text = "0";
            this.labelSLSPNhapNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNoKhachNam
            // 
            this.labelNoKhachNam.AutoSize = true;
            this.labelNoKhachNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhachNam.ForeColor = System.Drawing.Color.Black;
            this.labelNoKhachNam.Location = new System.Drawing.Point(2, 120);
            this.labelNoKhachNam.Name = "labelNoKhachNam";
            this.labelNoKhachNam.Size = new System.Drawing.Size(110, 25);
            this.labelNoKhachNam.TabIndex = 221;
            this.labelNoKhachNam.Text = "Nợ khách:";
            // 
            // labelNoKhachNam_Text
            // 
            this.labelNoKhachNam_Text.AutoSize = true;
            this.labelNoKhachNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhachNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelNoKhachNam_Text.Location = new System.Drawing.Point(161, 120);
            this.labelNoKhachNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelNoKhachNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelNoKhachNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelNoKhachNam_Text.Name = "labelNoKhachNam_Text";
            this.labelNoKhachNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelNoKhachNam_Text.TabIndex = 223;
            this.labelNoKhachNam_Text.Text = "0";
            this.labelNoKhachNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachNoNam
            // 
            this.labelKhachNoNam.AutoSize = true;
            this.labelKhachNoNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNoNam.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNoNam.Location = new System.Drawing.Point(2, 90);
            this.labelKhachNoNam.Name = "labelKhachNoNam";
            this.labelKhachNoNam.Size = new System.Drawing.Size(112, 25);
            this.labelKhachNoNam.TabIndex = 220;
            this.labelKhachNoNam.Text = "Khách nợ:";
            // 
            // groupBoxLuong
            // 
            this.groupBoxLuong.Controls.Add(this.pictureBox3);
            this.groupBoxLuong.Controls.Add(this.pictureBox2);
            this.groupBoxLuong.Controls.Add(this.pictureBox1);
            this.groupBoxLuong.Controls.Add(this.label17);
            this.groupBoxLuong.Controls.Add(this.labelTongDTNam);
            this.groupBoxLuong.Controls.Add(this.labelTongLoiNhuanCaNam);
            this.groupBoxLuong.Controls.Add(this.labelTongGiamGiaNam);
            this.groupBoxLuong.Controls.Add(this.labelTongGiamGiaNam_Text);
            this.groupBoxLuong.Controls.Add(this.labelTongDTNam_Text);
            this.groupBoxLuong.Controls.Add(this.labelKhachNoNam);
            this.groupBoxLuong.Controls.Add(this.labelNoKhachNam);
            this.groupBoxLuong.Controls.Add(this.labelNoKhachNam_Text);
            this.groupBoxLuong.Controls.Add(this.labelKhachNoNam_Text);
            this.groupBoxLuong.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxLuong.Location = new System.Drawing.Point(16, 297);
            this.groupBoxLuong.Name = "groupBoxLuong";
            this.groupBoxLuong.Size = new System.Drawing.Size(360, 208);
            this.groupBoxLuong.TabIndex = 245;
            this.groupBoxLuong.TabStop = false;
            this.groupBoxLuong.Text = "DOANH THU";
            this.groupBoxLuong.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxDoanhThu_Paint);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(91, 159);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(42, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 251;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(48, 159);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(42, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 250;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(5, 159);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 249;
            this.pictureBox1.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(287, 172);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 26);
            this.label17.TabIndex = 248;
            this.label17.Text = "VNĐ";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongDTNam
            // 
            this.labelTongDTNam.AutoSize = true;
            this.labelTongDTNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDTNam.ForeColor = System.Drawing.Color.Black;
            this.labelTongDTNam.Location = new System.Drawing.Point(2, 30);
            this.labelTongDTNam.Name = "labelTongDTNam";
            this.labelTongDTNam.Size = new System.Drawing.Size(103, 25);
            this.labelTongDTNam.TabIndex = 240;
            this.labelTongDTNam.Text = "Tổng DT:";
            // 
            // labelTongLoiNhuanCaNam
            // 
            this.labelTongLoiNhuanCaNam.AutoSize = true;
            this.labelTongLoiNhuanCaNam.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongLoiNhuanCaNam.ForeColor = System.Drawing.Color.Red;
            this.labelTongLoiNhuanCaNam.Location = new System.Drawing.Point(159, 172);
            this.labelTongLoiNhuanCaNam.MaximumSize = new System.Drawing.Size(132, 26);
            this.labelTongLoiNhuanCaNam.MinimumSize = new System.Drawing.Size(132, 26);
            this.labelTongLoiNhuanCaNam.Name = "labelTongLoiNhuanCaNam";
            this.labelTongLoiNhuanCaNam.Size = new System.Drawing.Size(132, 26);
            this.labelTongLoiNhuanCaNam.TabIndex = 247;
            this.labelTongLoiNhuanCaNam.Text = "1000000000";
            this.labelTongLoiNhuanCaNam.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongGiamGiaNam
            // 
            this.labelTongGiamGiaNam.AutoSize = true;
            this.labelTongGiamGiaNam.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGiaNam.ForeColor = System.Drawing.Color.Black;
            this.labelTongGiamGiaNam.Location = new System.Drawing.Point(2, 60);
            this.labelTongGiamGiaNam.Name = "labelTongGiamGiaNam";
            this.labelTongGiamGiaNam.Size = new System.Drawing.Size(154, 25);
            this.labelTongGiamGiaNam.TabIndex = 242;
            this.labelTongGiamGiaNam.Text = "Tổng giảm giá:";
            // 
            // labelTongGiamGiaNam_Text
            // 
            this.labelTongGiamGiaNam_Text.AutoSize = true;
            this.labelTongGiamGiaNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongGiamGiaNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongGiamGiaNam_Text.Location = new System.Drawing.Point(161, 60);
            this.labelTongGiamGiaNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelTongGiamGiaNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelTongGiamGiaNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelTongGiamGiaNam_Text.Name = "labelTongGiamGiaNam_Text";
            this.labelTongGiamGiaNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelTongGiamGiaNam_Text.TabIndex = 243;
            this.labelTongGiamGiaNam_Text.Text = "0";
            this.labelTongGiamGiaNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongDTNam_Text
            // 
            this.labelTongDTNam_Text.AutoSize = true;
            this.labelTongDTNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongDTNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongDTNam_Text.Location = new System.Drawing.Point(161, 30);
            this.labelTongDTNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelTongDTNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelTongDTNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelTongDTNam_Text.Name = "labelTongDTNam_Text";
            this.labelTongDTNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelTongDTNam_Text.TabIndex = 241;
            this.labelTongDTNam_Text.Text = "0";
            this.labelTongDTNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachNoNam_Text
            // 
            this.labelKhachNoNam_Text.AutoSize = true;
            this.labelKhachNoNam_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNoNam_Text.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNoNam_Text.Location = new System.Drawing.Point(161, 90);
            this.labelKhachNoNam_Text.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelKhachNoNam_Text.MaximumSize = new System.Drawing.Size(195, 27);
            this.labelKhachNoNam_Text.MinimumSize = new System.Drawing.Size(195, 27);
            this.labelKhachNoNam_Text.Name = "labelKhachNoNam_Text";
            this.labelKhachNoNam_Text.Size = new System.Drawing.Size(195, 27);
            this.labelKhachNoNam_Text.TabIndex = 222;
            this.labelKhachNoNam_Text.Text = "0";
            this.labelKhachNoNam_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBoxTKNam
            // 
            this.groupBoxTKNam.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBoxTKNam.Controls.Add(this.groupBoxLuong);
            this.groupBoxTKNam.Controls.Add(this.groupBoxNhapKhoLuong);
            this.groupBoxTKNam.Controls.Add(this.groupBoxBanHang);
            this.groupBoxTKNam.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxTKNam.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxTKNam.Location = new System.Drawing.Point(600, 43);
            this.groupBoxTKNam.Name = "groupBoxTKNam";
            this.groupBoxTKNam.Size = new System.Drawing.Size(426, 505);
            this.groupBoxTKNam.TabIndex = 191;
            this.groupBoxTKNam.TabStop = false;
            this.groupBoxTKNam.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxTKNam_Paint);
            // 
            // panelNam
            // 
            this.panelNam.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panelNam.Controls.Add(this.groupBoxTKNam);
            this.panelNam.Controls.Add(this.dateTimePickerNam);
            this.panelNam.Controls.Add(this.panelTest);
            this.panelNam.Controls.Add(this.dataGridViewNam);
            this.panelNam.Controls.Add(this.groupBoxBieuDoTangTruongHangThang);
            this.panelNam.Controls.Add(this.labelNam);
            this.panelNam.Location = new System.Drawing.Point(258, 35);
            this.panelNam.Name = "panelNam";
            this.panelNam.Size = new System.Drawing.Size(979, 550);
            this.panelNam.TabIndex = 89;
            this.panelNam.Visible = false;
            // 
            // dateTimePickerNam
            // 
            this.dateTimePickerNam.AllowDrop = true;
            this.dateTimePickerNam.CustomFormat = "yyyyy";
            this.dateTimePickerNam.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerNam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerNam.Location = new System.Drawing.Point(114, 6);
            this.dateTimePickerNam.Name = "dateTimePickerNam";
            this.dateTimePickerNam.ShowUpDown = true;
            this.dateTimePickerNam.Size = new System.Drawing.Size(84, 28);
            this.dateTimePickerNam.TabIndex = 109;
            this.dateTimePickerNam.Value = new System.DateTime(2020, 1, 10, 0, 0, 0, 0);
            this.dateTimePickerNam.ValueChanged += new System.EventHandler(this.dateTimePickerNam_ValueChanged);
            // 
            // panelTest
            // 
            this.panelTest.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panelTest.Location = new System.Drawing.Point(366, 2);
            this.panelTest.Name = "panelTest";
            this.panelTest.Size = new System.Drawing.Size(330, 25);
            this.panelTest.TabIndex = 109;
            this.panelTest.Visible = false;
            // 
            // dataGridViewNam
            // 
            this.dataGridViewNam.AllowDrop = true;
            this.dataGridViewNam.AllowUserToAddRows = false;
            this.dataGridViewNam.AllowUserToDeleteRows = false;
            this.dataGridViewNam.AllowUserToResizeColumns = false;
            this.dataGridViewNam.AllowUserToResizeRows = false;
            this.dataGridViewNam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNam.Location = new System.Drawing.Point(136, 6);
            this.dataGridViewNam.Name = "dataGridViewNam";
            this.dataGridViewNam.RowHeadersVisible = false;
            this.dataGridViewNam.RowHeadersWidth = 51;
            this.dataGridViewNam.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewNam.RowTemplate.Height = 24;
            this.dataGridViewNam.Size = new System.Drawing.Size(29, 26);
            this.dataGridViewNam.TabIndex = 190;
            this.dataGridViewNam.Visible = false;
            // 
            // groupBoxBieuDoTangTruongHangThang
            // 
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang12);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang11);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang10);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang12);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang8);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang11);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang4);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang10);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang7);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang9);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang3);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang6);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang2);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang5);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.panelThang1);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang12);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang11);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang10);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang9);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang8);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang7);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang6);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang5);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang4);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang3);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang2);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelDTThang1);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang9);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang8);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang7);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang6);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang5);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang4);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang3);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang2);
            this.groupBoxBieuDoTangTruongHangThang.Controls.Add(this.labelThang1);
            this.groupBoxBieuDoTangTruongHangThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxBieuDoTangTruongHangThang.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxBieuDoTangTruongHangThang.Location = new System.Drawing.Point(5, 43);
            this.groupBoxBieuDoTangTruongHangThang.Name = "groupBoxBieuDoTangTruongHangThang";
            this.groupBoxBieuDoTangTruongHangThang.Size = new System.Drawing.Size(601, 505);
            this.groupBoxBieuDoTangTruongHangThang.TabIndex = 0;
            this.groupBoxBieuDoTangTruongHangThang.TabStop = false;
            this.groupBoxBieuDoTangTruongHangThang.Text = "BIỂU ĐỒ DOANH THU TỪNG THÁNG";
            this.groupBoxBieuDoTangTruongHangThang.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxBieuDoTangTruongHangThang_Paint);
            // 
            // labelNam
            // 
            this.labelNam.AutoSize = true;
            this.labelNam.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNam.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNam.Location = new System.Drawing.Point(13, 8);
            this.labelNam.Name = "labelNam";
            this.labelNam.Size = new System.Drawing.Size(68, 26);
            this.labelNam.TabIndex = 108;
            this.labelNam.Text = "Năm:";
            // 
            // panelDoanhThuNgay
            // 
            this.panelDoanhThuNgay.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panelDoanhThuNgay.Controls.Add(this.dataGridViewTKSP1);
            this.panelDoanhThuNgay.Controls.Add(this.panelNgayMau);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPKhachTra);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPKhachTra_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPDaBan);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPDaBan_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelLaiTuSPBanDuoc);
            this.panelDoanhThuNgay.Controls.Add(this.labelLaiTuSPBanDuoc_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongTienNhapKho);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongTienNhapKho_Text);
            this.panelDoanhThuNgay.Controls.Add(this.dataGridViewSL);
            this.panelDoanhThuNgay.Controls.Add(this.dateTimePickerNgay1);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongKetNgay);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPNhapKho);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLSPNhapKho_Text);
            this.panelDoanhThuNgay.Controls.Add(this.groupBoxTKSP1);
            this.panelDoanhThuNgay.Controls.Add(this.labelNoKhach);
            this.panelDoanhThuNgay.Controls.Add(this.labelNoKhach_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelKhachNo);
            this.panelDoanhThuNgay.Controls.Add(this.labelKhachNo_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongGiamGia);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongGiamGia_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongDoanhThu);
            this.panelDoanhThuNgay.Controls.Add(this.labelTongDoanhThu_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLToa);
            this.panelDoanhThuNgay.Controls.Add(this.labelSLToa_Text);
            this.panelDoanhThuNgay.Controls.Add(this.labelDSTTN);
            this.panelDoanhThuNgay.Controls.Add(this.labelNgay);
            this.panelDoanhThuNgay.Controls.Add(this.dataGridViewDSTTN);
            this.panelDoanhThuNgay.Location = new System.Drawing.Point(258, 35);
            this.panelDoanhThuNgay.Name = "panelDoanhThuNgay";
            this.panelDoanhThuNgay.Size = new System.Drawing.Size(979, 550);
            this.panelDoanhThuNgay.TabIndex = 88;
            this.panelDoanhThuNgay.Visible = false;
            // 
            // panelNgayMau
            // 
            this.panelNgayMau.BackColor = System.Drawing.Color.LightBlue;
            this.panelNgayMau.Location = new System.Drawing.Point(622, 317);
            this.panelNgayMau.Name = "panelNgayMau";
            this.panelNgayMau.Size = new System.Drawing.Size(300, 38);
            this.panelNgayMau.TabIndex = 88;
            this.panelNgayMau.Visible = false;
            // 
            // buttonNam
            // 
            this.buttonNam.BackColor = System.Drawing.Color.SandyBrown;
            this.buttonNam.FlatAppearance.BorderSize = 0;
            this.buttonNam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNam.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonNam.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonNam.Image = ((System.Drawing.Image)(resources.GetObject("buttonNam.Image")));
            this.buttonNam.Location = new System.Drawing.Point(0, 404);
            this.buttonNam.Name = "buttonNam";
            this.buttonNam.Size = new System.Drawing.Size(250, 184);
            this.buttonNam.TabIndex = 87;
            this.buttonNam.Text = "Doanh thu   theo năm";
            this.buttonNam.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonNam.UseVisualStyleBackColor = false;
            this.buttonNam.Click += new System.EventHandler(this.buttonNam_Click);
            // 
            // buttonDoanhThuTrongNgay
            // 
            this.buttonDoanhThuTrongNgay.BackColor = System.Drawing.Color.SandyBrown;
            this.buttonDoanhThuTrongNgay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDoanhThuTrongNgay.FlatAppearance.BorderSize = 0;
            this.buttonDoanhThuTrongNgay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDoanhThuTrongNgay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonDoanhThuTrongNgay.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonDoanhThuTrongNgay.Image = ((System.Drawing.Image)(resources.GetObject("buttonDoanhThuTrongNgay.Image")));
            this.buttonDoanhThuTrongNgay.Location = new System.Drawing.Point(0, 35);
            this.buttonDoanhThuTrongNgay.Name = "buttonDoanhThuTrongNgay";
            this.buttonDoanhThuTrongNgay.Size = new System.Drawing.Size(250, 184);
            this.buttonDoanhThuTrongNgay.TabIndex = 86;
            this.buttonDoanhThuTrongNgay.Text = "Doanh thu trong ngày";
            this.buttonDoanhThuTrongNgay.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonDoanhThuTrongNgay.UseVisualStyleBackColor = false;
            this.buttonDoanhThuTrongNgay.Click += new System.EventHandler(this.buttonDoanhThuTrongNgay_Click);
            // 
            // buttonDoanhThuThang
            // 
            this.buttonDoanhThuThang.BackColor = System.Drawing.Color.SandyBrown;
            this.buttonDoanhThuThang.FlatAppearance.BorderSize = 0;
            this.buttonDoanhThuThang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDoanhThuThang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonDoanhThuThang.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonDoanhThuThang.Image = ((System.Drawing.Image)(resources.GetObject("buttonDoanhThuThang.Image")));
            this.buttonDoanhThuThang.Location = new System.Drawing.Point(0, 219);
            this.buttonDoanhThuThang.Name = "buttonDoanhThuThang";
            this.buttonDoanhThuThang.Size = new System.Drawing.Size(250, 184);
            this.buttonDoanhThuThang.TabIndex = 85;
            this.buttonDoanhThuThang.Text = "Doanh thu   theo tháng";
            this.buttonDoanhThuThang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonDoanhThuThang.UseVisualStyleBackColor = false;
            this.buttonDoanhThuThang.Click += new System.EventHandler(this.buttonDoanhThuThang_Click);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 82;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // formQuanLyDoanhThuBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1236, 588);
            this.Controls.Add(this.buttonNam);
            this.Controls.Add(this.buttonDoanhThuTrongNgay);
            this.Controls.Add(this.buttonDoanhThuThang);
            this.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.panelDoanhThuThang);
            this.Controls.Add(this.panelNam);
            this.Controls.Add(this.panelDoanhThuNgay);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formQuanLyDoanhThuBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formQuanLyDoanhThuBanHang";
            this.panelDoanhThuThang.ResumeLayout(false);
            this.panelDoanhThuThang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHangTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThang)).EndInit();
            this.groupBoxTongKetThang.ResumeLayout(false);
            this.groupBoxTongKetThang.PerformLayout();
            this.groupBoxTKSP1.ResumeLayout(false);
            this.panelNgay.ResumeLayout(false);
            this.panelNgay.PerformLayout();
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSTTN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTKSP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSL)).EndInit();
            this.groupBoxBanHang.ResumeLayout(false);
            this.groupBoxBanHang.PerformLayout();
            this.groupBoxNhapKhoLuong.ResumeLayout(false);
            this.groupBoxNhapKhoLuong.PerformLayout();
            this.groupBoxLuong.ResumeLayout(false);
            this.groupBoxLuong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxTKNam.ResumeLayout(false);
            this.panelNam.ResumeLayout(false);
            this.panelNam.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNam)).EndInit();
            this.groupBoxBieuDoTangTruongHangThang.ResumeLayout(false);
            this.groupBoxBieuDoTangTruongHangThang.PerformLayout();
            this.panelDoanhThuNgay.ResumeLayout(false);
            this.panelDoanhThuNgay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelDoanhThuThang;
        private System.Windows.Forms.GroupBox groupBoxTongKetThang;
        private System.Windows.Forms.Label labelThang12;
        private System.Windows.Forms.Label labelThang11;
        private System.Windows.Forms.Label labelThang10;
        private System.Windows.Forms.Panel panelThang12;
        private System.Windows.Forms.Panel panelThang8;
        private System.Windows.Forms.Label labelNgay;
        private System.Windows.Forms.Panel panelThang11;
        private System.Windows.Forms.Panel panelThang4;
        private System.Windows.Forms.Panel panelThang7;
        private System.Windows.Forms.Panel panelThang10;
        private System.Windows.Forms.GroupBox groupBoxTKSP1;
        private System.Windows.Forms.Label labelNoKhach;
        private System.Windows.Forms.Label labelNoKhach_Text;
        private System.Windows.Forms.Label labelKhachNo;
        private System.Windows.Forms.Label labelKhachNo_Text;
        private System.Windows.Forms.Label labelTongGiamGia;
        private System.Windows.Forms.Label labelTongGiamGia_Text;
        private System.Windows.Forms.Label labelTongDoanhThu;
        private System.Windows.Forms.Label labelTongDoanhThu_Text;
        private System.Windows.Forms.Label labelSLToa;
        private System.Windows.Forms.Label labelSLToa_Text;
        private System.Windows.Forms.Label labelDSTTN;
        private System.Windows.Forms.Panel panelThang9;
        private System.Windows.Forms.Label labelTongTienNhapKho;
        private System.Windows.Forms.Label labelTongTienNhapKho_Text;
        private System.Windows.Forms.Panel panelThang3;
        private System.Windows.Forms.Panel panelThang6;
        private System.Windows.Forms.Label labelSLSPDaBan;
        private System.Windows.Forms.Label labelSLSPDaBan_Text;
        private System.Windows.Forms.Label labelLaiTuSPBanDuoc;
        private System.Windows.Forms.Label labelLaiTuSPBanDuoc_Text;
        private System.Windows.Forms.Panel panelThang2;
        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Panel panelThang5;
        private System.Windows.Forms.Panel panelThang1;
        private System.Windows.Forms.Label labelDTThang12;
        private System.Windows.Forms.Label labelDTThang11;
        private System.Windows.Forms.Label labelDTThang10;
        private System.Windows.Forms.Label labelDTThang9;
        private System.Windows.Forms.Label labelDTThang8;
        private System.Windows.Forms.Label labelDTThang7;
        private System.Windows.Forms.Label labelDTThang6;
        private System.Windows.Forms.Label labelDTThang5;
        private System.Windows.Forms.Label labelDTThang4;
        private System.Windows.Forms.Label labelDTThang3;
        private System.Windows.Forms.Label labelSLSPKhachTra;
        private System.Windows.Forms.Label labelSLSPKhachTra_Text;
        private System.Windows.Forms.Label labelDTThang2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Label labelThang7;
        private System.Windows.Forms.Label labelDTThang1;
        private System.Windows.Forms.DataGridView dataGridViewDSTTN;
        private System.Windows.Forms.Label labelThang8;
        private System.Windows.Forms.Label labelThang1;
        private System.Windows.Forms.DataGridView dataGridViewTKSP1;
        private System.Windows.Forms.Label labelThang3;
        private System.Windows.Forms.Label labelThang2;
        private System.Windows.Forms.DataGridView dataGridViewSL;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgay1;
        private System.Windows.Forms.Label labelTongKetNgay;
        private System.Windows.Forms.Label labelSLSPNhapKho;
        private System.Windows.Forms.Label labelSLSPNhapKho_Text;
        private System.Windows.Forms.Label labelThang9;
        private System.Windows.Forms.Label labelThang6;
        private System.Windows.Forms.Label labelThang5;
        private System.Windows.Forms.Label labelThang4;
        private System.Windows.Forms.Label labelSLSPDaBanNam;
        private System.Windows.Forms.GroupBox groupBoxBanHang;
        private System.Windows.Forms.Label labelSLSPDaBanNam_Text;
        private System.Windows.Forms.GroupBox groupBoxNhapKhoLuong;
        private System.Windows.Forms.Label labelSLSPNhapNam;
        private System.Windows.Forms.Label labelSLSPNhapNam_Text;
        private System.Windows.Forms.Label labelNoKhachNam;
        private System.Windows.Forms.Label labelNoKhachNam_Text;
        private System.Windows.Forms.Label labelKhachNoNam;
        private System.Windows.Forms.GroupBox groupBoxLuong;
        private System.Windows.Forms.Label labelKhachNoNam_Text;
        private System.Windows.Forms.GroupBox groupBoxTKNam;
        private System.Windows.Forms.Panel panelNam;
        private System.Windows.Forms.DateTimePicker dateTimePickerNam;
        private System.Windows.Forms.Panel panelTest;
        private System.Windows.Forms.DataGridView dataGridViewNam;
        private System.Windows.Forms.GroupBox groupBoxBieuDoTangTruongHangThang;
        private System.Windows.Forms.Label labelNam;
        private System.Windows.Forms.Panel panelDoanhThuNgay;
        private System.Windows.Forms.Button buttonNam;
        private System.Windows.Forms.Button buttonDoanhThuThang;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonDoanhThuTrongNgay;
        private System.Windows.Forms.Label labelSLSPTra;
        private System.Windows.Forms.Label labelSLSPTra_Text;
        private System.Windows.Forms.Label labelLoiNhuanBHNam;
        private System.Windows.Forms.Label labelLoiNhuanBHNam_Text;
        private System.Windows.Forms.Label labelLuongNV;
        private System.Windows.Forms.Label labelLuongNV_Text;
        private System.Windows.Forms.Label labelTienNhapKhoNam;
        private System.Windows.Forms.Label labelTienNhapKhoNam_Text;
        private System.Windows.Forms.Label labelTongDTNam;
        private System.Windows.Forms.Label labelTongGiamGiaNam;
        private System.Windows.Forms.Label labelTongGiamGiaNam_Text;
        private System.Windows.Forms.Label labelTongDTNam_Text;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label labelTongLoiNhuanCaNam;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelNgayMau;
        private System.Windows.Forms.Panel panelNgay;
        private System.Windows.Forms.Label labelChuThichTKSP1;
        private System.Windows.Forms.Label labelsp4;
        private System.Windows.Forms.Label labelsp3;
        private System.Windows.Forms.Label labelsp2;
        private System.Windows.Forms.Label labelsp1;
        private System.Windows.Forms.Panel panelsp4;
        private System.Windows.Forms.Panel panelsp3;
        private System.Windows.Forms.Panel panelsp2;
        private System.Windows.Forms.Panel panelsp1;
        private System.Windows.Forms.Label labelSLsp4;
        private System.Windows.Forms.Label labelSLsp3;
        private System.Windows.Forms.Label labelSLsp2;
        private System.Windows.Forms.Label labelSLsp1;
        private System.Windows.Forms.Panel panelThangMau;
        private System.Windows.Forms.DataGridView dataGridViewHangTra;
        private System.Windows.Forms.Panel panelCotY;
        private System.Windows.Forms.Label labelSLBieuDoThang;
        private System.Windows.Forms.Panel panelCotX;
        private System.Windows.Forms.DataGridView dataGridViewThang;
        private System.Windows.Forms.Label labelSLsp6T;
        private System.Windows.Forms.Label labelSLsp5T;
        private System.Windows.Forms.Label labelSLsp4T;
        private System.Windows.Forms.Label labelSLsp3T;
        private System.Windows.Forms.Label labelSLsp2T;
        private System.Windows.Forms.Label labelSLsp1T;
        private System.Windows.Forms.Label labelsp5Thang;
        private System.Windows.Forms.Label labelsp6Thang;
        private System.Windows.Forms.Label labelsp3Thang;
        private System.Windows.Forms.Label labelsp4Thang;
        private System.Windows.Forms.Label labelsp1Thang;
        private System.Windows.Forms.Panel panelsp4T;
        private System.Windows.Forms.Panel panelsp3T;
        private System.Windows.Forms.Panel panelsp6T;
        private System.Windows.Forms.Panel panelsp2T;
        private System.Windows.Forms.Panel panelsp5T;
        private System.Windows.Forms.Panel panelsp1T;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelsp2Thang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelLaiTuSPBanDuocTrongThang;
        private System.Windows.Forms.Label labelLaiTuSPBanDuocTrongThang_Text;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label labelSLSPDaBanTrongThang;
        private System.Windows.Forms.Label labelSLSPDaBanTrongThang_Text;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label labelTongGiamGiaThang;
        private System.Windows.Forms.Label labelTongGiamGiaThang_Text;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label labelLoiNhuan;
        private System.Windows.Forms.Label labelLoiNhuan_Text;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labelSLSPNhapKhoTrongThang;
        private System.Windows.Forms.Label labelSLSPNhapKhoTrongThang_Text;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label labelTongTienNhapKhoTrongThang;
        private System.Windows.Forms.Label labelTongTienNhapKhoTrongThang_Text;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelSLSPKhachTraThang;
        private System.Windows.Forms.Label labelSLSPKhachTraThang_Text;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelTongLuongNV;
        private System.Windows.Forms.Label labelTongLuongNV_Text;
        private System.Windows.Forms.Label labelSLToaTrongThang;
        private System.Windows.Forms.Label labelThang;
        private System.Windows.Forms.Label labelKhachNoNoKhachTrongThang;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label labelKhachNoNoKhachTrongThang_Text;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label labelTongDoanhThuTrongThang;
        private System.Windows.Forms.Label labelTongDoanhThuTrongThang_Text;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label labelSLToaTrongThang_Text;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKhachHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongToa;
        private System.Windows.Forms.DataGridViewTextBoxColumn KhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn NoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn TienGiamGia;
        private System.Windows.Forms.DateTimePicker dateTimePickerThang;
    }
}