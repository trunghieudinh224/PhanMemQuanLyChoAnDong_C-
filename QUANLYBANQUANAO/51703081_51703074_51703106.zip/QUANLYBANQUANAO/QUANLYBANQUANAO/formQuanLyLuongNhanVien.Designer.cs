﻿namespace QUANLYBANQUANAO
{
    partial class formQuanLyLuongNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formQuanLyLuongNhanVien));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.buttonX = new System.Windows.Forms.Button();
            this.labelNgayNhap = new System.Windows.Forms.Label();
            this.dateTimePickerThangNam = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewGioCong = new System.Windows.Forms.DataGridView();
            this.ColumnUsername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLuongTheoGio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLuongThuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongGioLam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNgay31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonCapNhat = new System.Windows.Forms.Button();
            this.groupBoxLuongNhanVienChiTiet = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.labelTongThuNhap_Text = new System.Windows.Forms.Label();
            this.labelLuongThuong_Text = new System.Windows.Forms.Label();
            this.labelLuongTheoGio_Text = new System.Windows.Forms.Label();
            this.labelNhanVien_Text = new System.Windows.Forms.Label();
            this.labelGioCong_Text = new System.Windows.Forms.Label();
            this.labelTongThuNhap = new System.Windows.Forms.Label();
            this.labelLuongTheoGio = new System.Windows.Forms.Label();
            this.labelGioCong = new System.Windows.Forms.Label();
            this.labelLuongThuong = new System.Windows.Forms.Label();
            this.labelNhanVien = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBoxTongKet = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelNhanVienHieuQuaNhat_Text = new System.Windows.Forms.Label();
            this.labelTongThuong_Text = new System.Windows.Forms.Label();
            this.labelNhanVienHieuQuaNhat = new System.Windows.Forms.Label();
            this.labelSLNV_Text = new System.Windows.Forms.Label();
            this.labelSLNV = new System.Windows.Forms.Label();
            this.labelTongThuong = new System.Windows.Forms.Label();
            this.labelTongLuongThang_Text = new System.Windows.Forms.Label();
            this.labelTongLuongThang = new System.Windows.Forms.Label();
            this.labelTC = new System.Windows.Forms.Label();
            this.timerTC = new System.Windows.Forms.Timer(this.components);
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGioCong)).BeginInit();
            this.groupBoxLuongNhanVienChiTiet.SuspendLayout();
            this.groupBoxTongKet.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(1284, 35);
            this.panelThanhTieuDe.TabIndex = 53;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 93;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(1172, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 51;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(295, 23);
            this.labelTieuDeForm.TabIndex = 92;
            this.labelTieuDeForm.Text = "QUẢN LÝ LƯƠNG NHÂN VIÊN";
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(1231, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 50;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // labelNgayNhap
            // 
            this.labelNgayNhap.AutoSize = true;
            this.labelNgayNhap.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgayNhap.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNgayNhap.Location = new System.Drawing.Point(-2, 42);
            this.labelNgayNhap.Name = "labelNgayNhap";
            this.labelNgayNhap.Size = new System.Drawing.Size(376, 26);
            this.labelNgayNhap.TabIndex = 94;
            this.labelNgayNhap.Text = "GIỜ CÔNG NHÂN VIÊN THÁNG:";
            // 
            // dateTimePickerThangNam
            // 
            this.dateTimePickerThangNam.AllowDrop = true;
            this.dateTimePickerThangNam.CustomFormat = "MM/yyyyy";
            this.dateTimePickerThangNam.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerThangNam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerThangNam.Location = new System.Drawing.Point(396, 38);
            this.dateTimePickerThangNam.MaxDate = new System.DateTime(3020, 3, 3, 0, 0, 0, 0);
            this.dateTimePickerThangNam.Name = "dateTimePickerThangNam";
            this.dateTimePickerThangNam.ShowUpDown = true;
            this.dateTimePickerThangNam.Size = new System.Drawing.Size(110, 30);
            this.dateTimePickerThangNam.TabIndex = 108;
            this.dateTimePickerThangNam.Value = new System.DateTime(2020, 2, 29, 0, 0, 0, 0);
            this.dateTimePickerThangNam.ValueChanged += new System.EventHandler(this.dateTimePickerThangNam_ValueChanged);
            // 
            // dataGridViewGioCong
            // 
            this.dataGridViewGioCong.AllowDrop = true;
            this.dataGridViewGioCong.AllowUserToAddRows = false;
            this.dataGridViewGioCong.AllowUserToDeleteRows = false;
            this.dataGridViewGioCong.AllowUserToResizeColumns = false;
            this.dataGridViewGioCong.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewGioCong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGioCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGioCong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnUsername,
            this.ColumnLuongTheoGio,
            this.ColumnLuongThuong,
            this.ColumnTongLuong,
            this.ColumnTongGioLam,
            this.ColumnNgay1,
            this.ColumnNgay2,
            this.ColumnNgay3,
            this.ColumnNgay4,
            this.ColumnNgay5,
            this.ColumnNgay6,
            this.ColumnNgay7,
            this.ColumnNgay8,
            this.ColumnNgay9,
            this.ColumnNgay10,
            this.ColumnNgay11,
            this.ColumnNgay12,
            this.ColumnNgay13,
            this.ColumnNgay14,
            this.ColumnNgay15,
            this.ColumnNgay16,
            this.ColumnNgay17,
            this.ColumnNgay18,
            this.ColumnNgay19,
            this.ColumnNgay20,
            this.ColumnNgay21,
            this.ColumnNgay22,
            this.ColumnNgay23,
            this.ColumnNgay24,
            this.ColumnNgay25,
            this.ColumnNgay26,
            this.ColumnNgay27,
            this.ColumnNgay28,
            this.ColumnNgay29,
            this.ColumnNgay30,
            this.ColumnNgay31});
            this.dataGridViewGioCong.Location = new System.Drawing.Point(3, 74);
            this.dataGridViewGioCong.Name = "dataGridViewGioCong";
            this.dataGridViewGioCong.RowHeadersVisible = false;
            this.dataGridViewGioCong.RowHeadersWidth = 51;
            this.dataGridViewGioCong.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewGioCong.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewGioCong.RowTemplate.Height = 24;
            this.dataGridViewGioCong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridViewGioCong.Size = new System.Drawing.Size(784, 325);
            this.dataGridViewGioCong.TabIndex = 109;
            this.dataGridViewGioCong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGioCong_CellClick);
            this.dataGridViewGioCong.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGioCong_CellEndEdit);
            this.dataGridViewGioCong.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridViewGioCong_EditingControlShowing);
            this.dataGridViewGioCong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dataGridViewGioCong_KeyPress);
            // 
            // ColumnUsername
            // 
            this.ColumnUsername.DataPropertyName = "Username";
            this.ColumnUsername.HeaderText = "Nhân viên";
            this.ColumnUsername.MinimumWidth = 6;
            this.ColumnUsername.Name = "ColumnUsername";
            this.ColumnUsername.ReadOnly = true;
            this.ColumnUsername.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnUsername.Width = 120;
            // 
            // ColumnLuongTheoGio
            // 
            this.ColumnLuongTheoGio.DataPropertyName = "LuongTheoGio";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = null;
            this.ColumnLuongTheoGio.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnLuongTheoGio.HeaderText = "Lương theo giờ";
            this.ColumnLuongTheoGio.MinimumWidth = 6;
            this.ColumnLuongTheoGio.Name = "ColumnLuongTheoGio";
            this.ColumnLuongTheoGio.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnLuongTheoGio.Width = 155;
            // 
            // ColumnLuongThuong
            // 
            this.ColumnLuongThuong.DataPropertyName = "LuongThuong";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = null;
            this.ColumnLuongThuong.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnLuongThuong.HeaderText = "Lương thưởng";
            this.ColumnLuongThuong.MinimumWidth = 6;
            this.ColumnLuongThuong.Name = "ColumnLuongThuong";
            this.ColumnLuongThuong.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnLuongThuong.Width = 145;
            // 
            // ColumnTongLuong
            // 
            this.ColumnTongLuong.DataPropertyName = "TongLuong";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "C0";
            dataGridViewCellStyle4.NullValue = null;
            this.ColumnTongLuong.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnTongLuong.HeaderText = "Tổng lương";
            this.ColumnTongLuong.MinimumWidth = 6;
            this.ColumnTongLuong.Name = "ColumnTongLuong";
            this.ColumnTongLuong.ReadOnly = true;
            this.ColumnTongLuong.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnTongLuong.Width = 125;
            // 
            // ColumnTongGioLam
            // 
            this.ColumnTongGioLam.DataPropertyName = "TongGioLam";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.NullValue = null;
            this.ColumnTongGioLam.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnTongGioLam.HeaderText = "Tổng giờ làm";
            this.ColumnTongGioLam.MinimumWidth = 6;
            this.ColumnTongGioLam.Name = "ColumnTongGioLam";
            this.ColumnTongGioLam.ReadOnly = true;
            this.ColumnTongGioLam.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnTongGioLam.Width = 145;
            // 
            // ColumnNgay1
            // 
            this.ColumnNgay1.DataPropertyName = "Ngay1";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay1.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnNgay1.HeaderText = "Ngày 1";
            this.ColumnNgay1.MinimumWidth = 6;
            this.ColumnNgay1.Name = "ColumnNgay1";
            this.ColumnNgay1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay1.Width = 125;
            // 
            // ColumnNgay2
            // 
            this.ColumnNgay2.DataPropertyName = "Ngay2";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay2.DefaultCellStyle = dataGridViewCellStyle7;
            this.ColumnNgay2.HeaderText = "Ngày 2";
            this.ColumnNgay2.MinimumWidth = 6;
            this.ColumnNgay2.Name = "ColumnNgay2";
            this.ColumnNgay2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay2.Width = 125;
            // 
            // ColumnNgay3
            // 
            this.ColumnNgay3.DataPropertyName = "Ngay3";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay3.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColumnNgay3.HeaderText = "Ngày 3";
            this.ColumnNgay3.MinimumWidth = 6;
            this.ColumnNgay3.Name = "ColumnNgay3";
            this.ColumnNgay3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay3.Width = 125;
            // 
            // ColumnNgay4
            // 
            this.ColumnNgay4.DataPropertyName = "Ngay4";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay4.DefaultCellStyle = dataGridViewCellStyle9;
            this.ColumnNgay4.HeaderText = "Ngày 4";
            this.ColumnNgay4.MinimumWidth = 6;
            this.ColumnNgay4.Name = "ColumnNgay4";
            this.ColumnNgay4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay4.Width = 125;
            // 
            // ColumnNgay5
            // 
            this.ColumnNgay5.DataPropertyName = "Ngay5";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay5.DefaultCellStyle = dataGridViewCellStyle10;
            this.ColumnNgay5.HeaderText = "Ngày 5";
            this.ColumnNgay5.MinimumWidth = 6;
            this.ColumnNgay5.Name = "ColumnNgay5";
            this.ColumnNgay5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay5.Width = 125;
            // 
            // ColumnNgay6
            // 
            this.ColumnNgay6.DataPropertyName = "Ngay6";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay6.DefaultCellStyle = dataGridViewCellStyle11;
            this.ColumnNgay6.HeaderText = "Ngày 6";
            this.ColumnNgay6.MinimumWidth = 6;
            this.ColumnNgay6.Name = "ColumnNgay6";
            this.ColumnNgay6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay6.Width = 125;
            // 
            // ColumnNgay7
            // 
            this.ColumnNgay7.DataPropertyName = "Ngay7";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay7.DefaultCellStyle = dataGridViewCellStyle12;
            this.ColumnNgay7.HeaderText = "Ngày 7 ";
            this.ColumnNgay7.MinimumWidth = 6;
            this.ColumnNgay7.Name = "ColumnNgay7";
            this.ColumnNgay7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay7.Width = 125;
            // 
            // ColumnNgay8
            // 
            this.ColumnNgay8.DataPropertyName = "Ngay8";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay8.DefaultCellStyle = dataGridViewCellStyle13;
            this.ColumnNgay8.HeaderText = "Ngày 8";
            this.ColumnNgay8.MinimumWidth = 6;
            this.ColumnNgay8.Name = "ColumnNgay8";
            this.ColumnNgay8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay8.Width = 125;
            // 
            // ColumnNgay9
            // 
            this.ColumnNgay9.DataPropertyName = "Ngay9";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay9.DefaultCellStyle = dataGridViewCellStyle14;
            this.ColumnNgay9.HeaderText = "Ngày 9";
            this.ColumnNgay9.MinimumWidth = 6;
            this.ColumnNgay9.Name = "ColumnNgay9";
            this.ColumnNgay9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay9.Width = 125;
            // 
            // ColumnNgay10
            // 
            this.ColumnNgay10.DataPropertyName = "Ngay10";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay10.DefaultCellStyle = dataGridViewCellStyle15;
            this.ColumnNgay10.HeaderText = "Ngày 10";
            this.ColumnNgay10.MinimumWidth = 6;
            this.ColumnNgay10.Name = "ColumnNgay10";
            this.ColumnNgay10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay10.Width = 125;
            // 
            // ColumnNgay11
            // 
            this.ColumnNgay11.DataPropertyName = "Ngay11";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay11.DefaultCellStyle = dataGridViewCellStyle16;
            this.ColumnNgay11.HeaderText = "Ngày 11";
            this.ColumnNgay11.MinimumWidth = 6;
            this.ColumnNgay11.Name = "ColumnNgay11";
            this.ColumnNgay11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay11.Width = 125;
            // 
            // ColumnNgay12
            // 
            this.ColumnNgay12.DataPropertyName = "Ngay12";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay12.DefaultCellStyle = dataGridViewCellStyle17;
            this.ColumnNgay12.HeaderText = "Ngày 12";
            this.ColumnNgay12.MinimumWidth = 6;
            this.ColumnNgay12.Name = "ColumnNgay12";
            this.ColumnNgay12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay12.Width = 125;
            // 
            // ColumnNgay13
            // 
            this.ColumnNgay13.DataPropertyName = "Ngay13";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay13.DefaultCellStyle = dataGridViewCellStyle18;
            this.ColumnNgay13.HeaderText = "Ngày 13";
            this.ColumnNgay13.MinimumWidth = 6;
            this.ColumnNgay13.Name = "ColumnNgay13";
            this.ColumnNgay13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay13.Width = 125;
            // 
            // ColumnNgay14
            // 
            this.ColumnNgay14.DataPropertyName = "Ngay14";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay14.DefaultCellStyle = dataGridViewCellStyle19;
            this.ColumnNgay14.HeaderText = "Ngày 14";
            this.ColumnNgay14.MinimumWidth = 6;
            this.ColumnNgay14.Name = "ColumnNgay14";
            this.ColumnNgay14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay14.Width = 125;
            // 
            // ColumnNgay15
            // 
            this.ColumnNgay15.DataPropertyName = "Ngay15";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay15.DefaultCellStyle = dataGridViewCellStyle20;
            this.ColumnNgay15.HeaderText = "Ngày 15";
            this.ColumnNgay15.MinimumWidth = 6;
            this.ColumnNgay15.Name = "ColumnNgay15";
            this.ColumnNgay15.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay15.Width = 125;
            // 
            // ColumnNgay16
            // 
            this.ColumnNgay16.DataPropertyName = "Ngay16";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay16.DefaultCellStyle = dataGridViewCellStyle21;
            this.ColumnNgay16.HeaderText = "Ngày 16";
            this.ColumnNgay16.MinimumWidth = 6;
            this.ColumnNgay16.Name = "ColumnNgay16";
            this.ColumnNgay16.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay16.Width = 125;
            // 
            // ColumnNgay17
            // 
            this.ColumnNgay17.DataPropertyName = "Ngay17";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay17.DefaultCellStyle = dataGridViewCellStyle22;
            this.ColumnNgay17.HeaderText = "Ngày 17";
            this.ColumnNgay17.MinimumWidth = 6;
            this.ColumnNgay17.Name = "ColumnNgay17";
            this.ColumnNgay17.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay17.Width = 125;
            // 
            // ColumnNgay18
            // 
            this.ColumnNgay18.DataPropertyName = "Ngay18";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay18.DefaultCellStyle = dataGridViewCellStyle23;
            this.ColumnNgay18.HeaderText = "Ngày 18";
            this.ColumnNgay18.MinimumWidth = 6;
            this.ColumnNgay18.Name = "ColumnNgay18";
            this.ColumnNgay18.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay18.Width = 125;
            // 
            // ColumnNgay19
            // 
            this.ColumnNgay19.DataPropertyName = "Ngay19";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay19.DefaultCellStyle = dataGridViewCellStyle24;
            this.ColumnNgay19.HeaderText = "Ngày 19";
            this.ColumnNgay19.MinimumWidth = 6;
            this.ColumnNgay19.Name = "ColumnNgay19";
            this.ColumnNgay19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay19.Width = 125;
            // 
            // ColumnNgay20
            // 
            this.ColumnNgay20.DataPropertyName = "Ngay20";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay20.DefaultCellStyle = dataGridViewCellStyle25;
            this.ColumnNgay20.HeaderText = "Ngày 20";
            this.ColumnNgay20.MinimumWidth = 6;
            this.ColumnNgay20.Name = "ColumnNgay20";
            this.ColumnNgay20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay20.Width = 125;
            // 
            // ColumnNgay21
            // 
            this.ColumnNgay21.DataPropertyName = "Ngay21";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay21.DefaultCellStyle = dataGridViewCellStyle26;
            this.ColumnNgay21.HeaderText = "Ngày 21";
            this.ColumnNgay21.MinimumWidth = 6;
            this.ColumnNgay21.Name = "ColumnNgay21";
            this.ColumnNgay21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay21.Width = 125;
            // 
            // ColumnNgay22
            // 
            this.ColumnNgay22.DataPropertyName = "Ngay22";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay22.DefaultCellStyle = dataGridViewCellStyle27;
            this.ColumnNgay22.HeaderText = "Ngày 22";
            this.ColumnNgay22.MinimumWidth = 6;
            this.ColumnNgay22.Name = "ColumnNgay22";
            this.ColumnNgay22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay22.Width = 125;
            // 
            // ColumnNgay23
            // 
            this.ColumnNgay23.DataPropertyName = "Ngay23";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay23.DefaultCellStyle = dataGridViewCellStyle28;
            this.ColumnNgay23.HeaderText = "Ngày 23";
            this.ColumnNgay23.MinimumWidth = 6;
            this.ColumnNgay23.Name = "ColumnNgay23";
            this.ColumnNgay23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay23.Width = 125;
            // 
            // ColumnNgay24
            // 
            this.ColumnNgay24.DataPropertyName = "Ngay24";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay24.DefaultCellStyle = dataGridViewCellStyle29;
            this.ColumnNgay24.HeaderText = "Ngày 24";
            this.ColumnNgay24.MinimumWidth = 6;
            this.ColumnNgay24.Name = "ColumnNgay24";
            this.ColumnNgay24.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay24.Width = 125;
            // 
            // ColumnNgay25
            // 
            this.ColumnNgay25.DataPropertyName = "Ngay25";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay25.DefaultCellStyle = dataGridViewCellStyle30;
            this.ColumnNgay25.HeaderText = "Ngày 25";
            this.ColumnNgay25.MinimumWidth = 6;
            this.ColumnNgay25.Name = "ColumnNgay25";
            this.ColumnNgay25.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay25.Width = 125;
            // 
            // ColumnNgay26
            // 
            this.ColumnNgay26.DataPropertyName = "Ngay26";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay26.DefaultCellStyle = dataGridViewCellStyle31;
            this.ColumnNgay26.HeaderText = "Ngày 26";
            this.ColumnNgay26.MinimumWidth = 6;
            this.ColumnNgay26.Name = "ColumnNgay26";
            this.ColumnNgay26.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay26.Width = 125;
            // 
            // ColumnNgay27
            // 
            this.ColumnNgay27.DataPropertyName = "Ngay27";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay27.DefaultCellStyle = dataGridViewCellStyle32;
            this.ColumnNgay27.HeaderText = "Ngày 27";
            this.ColumnNgay27.MinimumWidth = 6;
            this.ColumnNgay27.Name = "ColumnNgay27";
            this.ColumnNgay27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay27.Width = 125;
            // 
            // ColumnNgay28
            // 
            this.ColumnNgay28.DataPropertyName = "Ngay28";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay28.DefaultCellStyle = dataGridViewCellStyle33;
            this.ColumnNgay28.HeaderText = "Ngày 28";
            this.ColumnNgay28.MinimumWidth = 6;
            this.ColumnNgay28.Name = "ColumnNgay28";
            this.ColumnNgay28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay28.Width = 125;
            // 
            // ColumnNgay29
            // 
            this.ColumnNgay29.DataPropertyName = "Ngay29";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay29.DefaultCellStyle = dataGridViewCellStyle34;
            this.ColumnNgay29.HeaderText = "Ngày 29";
            this.ColumnNgay29.MinimumWidth = 6;
            this.ColumnNgay29.Name = "ColumnNgay29";
            this.ColumnNgay29.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay29.Width = 125;
            // 
            // ColumnNgay30
            // 
            this.ColumnNgay30.DataPropertyName = "Ngay30";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay30.DefaultCellStyle = dataGridViewCellStyle35;
            this.ColumnNgay30.HeaderText = "Ngày 30";
            this.ColumnNgay30.MinimumWidth = 6;
            this.ColumnNgay30.Name = "ColumnNgay30";
            this.ColumnNgay30.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay30.Width = 125;
            // 
            // ColumnNgay31
            // 
            this.ColumnNgay31.DataPropertyName = "Ngay31";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnNgay31.DefaultCellStyle = dataGridViewCellStyle36;
            this.ColumnNgay31.HeaderText = "Ngày 31";
            this.ColumnNgay31.MinimumWidth = 6;
            this.ColumnNgay31.Name = "ColumnNgay31";
            this.ColumnNgay31.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnNgay31.Width = 125;
            // 
            // buttonCapNhat
            // 
            this.buttonCapNhat.BackColor = System.Drawing.Color.Red;
            this.buttonCapNhat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonCapNhat.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhat.Location = new System.Drawing.Point(1130, 355);
            this.buttonCapNhat.Name = "buttonCapNhat";
            this.buttonCapNhat.Size = new System.Drawing.Size(148, 44);
            this.buttonCapNhat.TabIndex = 10;
            this.buttonCapNhat.Text = "Cập nhật";
            this.buttonCapNhat.UseVisualStyleBackColor = false;
            this.buttonCapNhat.Click += new System.EventHandler(this.buttonCapNhat_Click);
            // 
            // groupBoxLuongNhanVienChiTiet
            // 
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.label19);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.label21);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelTongThuNhap_Text);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelLuongThuong_Text);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelLuongTheoGio_Text);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelNhanVien_Text);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelGioCong_Text);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelTongThuNhap);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelLuongTheoGio);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelGioCong);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelLuongThuong);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.labelNhanVien);
            this.groupBoxLuongNhanVienChiTiet.Controls.Add(this.label12);
            this.groupBoxLuongNhanVienChiTiet.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxLuongNhanVienChiTiet.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxLuongNhanVienChiTiet.Location = new System.Drawing.Point(800, 42);
            this.groupBoxLuongNhanVienChiTiet.Name = "groupBoxLuongNhanVienChiTiet";
            this.groupBoxLuongNhanVienChiTiet.Size = new System.Drawing.Size(477, 153);
            this.groupBoxLuongNhanVienChiTiet.TabIndex = 111;
            this.groupBoxLuongNhanVienChiTiet.TabStop = false;
            this.groupBoxLuongNhanVienChiTiet.Text = "LƯƠNG NHÂN VIÊN CHI TIẾT";
            this.groupBoxLuongNhanVienChiTiet.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxLuongNhanVienChiTiet_Paint);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(271, 90);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 25);
            this.label19.TabIndex = 68;
            this.label19.Text = "VNĐ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(292, 120);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 25);
            this.label21.TabIndex = 70;
            this.label21.Text = "VNĐ";
            // 
            // labelTongThuNhap_Text
            // 
            this.labelTongThuNhap_Text.AutoSize = true;
            this.labelTongThuNhap_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongThuNhap_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongThuNhap_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongThuNhap_Text.Location = new System.Drawing.Point(177, 121);
            this.labelTongThuNhap_Text.MaximumSize = new System.Drawing.Size(121, 25);
            this.labelTongThuNhap_Text.MinimumSize = new System.Drawing.Size(121, 25);
            this.labelTongThuNhap_Text.Name = "labelTongThuNhap_Text";
            this.labelTongThuNhap_Text.Size = new System.Drawing.Size(121, 25);
            this.labelTongThuNhap_Text.TabIndex = 69;
            this.labelTongThuNhap_Text.Text = "2500000";
            this.labelTongThuNhap_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelLuongThuong_Text
            // 
            this.labelLuongThuong_Text.AutoSize = true;
            this.labelLuongThuong_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLuongThuong_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongThuong_Text.ForeColor = System.Drawing.Color.Black;
            this.labelLuongThuong_Text.Location = new System.Drawing.Point(168, 90);
            this.labelLuongThuong_Text.MaximumSize = new System.Drawing.Size(109, 25);
            this.labelLuongThuong_Text.MinimumSize = new System.Drawing.Size(109, 25);
            this.labelLuongThuong_Text.Name = "labelLuongThuong_Text";
            this.labelLuongThuong_Text.Size = new System.Drawing.Size(109, 25);
            this.labelLuongThuong_Text.TabIndex = 67;
            this.labelLuongThuong_Text.Text = "1000000";
            this.labelLuongThuong_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelLuongTheoGio_Text
            // 
            this.labelLuongTheoGio_Text.AutoSize = true;
            this.labelLuongTheoGio_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLuongTheoGio_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongTheoGio_Text.ForeColor = System.Drawing.Color.Black;
            this.labelLuongTheoGio_Text.Location = new System.Drawing.Point(176, 60);
            this.labelLuongTheoGio_Text.MaximumSize = new System.Drawing.Size(83, 25);
            this.labelLuongTheoGio_Text.MinimumSize = new System.Drawing.Size(83, 25);
            this.labelLuongTheoGio_Text.Name = "labelLuongTheoGio_Text";
            this.labelLuongTheoGio_Text.Size = new System.Drawing.Size(83, 25);
            this.labelLuongTheoGio_Text.TabIndex = 61;
            this.labelLuongTheoGio_Text.Text = "25000";
            this.labelLuongTheoGio_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelNhanVien_Text
            // 
            this.labelNhanVien_Text.AutoSize = true;
            this.labelNhanVien_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNhanVien_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVien_Text.ForeColor = System.Drawing.Color.Black;
            this.labelNhanVien_Text.Location = new System.Drawing.Point(127, 29);
            this.labelNhanVien_Text.Name = "labelNhanVien_Text";
            this.labelNhanVien_Text.Size = new System.Drawing.Size(54, 25);
            this.labelNhanVien_Text.TabIndex = 66;
            this.labelNhanVien_Text.Text = "Hiếu";
            // 
            // labelGioCong_Text
            // 
            this.labelGioCong_Text.AutoSize = true;
            this.labelGioCong_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelGioCong_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGioCong_Text.ForeColor = System.Drawing.Color.Black;
            this.labelGioCong_Text.Location = new System.Drawing.Point(418, 60);
            this.labelGioCong_Text.Name = "labelGioCong_Text";
            this.labelGioCong_Text.Size = new System.Drawing.Size(33, 25);
            this.labelGioCong_Text.TabIndex = 66;
            this.labelGioCong_Text.Text = "11";
            this.labelGioCong_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTongThuNhap
            // 
            this.labelTongThuNhap.AutoSize = true;
            this.labelTongThuNhap.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongThuNhap.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongThuNhap.ForeColor = System.Drawing.Color.Black;
            this.labelTongThuNhap.Location = new System.Drawing.Point(6, 120);
            this.labelTongThuNhap.Name = "labelTongThuNhap";
            this.labelTongThuNhap.Size = new System.Drawing.Size(164, 25);
            this.labelTongThuNhap.TabIndex = 61;
            this.labelTongThuNhap.Text = "Tổng thu nhập :";
            // 
            // labelLuongTheoGio
            // 
            this.labelLuongTheoGio.AutoSize = true;
            this.labelLuongTheoGio.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLuongTheoGio.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongTheoGio.ForeColor = System.Drawing.Color.Black;
            this.labelLuongTheoGio.Location = new System.Drawing.Point(6, 60);
            this.labelLuongTheoGio.Name = "labelLuongTheoGio";
            this.labelLuongTheoGio.Size = new System.Drawing.Size(163, 25);
            this.labelLuongTheoGio.TabIndex = 60;
            this.labelLuongTheoGio.Text = "Lương theo giờ:";
            // 
            // labelGioCong
            // 
            this.labelGioCong.AutoSize = true;
            this.labelGioCong.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelGioCong.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGioCong.ForeColor = System.Drawing.Color.Black;
            this.labelGioCong.Location = new System.Drawing.Point(313, 60);
            this.labelGioCong.Name = "labelGioCong";
            this.labelGioCong.Size = new System.Drawing.Size(104, 25);
            this.labelGioCong.TabIndex = 57;
            this.labelGioCong.Text = "Giờ công:";
            // 
            // labelLuongThuong
            // 
            this.labelLuongThuong.AutoSize = true;
            this.labelLuongThuong.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLuongThuong.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLuongThuong.ForeColor = System.Drawing.Color.Black;
            this.labelLuongThuong.Location = new System.Drawing.Point(6, 90);
            this.labelLuongThuong.Name = "labelLuongThuong";
            this.labelLuongThuong.Size = new System.Drawing.Size(155, 25);
            this.labelLuongThuong.TabIndex = 56;
            this.labelLuongThuong.Text = "Lương thưởng:";
            // 
            // labelNhanVien
            // 
            this.labelNhanVien.AutoSize = true;
            this.labelNhanVien.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNhanVien.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVien.ForeColor = System.Drawing.Color.Black;
            this.labelNhanVien.Location = new System.Drawing.Point(6, 30);
            this.labelNhanVien.Name = "labelNhanVien";
            this.labelNhanVien.Size = new System.Drawing.Size(116, 25);
            this.labelNhanVien.TabIndex = 55;
            this.labelNhanVien.Text = "Nhân viên:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(254, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 25);
            this.label12.TabIndex = 62;
            this.label12.Text = "VNĐ";
            // 
            // groupBoxTongKet
            // 
            this.groupBoxTongKet.Controls.Add(this.label13);
            this.groupBoxTongKet.Controls.Add(this.label14);
            this.groupBoxTongKet.Controls.Add(this.labelNhanVienHieuQuaNhat_Text);
            this.groupBoxTongKet.Controls.Add(this.labelTongThuong_Text);
            this.groupBoxTongKet.Controls.Add(this.labelNhanVienHieuQuaNhat);
            this.groupBoxTongKet.Controls.Add(this.labelSLNV_Text);
            this.groupBoxTongKet.Controls.Add(this.labelSLNV);
            this.groupBoxTongKet.Controls.Add(this.labelTongThuong);
            this.groupBoxTongKet.Controls.Add(this.labelTongLuongThang_Text);
            this.groupBoxTongKet.Controls.Add(this.labelTongLuongThang);
            this.groupBoxTongKet.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxTongKet.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxTongKet.Location = new System.Drawing.Point(800, 210);
            this.groupBoxTongKet.Name = "groupBoxTongKet";
            this.groupBoxTongKet.Size = new System.Drawing.Size(477, 122);
            this.groupBoxTongKet.TabIndex = 112;
            this.groupBoxTongKet.TabStop = false;
            this.groupBoxTongKet.Text = "TỔNG KẾT";
            this.groupBoxTongKet.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxTongKet_Paint);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(311, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 25);
            this.label13.TabIndex = 63;
            this.label13.Text = "VNĐ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(267, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 25);
            this.label14.TabIndex = 65;
            this.label14.Text = "VNĐ";
            // 
            // labelNhanVienHieuQuaNhat_Text
            // 
            this.labelNhanVienHieuQuaNhat_Text.AutoSize = true;
            this.labelNhanVienHieuQuaNhat_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNhanVienHieuQuaNhat_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienHieuQuaNhat_Text.ForeColor = System.Drawing.Color.Black;
            this.labelNhanVienHieuQuaNhat_Text.Location = new System.Drawing.Point(271, 90);
            this.labelNhanVienHieuQuaNhat_Text.Name = "labelNhanVienHieuQuaNhat_Text";
            this.labelNhanVienHieuQuaNhat_Text.Size = new System.Drawing.Size(54, 25);
            this.labelNhanVienHieuQuaNhat_Text.TabIndex = 71;
            this.labelNhanVienHieuQuaNhat_Text.Text = "Hiếu";
            // 
            // labelTongThuong_Text
            // 
            this.labelTongThuong_Text.AutoSize = true;
            this.labelTongThuong_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongThuong_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongThuong_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongThuong_Text.Location = new System.Drawing.Point(152, 60);
            this.labelTongThuong_Text.MaximumSize = new System.Drawing.Size(121, 25);
            this.labelTongThuong_Text.MinimumSize = new System.Drawing.Size(121, 25);
            this.labelTongThuong_Text.Name = "labelTongThuong_Text";
            this.labelTongThuong_Text.Size = new System.Drawing.Size(121, 25);
            this.labelTongThuong_Text.TabIndex = 64;
            this.labelTongThuong_Text.Text = "100000000";
            this.labelTongThuong_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelNhanVienHieuQuaNhat
            // 
            this.labelNhanVienHieuQuaNhat.AutoSize = true;
            this.labelNhanVienHieuQuaNhat.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNhanVienHieuQuaNhat.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienHieuQuaNhat.ForeColor = System.Drawing.Color.Black;
            this.labelNhanVienHieuQuaNhat.Location = new System.Drawing.Point(6, 90);
            this.labelNhanVienHieuQuaNhat.Name = "labelNhanVienHieuQuaNhat";
            this.labelNhanVienHieuQuaNhat.Size = new System.Drawing.Size(251, 25);
            this.labelNhanVienHieuQuaNhat.TabIndex = 60;
            this.labelNhanVienHieuQuaNhat.Text = "Nhân viên hiệu quả nhất:";
            // 
            // labelSLNV_Text
            // 
            this.labelSLNV_Text.AutoSize = true;
            this.labelSLNV_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLNV_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLNV_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSLNV_Text.Location = new System.Drawing.Point(419, 60);
            this.labelSLNV_Text.Name = "labelSLNV_Text";
            this.labelSLNV_Text.Size = new System.Drawing.Size(33, 25);
            this.labelSLNV_Text.TabIndex = 59;
            this.labelSLNV_Text.Text = "11";
            this.labelSLNV_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelSLNV
            // 
            this.labelSLNV.AutoSize = true;
            this.labelSLNV.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLNV.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLNV.ForeColor = System.Drawing.Color.Black;
            this.labelSLNV.Location = new System.Drawing.Point(339, 60);
            this.labelSLNV.Name = "labelSLNV";
            this.labelSLNV.Size = new System.Drawing.Size(75, 25);
            this.labelSLNV.TabIndex = 58;
            this.labelSLNV.Text = "SLNV:";
            // 
            // labelTongThuong
            // 
            this.labelTongThuong.AutoSize = true;
            this.labelTongThuong.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongThuong.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongThuong.ForeColor = System.Drawing.Color.Black;
            this.labelTongThuong.Location = new System.Drawing.Point(6, 60);
            this.labelTongThuong.Name = "labelTongThuong";
            this.labelTongThuong.Size = new System.Drawing.Size(141, 25);
            this.labelTongThuong.TabIndex = 57;
            this.labelTongThuong.Text = "Tổng thưởng:";
            // 
            // labelTongLuongThang_Text
            // 
            this.labelTongLuongThang_Text.AutoSize = true;
            this.labelTongLuongThang_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongLuongThang_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongLuongThang_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongLuongThang_Text.Location = new System.Drawing.Point(195, 29);
            this.labelTongLuongThang_Text.MaximumSize = new System.Drawing.Size(121, 25);
            this.labelTongLuongThang_Text.MinimumSize = new System.Drawing.Size(121, 25);
            this.labelTongLuongThang_Text.Name = "labelTongLuongThang_Text";
            this.labelTongLuongThang_Text.Size = new System.Drawing.Size(121, 25);
            this.labelTongLuongThang_Text.TabIndex = 56;
            this.labelTongLuongThang_Text.Text = "100000000";
            this.labelTongLuongThang_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTongLuongThang
            // 
            this.labelTongLuongThang.AutoSize = true;
            this.labelTongLuongThang.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongLuongThang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongLuongThang.ForeColor = System.Drawing.Color.Black;
            this.labelTongLuongThang.Location = new System.Drawing.Point(6, 30);
            this.labelTongLuongThang.Name = "labelTongLuongThang";
            this.labelTongLuongThang.Size = new System.Drawing.Size(187, 25);
            this.labelTongLuongThang.TabIndex = 55;
            this.labelTongLuongThang.Text = "Tổng lương tháng:";
            // 
            // labelTC
            // 
            this.labelTC.AutoSize = true;
            this.labelTC.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTC.ForeColor = System.Drawing.Color.Red;
            this.labelTC.Location = new System.Drawing.Point(806, 371);
            this.labelTC.Name = "labelTC";
            this.labelTC.Size = new System.Drawing.Size(231, 26);
            this.labelTC.TabIndex = 72;
            this.labelTC.Text = "Cập nhật thành công.";
            this.labelTC.Visible = false;
            // 
            // timerTC
            // 
            this.timerTC.Interval = 1000;
            this.timerTC.Tick += new System.EventHandler(this.timerTC_Tick);
            // 
            // formQuanLyLuongNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1284, 402);
            this.Controls.Add(this.labelTC);
            this.Controls.Add(this.groupBoxTongKet);
            this.Controls.Add(this.groupBoxLuongNhanVienChiTiet);
            this.Controls.Add(this.buttonCapNhat);
            this.Controls.Add(this.dataGridViewGioCong);
            this.Controls.Add(this.dateTimePickerThangNam);
            this.Controls.Add(this.labelNgayNhap);
            this.Controls.Add(this.panelThanhTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formQuanLyLuongNhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formQuanLyLuongNhanVien";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGioCong)).EndInit();
            this.groupBoxLuongNhanVienChiTiet.ResumeLayout(false);
            this.groupBoxLuongNhanVienChiTiet.PerformLayout();
            this.groupBoxTongKet.ResumeLayout(false);
            this.groupBoxTongKet.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Label labelNgayNhap;
        private System.Windows.Forms.DateTimePicker dateTimePickerThangNam;
        private System.Windows.Forms.DataGridView dataGridViewGioCong;
        private System.Windows.Forms.Button buttonCapNhat;
        private System.Windows.Forms.GroupBox groupBoxLuongNhanVienChiTiet;
        private System.Windows.Forms.Label labelTongThuNhap_Text;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label labelLuongThuong_Text;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labelNhanVien_Text;
        private System.Windows.Forms.Label labelGioCong_Text;
        private System.Windows.Forms.Label labelLuongTheoGio_Text;
        private System.Windows.Forms.Label labelTongThuNhap;
        private System.Windows.Forms.Label labelLuongTheoGio;
        private System.Windows.Forms.Label labelGioCong;
        private System.Windows.Forms.Label labelLuongThuong;
        private System.Windows.Forms.Label labelNhanVien;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBoxTongKet;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelNhanVienHieuQuaNhat_Text;
        private System.Windows.Forms.Label labelTongThuong_Text;
        private System.Windows.Forms.Label labelNhanVienHieuQuaNhat;
        private System.Windows.Forms.Label labelSLNV_Text;
        private System.Windows.Forms.Label labelSLNV;
        private System.Windows.Forms.Label labelTongThuong;
        private System.Windows.Forms.Label labelTongLuongThang_Text;
        private System.Windows.Forms.Label labelTongLuongThang;
        private System.Windows.Forms.Label labelTC;
        private System.Windows.Forms.Timer timerTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUsername;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLuongTheoGio;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLuongThuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongGioLam;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay5;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay7;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay8;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay9;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay10;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay11;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay12;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay13;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay14;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay15;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay16;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay17;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay18;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay19;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay20;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay21;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay22;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay23;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay24;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay25;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay26;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay27;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay28;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay29;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay30;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgay31;
    }
}