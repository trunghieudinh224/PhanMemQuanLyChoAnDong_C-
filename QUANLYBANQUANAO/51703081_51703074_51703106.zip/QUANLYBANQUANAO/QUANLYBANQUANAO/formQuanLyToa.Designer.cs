﻿namespace QUANLYBANQUANAO
{
    partial class formQuanLyToa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formQuanLyToa));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.tabPageToaNoKhach = new System.Windows.Forms.TabPage();
            this.buttonCapNhatNoKhach = new System.Windows.Forms.Button();
            this.labelNoKhachNoKhach_Text = new System.Windows.Forms.Label();
            this.labelTongToaNoKhach_Text = new System.Windows.Forms.Label();
            this.labelTenKhachNoKhach_Text = new System.Windows.Forms.Label();
            this.labelMaToaNoKhach_Text = new System.Windows.Forms.Label();
            this.labelThongTinToaNoKhach = new System.Windows.Forms.Label();
            this.labelDanhSachToaNoKhach = new System.Windows.Forms.Label();
            this.labelNoKhachNoKhach = new System.Windows.Forms.Label();
            this.labelTongToaNoKhach = new System.Windows.Forms.Label();
            this.labelTenKhachNoKhach = new System.Windows.Forms.Label();
            this.labelMaToaNoKhach = new System.Windows.Forms.Label();
            this.textBoxTruNo = new System.Windows.Forms.TextBox();
            this.textBoxTinhTrangNoKhach = new System.Windows.Forms.TextBox();
            this.labelTruNo = new System.Windows.Forms.Label();
            this.labelTinhTrangNoKhach = new System.Windows.Forms.Label();
            this.dataGridViewToaNoKhach = new System.Windows.Forms.DataGridView();
            this.ColumnNgayLapToaNoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMaToaNoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenKHNoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongToaNoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNoKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageToaKhachNo = new System.Windows.Forms.TabPage();
            this.labelMaToaKhachNo_Text = new System.Windows.Forms.Label();
            this.labelMaToaKhachNo = new System.Windows.Forms.Label();
            this.textBoxTinhTrangKhachNo = new System.Windows.Forms.TextBox();
            this.textBoxTraNoKhachNo = new System.Windows.Forms.TextBox();
            this.labelKhachNo_Text = new System.Windows.Forms.Label();
            this.labelTongToaKhachNo_Text = new System.Windows.Forms.Label();
            this.labelTenKhachKhachNo_Text = new System.Windows.Forms.Label();
            this.labelKhachNo = new System.Windows.Forms.Label();
            this.labelTinhTrangKhachNo = new System.Windows.Forms.Label();
            this.labelTongToaKhachNo = new System.Windows.Forms.Label();
            this.labelTenKhachKhachNo = new System.Windows.Forms.Label();
            this.labelThongTinToaKhachNo = new System.Windows.Forms.Label();
            this.labelTraNoKhachNo = new System.Windows.Forms.Label();
            this.buttonCapNhat = new System.Windows.Forms.Button();
            this.labelDanhSachToaKhachNo = new System.Windows.Forms.Label();
            this.dataGridViewToaKhachNo = new System.Windows.Forms.DataGridView();
            this.ColumnNgayLapToaKhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSDTKhachKhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenKhachKhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongToaKhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnKhachNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageDanhSachToa = new System.Windows.Forms.TabPage();
            this.labelTimKiem = new System.Windows.Forms.Label();
            this.textBoxTimKiem = new System.Windows.Forms.TextBox();
            this.buttonChiTietToa = new System.Windows.Forms.Button();
            this.buttonHienDanhSachBill = new System.Windows.Forms.Button();
            this.labelDenNgay = new System.Windows.Forms.Label();
            this.labelTuNgay = new System.Windows.Forms.Label();
            this.dateTimePickerDenNgay = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewToa = new System.Windows.Forms.DataGridView();
            this.ColumnNgayLapToa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMaToa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTenKhachHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSDTKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongToa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnHinhThucThanhToan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePickerTuNgay = new System.Windows.Forms.DateTimePicker();
            this.tabControlToa = new System.Windows.Forms.TabControl();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.tabPageToaNoKhach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToaNoKhach)).BeginInit();
            this.tabPageToaKhachNo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToaKhachNo)).BeginInit();
            this.tabPageDanhSachToa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToa)).BeginInit();
            this.tabControlToa.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(1125, 35);
            this.panelThanhTieuDe.TabIndex = 17;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(211, 23);
            this.labelTieuDeForm.TabIndex = 91;
            this.labelTieuDeForm.Text = "QUẢN LÝ TOA HÀNG";
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 50;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(1015, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(1071, -1);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 35);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // tabPageToaNoKhach
            // 
            this.tabPageToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPageToaNoKhach.Controls.Add(this.buttonCapNhatNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelNoKhachNoKhach_Text);
            this.tabPageToaNoKhach.Controls.Add(this.labelTongToaNoKhach_Text);
            this.tabPageToaNoKhach.Controls.Add(this.labelTenKhachNoKhach_Text);
            this.tabPageToaNoKhach.Controls.Add(this.labelMaToaNoKhach_Text);
            this.tabPageToaNoKhach.Controls.Add(this.labelThongTinToaNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelDanhSachToaNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelNoKhachNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelTongToaNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelTenKhachNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelMaToaNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.textBoxTruNo);
            this.tabPageToaNoKhach.Controls.Add(this.textBoxTinhTrangNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.labelTruNo);
            this.tabPageToaNoKhach.Controls.Add(this.labelTinhTrangNoKhach);
            this.tabPageToaNoKhach.Controls.Add(this.dataGridViewToaNoKhach);
            this.tabPageToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageToaNoKhach.Location = new System.Drawing.Point(4, 34);
            this.tabPageToaNoKhach.Name = "tabPageToaNoKhach";
            this.tabPageToaNoKhach.Size = new System.Drawing.Size(1117, 539);
            this.tabPageToaNoKhach.TabIndex = 2;
            this.tabPageToaNoKhach.Text = "Toa nợ khách";
            // 
            // buttonCapNhatNoKhach
            // 
            this.buttonCapNhatNoKhach.BackColor = System.Drawing.Color.Red;
            this.buttonCapNhatNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonCapNhatNoKhach.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhatNoKhach.Location = new System.Drawing.Point(959, 364);
            this.buttonCapNhatNoKhach.Name = "buttonCapNhatNoKhach";
            this.buttonCapNhatNoKhach.Size = new System.Drawing.Size(151, 50);
            this.buttonCapNhatNoKhach.TabIndex = 53;
            this.buttonCapNhatNoKhach.Text = "Cập nhật";
            this.buttonCapNhatNoKhach.UseVisualStyleBackColor = false;
            this.buttonCapNhatNoKhach.Click += new System.EventHandler(this.buttonCapNhatNoKhach_Click);
            // 
            // labelNoKhachNoKhach_Text
            // 
            this.labelNoKhachNoKhach_Text.AutoSize = true;
            this.labelNoKhachNoKhach_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNoKhachNoKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhachNoKhach_Text.ForeColor = System.Drawing.Color.Black;
            this.labelNoKhachNoKhach_Text.Location = new System.Drawing.Point(858, 200);
            this.labelNoKhachNoKhach_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelNoKhachNoKhach_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelNoKhachNoKhach_Text.Name = "labelNoKhachNoKhach_Text";
            this.labelNoKhachNoKhach_Text.Size = new System.Drawing.Size(190, 27);
            this.labelNoKhachNoKhach_Text.TabIndex = 52;
            // 
            // labelTongToaNoKhach_Text
            // 
            this.labelTongToaNoKhach_Text.AutoSize = true;
            this.labelTongToaNoKhach_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongToaNoKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaNoKhach_Text.ForeColor = System.Drawing.Color.Red;
            this.labelTongToaNoKhach_Text.Location = new System.Drawing.Point(858, 164);
            this.labelTongToaNoKhach_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelTongToaNoKhach_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelTongToaNoKhach_Text.Name = "labelTongToaNoKhach_Text";
            this.labelTongToaNoKhach_Text.Size = new System.Drawing.Size(190, 27);
            this.labelTongToaNoKhach_Text.TabIndex = 51;
            // 
            // labelTenKhachNoKhach_Text
            // 
            this.labelTenKhachNoKhach_Text.AutoSize = true;
            this.labelTenKhachNoKhach_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenKhachNoKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhachNoKhach_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTenKhachNoKhach_Text.Location = new System.Drawing.Point(858, 128);
            this.labelTenKhachNoKhach_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelTenKhachNoKhach_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelTenKhachNoKhach_Text.Name = "labelTenKhachNoKhach_Text";
            this.labelTenKhachNoKhach_Text.Size = new System.Drawing.Size(190, 27);
            this.labelTenKhachNoKhach_Text.TabIndex = 50;
            // 
            // labelMaToaNoKhach_Text
            // 
            this.labelMaToaNoKhach_Text.AutoSize = true;
            this.labelMaToaNoKhach_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMaToaNoKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaToaNoKhach_Text.ForeColor = System.Drawing.Color.Black;
            this.labelMaToaNoKhach_Text.Location = new System.Drawing.Point(858, 92);
            this.labelMaToaNoKhach_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelMaToaNoKhach_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelMaToaNoKhach_Text.Name = "labelMaToaNoKhach_Text";
            this.labelMaToaNoKhach_Text.Size = new System.Drawing.Size(190, 27);
            this.labelMaToaNoKhach_Text.TabIndex = 49;
            // 
            // labelThongTinToaNoKhach
            // 
            this.labelThongTinToaNoKhach.AutoSize = true;
            this.labelThongTinToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelThongTinToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinToaNoKhach.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinToaNoKhach.Location = new System.Drawing.Point(716, 48);
            this.labelThongTinToaNoKhach.Name = "labelThongTinToaNoKhach";
            this.labelThongTinToaNoKhach.Size = new System.Drawing.Size(212, 29);
            this.labelThongTinToaNoKhach.TabIndex = 48;
            this.labelThongTinToaNoKhach.Text = "THÔNG TIN TOA";
            // 
            // labelDanhSachToaNoKhach
            // 
            this.labelDanhSachToaNoKhach.AutoSize = true;
            this.labelDanhSachToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelDanhSachToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDanhSachToaNoKhach.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDanhSachToaNoKhach.Location = new System.Drawing.Point(0, 16);
            this.labelDanhSachToaNoKhach.Name = "labelDanhSachToaNoKhach";
            this.labelDanhSachToaNoKhach.Size = new System.Drawing.Size(356, 29);
            this.labelDanhSachToaNoKhach.TabIndex = 47;
            this.labelDanhSachToaNoKhach.Text = "DANH SÁCH TOA NỢ KHÁCH";
            // 
            // labelNoKhachNoKhach
            // 
            this.labelNoKhachNoKhach.AutoSize = true;
            this.labelNoKhachNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelNoKhachNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNoKhachNoKhach.ForeColor = System.Drawing.Color.Black;
            this.labelNoKhachNoKhach.Location = new System.Drawing.Point(719, 200);
            this.labelNoKhachNoKhach.Name = "labelNoKhachNoKhach";
            this.labelNoKhachNoKhach.Size = new System.Drawing.Size(118, 26);
            this.labelNoKhachNoKhach.TabIndex = 46;
            this.labelNoKhachNoKhach.Text = "Nợ khách:";
            // 
            // labelTongToaNoKhach
            // 
            this.labelTongToaNoKhach.AutoSize = true;
            this.labelTongToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaNoKhach.ForeColor = System.Drawing.Color.Black;
            this.labelTongToaNoKhach.Location = new System.Drawing.Point(719, 164);
            this.labelTongToaNoKhach.Name = "labelTongToaNoKhach";
            this.labelTongToaNoKhach.Size = new System.Drawing.Size(110, 26);
            this.labelTongToaNoKhach.TabIndex = 45;
            this.labelTongToaNoKhach.Text = "Tổng toa:";
            // 
            // labelTenKhachNoKhach
            // 
            this.labelTenKhachNoKhach.AutoSize = true;
            this.labelTenKhachNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenKhachNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhachNoKhach.ForeColor = System.Drawing.Color.Black;
            this.labelTenKhachNoKhach.Location = new System.Drawing.Point(719, 128);
            this.labelTenKhachNoKhach.Name = "labelTenKhachNoKhach";
            this.labelTenKhachNoKhach.Size = new System.Drawing.Size(127, 26);
            this.labelTenKhachNoKhach.TabIndex = 44;
            this.labelTenKhachNoKhach.Text = "Tên khách:";
            // 
            // labelMaToaNoKhach
            // 
            this.labelMaToaNoKhach.AutoSize = true;
            this.labelMaToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMaToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaToaNoKhach.ForeColor = System.Drawing.Color.Black;
            this.labelMaToaNoKhach.Location = new System.Drawing.Point(719, 92);
            this.labelMaToaNoKhach.Name = "labelMaToaNoKhach";
            this.labelMaToaNoKhach.Size = new System.Drawing.Size(93, 26);
            this.labelMaToaNoKhach.TabIndex = 43;
            this.labelMaToaNoKhach.Text = "Mã toa:";
            // 
            // textBoxTruNo
            // 
            this.textBoxTruNo.BackColor = System.Drawing.Color.White;
            this.textBoxTruNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTruNo.Location = new System.Drawing.Point(891, 263);
            this.textBoxTruNo.Name = "textBoxTruNo";
            this.textBoxTruNo.Size = new System.Drawing.Size(218, 34);
            this.textBoxTruNo.TabIndex = 37;
            this.textBoxTruNo.TextChanged += new System.EventHandler(this.textBoxTruNo_TextChanged);
            this.textBoxTruNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTruNo_KeyPress);
            // 
            // textBoxTinhTrangNoKhach
            // 
            this.textBoxTinhTrangNoKhach.BackColor = System.Drawing.Color.LightGray;
            this.textBoxTinhTrangNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTinhTrangNoKhach.Location = new System.Drawing.Point(891, 317);
            this.textBoxTinhTrangNoKhach.Name = "textBoxTinhTrangNoKhach";
            this.textBoxTinhTrangNoKhach.ReadOnly = true;
            this.textBoxTinhTrangNoKhach.Size = new System.Drawing.Size(218, 34);
            this.textBoxTinhTrangNoKhach.TabIndex = 42;
            // 
            // labelTruNo
            // 
            this.labelTruNo.AutoSize = true;
            this.labelTruNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTruNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTruNo.ForeColor = System.Drawing.Color.Black;
            this.labelTruNo.Location = new System.Drawing.Point(719, 271);
            this.labelTruNo.Name = "labelTruNo";
            this.labelTruNo.Size = new System.Drawing.Size(90, 26);
            this.labelTruNo.TabIndex = 38;
            this.labelTruNo.Text = "Trừ nợ:";
            // 
            // labelTinhTrangNoKhach
            // 
            this.labelTinhTrangNoKhach.AutoSize = true;
            this.labelTinhTrangNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTinhTrangNoKhach.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTinhTrangNoKhach.ForeColor = System.Drawing.Color.Black;
            this.labelTinhTrangNoKhach.Location = new System.Drawing.Point(719, 325);
            this.labelTinhTrangNoKhach.Name = "labelTinhTrangNoKhach";
            this.labelTinhTrangNoKhach.Size = new System.Drawing.Size(130, 26);
            this.labelTinhTrangNoKhach.TabIndex = 41;
            this.labelTinhTrangNoKhach.Text = "Tình trạng:";
            // 
            // dataGridViewToaNoKhach
            // 
            this.dataGridViewToaNoKhach.AllowDrop = true;
            this.dataGridViewToaNoKhach.AllowUserToAddRows = false;
            this.dataGridViewToaNoKhach.AllowUserToDeleteRows = false;
            this.dataGridViewToaNoKhach.AllowUserToOrderColumns = true;
            this.dataGridViewToaNoKhach.AllowUserToResizeRows = false;
            this.dataGridViewToaNoKhach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewToaNoKhach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewToaNoKhach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnNgayLapToaNoKhach,
            this.ColumnMaToaNoKhach,
            this.ColumnTenKHNoKhach,
            this.ColumnTongToaNoKhach,
            this.ColumnNoKhach});
            this.dataGridViewToaNoKhach.Location = new System.Drawing.Point(3, 48);
            this.dataGridViewToaNoKhach.MultiSelect = false;
            this.dataGridViewToaNoKhach.Name = "dataGridViewToaNoKhach";
            this.dataGridViewToaNoKhach.ReadOnly = true;
            this.dataGridViewToaNoKhach.RowHeadersVisible = false;
            this.dataGridViewToaNoKhach.RowHeadersWidth = 51;
            this.dataGridViewToaNoKhach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewToaNoKhach.RowTemplate.Height = 24;
            this.dataGridViewToaNoKhach.Size = new System.Drawing.Size(710, 488);
            this.dataGridViewToaNoKhach.TabIndex = 0;
            this.dataGridViewToaNoKhach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewToaNoKhach_CellClick);
            // 
            // ColumnNgayLapToaNoKhach
            // 
            this.ColumnNgayLapToaNoKhach.DataPropertyName = "NgayLapToa";
            this.ColumnNgayLapToaNoKhach.FillWeight = 106.2834F;
            this.ColumnNgayLapToaNoKhach.HeaderText = "Ngày lập toa";
            this.ColumnNgayLapToaNoKhach.MinimumWidth = 6;
            this.ColumnNgayLapToaNoKhach.Name = "ColumnNgayLapToaNoKhach";
            this.ColumnNgayLapToaNoKhach.ReadOnly = true;
            // 
            // ColumnMaToaNoKhach
            // 
            this.ColumnMaToaNoKhach.DataPropertyName = "MaToa";
            this.ColumnMaToaNoKhach.FillWeight = 74.86631F;
            this.ColumnMaToaNoKhach.HeaderText = "Mã toa";
            this.ColumnMaToaNoKhach.MinimumWidth = 6;
            this.ColumnMaToaNoKhach.Name = "ColumnMaToaNoKhach";
            this.ColumnMaToaNoKhach.ReadOnly = true;
            // 
            // ColumnTenKHNoKhach
            // 
            this.ColumnTenKHNoKhach.DataPropertyName = "TenKhachHang";
            this.ColumnTenKHNoKhach.FillWeight = 106.2834F;
            this.ColumnTenKHNoKhach.HeaderText = "Tên KH";
            this.ColumnTenKHNoKhach.MinimumWidth = 6;
            this.ColumnTenKHNoKhach.Name = "ColumnTenKHNoKhach";
            this.ColumnTenKHNoKhach.ReadOnly = true;
            // 
            // ColumnTongToaNoKhach
            // 
            this.ColumnTongToaNoKhach.DataPropertyName = "TongToa";
            dataGridViewCellStyle1.Format = "C0";
            dataGridViewCellStyle1.NullValue = null;
            this.ColumnTongToaNoKhach.DefaultCellStyle = dataGridViewCellStyle1;
            this.ColumnTongToaNoKhach.FillWeight = 106.2834F;
            this.ColumnTongToaNoKhach.HeaderText = "Tổng toa";
            this.ColumnTongToaNoKhach.MinimumWidth = 6;
            this.ColumnTongToaNoKhach.Name = "ColumnTongToaNoKhach";
            this.ColumnTongToaNoKhach.ReadOnly = true;
            // 
            // ColumnNoKhach
            // 
            this.ColumnNoKhach.DataPropertyName = "NoKhach";
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = null;
            this.ColumnNoKhach.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnNoKhach.FillWeight = 106.2834F;
            this.ColumnNoKhach.HeaderText = "Nợ khách";
            this.ColumnNoKhach.MinimumWidth = 6;
            this.ColumnNoKhach.Name = "ColumnNoKhach";
            this.ColumnNoKhach.ReadOnly = true;
            // 
            // tabPageToaKhachNo
            // 
            this.tabPageToaKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPageToaKhachNo.Controls.Add(this.labelMaToaKhachNo_Text);
            this.tabPageToaKhachNo.Controls.Add(this.labelMaToaKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.textBoxTinhTrangKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.textBoxTraNoKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelKhachNo_Text);
            this.tabPageToaKhachNo.Controls.Add(this.labelTongToaKhachNo_Text);
            this.tabPageToaKhachNo.Controls.Add(this.labelTenKhachKhachNo_Text);
            this.tabPageToaKhachNo.Controls.Add(this.labelKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelTinhTrangKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelTongToaKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelTenKhachKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelThongTinToaKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.labelTraNoKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.buttonCapNhat);
            this.tabPageToaKhachNo.Controls.Add(this.labelDanhSachToaKhachNo);
            this.tabPageToaKhachNo.Controls.Add(this.dataGridViewToaKhachNo);
            this.tabPageToaKhachNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabPageToaKhachNo.Location = new System.Drawing.Point(4, 34);
            this.tabPageToaKhachNo.Name = "tabPageToaKhachNo";
            this.tabPageToaKhachNo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageToaKhachNo.Size = new System.Drawing.Size(1117, 539);
            this.tabPageToaKhachNo.TabIndex = 1;
            this.tabPageToaKhachNo.Text = "Toa khách nợ";
            // 
            // labelMaToaKhachNo_Text
            // 
            this.labelMaToaKhachNo_Text.AutoSize = true;
            this.labelMaToaKhachNo_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMaToaKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaToaKhachNo_Text.ForeColor = System.Drawing.Color.Black;
            this.labelMaToaKhachNo_Text.Location = new System.Drawing.Point(886, 92);
            this.labelMaToaKhachNo_Text.MaximumSize = new System.Drawing.Size(160, 27);
            this.labelMaToaKhachNo_Text.MinimumSize = new System.Drawing.Size(160, 27);
            this.labelMaToaKhachNo_Text.Name = "labelMaToaKhachNo_Text";
            this.labelMaToaKhachNo_Text.Size = new System.Drawing.Size(160, 27);
            this.labelMaToaKhachNo_Text.TabIndex = 56;
            this.labelMaToaKhachNo_Text.Text = "1";
            // 
            // labelMaToaKhachNo
            // 
            this.labelMaToaKhachNo.AutoSize = true;
            this.labelMaToaKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMaToaKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaToaKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelMaToaKhachNo.Location = new System.Drawing.Point(719, 92);
            this.labelMaToaKhachNo.Name = "labelMaToaKhachNo";
            this.labelMaToaKhachNo.Size = new System.Drawing.Size(93, 26);
            this.labelMaToaKhachNo.TabIndex = 55;
            this.labelMaToaKhachNo.Text = "Mã toa:";
            // 
            // textBoxTinhTrangKhachNo
            // 
            this.textBoxTinhTrangKhachNo.BackColor = System.Drawing.Color.LightGray;
            this.textBoxTinhTrangKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTinhTrangKhachNo.Location = new System.Drawing.Point(891, 317);
            this.textBoxTinhTrangKhachNo.Name = "textBoxTinhTrangKhachNo";
            this.textBoxTinhTrangKhachNo.ReadOnly = true;
            this.textBoxTinhTrangKhachNo.Size = new System.Drawing.Size(218, 34);
            this.textBoxTinhTrangKhachNo.TabIndex = 54;
            this.textBoxTinhTrangKhachNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxTraNoKhachNo
            // 
            this.textBoxTraNoKhachNo.BackColor = System.Drawing.Color.White;
            this.textBoxTraNoKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTraNoKhachNo.Location = new System.Drawing.Point(891, 263);
            this.textBoxTraNoKhachNo.Name = "textBoxTraNoKhachNo";
            this.textBoxTraNoKhachNo.Size = new System.Drawing.Size(218, 34);
            this.textBoxTraNoKhachNo.TabIndex = 42;
            this.textBoxTraNoKhachNo.Text = "0";
            this.textBoxTraNoKhachNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTraNoKhachNo.TextChanged += new System.EventHandler(this.textBoxTraNoKhachNo_TextChanged);
            this.textBoxTraNoKhachNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTraNoKhachNo_KeyPress);
            // 
            // labelKhachNo_Text
            // 
            this.labelKhachNo_Text.AutoSize = true;
            this.labelKhachNo_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo_Text.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNo_Text.Location = new System.Drawing.Point(886, 200);
            this.labelKhachNo_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelKhachNo_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelKhachNo_Text.Name = "labelKhachNo_Text";
            this.labelKhachNo_Text.Size = new System.Drawing.Size(190, 27);
            this.labelKhachNo_Text.TabIndex = 53;
            this.labelKhachNo_Text.Text = "1000000000";
            // 
            // labelTongToaKhachNo_Text
            // 
            this.labelTongToaKhachNo_Text.AutoSize = true;
            this.labelTongToaKhachNo_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongToaKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaKhachNo_Text.ForeColor = System.Drawing.Color.Red;
            this.labelTongToaKhachNo_Text.Location = new System.Drawing.Point(886, 164);
            this.labelTongToaKhachNo_Text.MaximumSize = new System.Drawing.Size(190, 27);
            this.labelTongToaKhachNo_Text.MinimumSize = new System.Drawing.Size(190, 27);
            this.labelTongToaKhachNo_Text.Name = "labelTongToaKhachNo_Text";
            this.labelTongToaKhachNo_Text.Size = new System.Drawing.Size(190, 27);
            this.labelTongToaKhachNo_Text.TabIndex = 52;
            this.labelTongToaKhachNo_Text.Text = "1000000000";
            // 
            // labelTenKhachKhachNo_Text
            // 
            this.labelTenKhachKhachNo_Text.AutoSize = true;
            this.labelTenKhachKhachNo_Text.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenKhachKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhachKhachNo_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTenKhachKhachNo_Text.Location = new System.Drawing.Point(886, 128);
            this.labelTenKhachKhachNo_Text.MaximumSize = new System.Drawing.Size(160, 27);
            this.labelTenKhachKhachNo_Text.MinimumSize = new System.Drawing.Size(160, 27);
            this.labelTenKhachKhachNo_Text.Name = "labelTenKhachKhachNo_Text";
            this.labelTenKhachKhachNo_Text.Size = new System.Drawing.Size(160, 27);
            this.labelTenKhachKhachNo_Text.TabIndex = 51;
            this.labelTenKhachKhachNo_Text.Text = "đinh trung hiếu 123";
            // 
            // labelKhachNo
            // 
            this.labelKhachNo.AutoSize = true;
            this.labelKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelKhachNo.Location = new System.Drawing.Point(719, 200);
            this.labelKhachNo.Name = "labelKhachNo";
            this.labelKhachNo.Size = new System.Drawing.Size(120, 26);
            this.labelKhachNo.TabIndex = 49;
            this.labelKhachNo.Text = "Khách nợ:";
            // 
            // labelTinhTrangKhachNo
            // 
            this.labelTinhTrangKhachNo.AutoSize = true;
            this.labelTinhTrangKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTinhTrangKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTinhTrangKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelTinhTrangKhachNo.Location = new System.Drawing.Point(719, 325);
            this.labelTinhTrangKhachNo.Name = "labelTinhTrangKhachNo";
            this.labelTinhTrangKhachNo.Size = new System.Drawing.Size(130, 26);
            this.labelTinhTrangKhachNo.TabIndex = 47;
            this.labelTinhTrangKhachNo.Text = "Tình trạng:";
            // 
            // labelTongToaKhachNo
            // 
            this.labelTongToaKhachNo.AutoSize = true;
            this.labelTongToaKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTongToaKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelTongToaKhachNo.Location = new System.Drawing.Point(719, 164);
            this.labelTongToaKhachNo.Name = "labelTongToaKhachNo";
            this.labelTongToaKhachNo.Size = new System.Drawing.Size(110, 26);
            this.labelTongToaKhachNo.TabIndex = 46;
            this.labelTongToaKhachNo.Text = "Tổng toa:";
            // 
            // labelTenKhachKhachNo
            // 
            this.labelTenKhachKhachNo.AutoSize = true;
            this.labelTenKhachKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenKhachKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhachKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelTenKhachKhachNo.Location = new System.Drawing.Point(719, 128);
            this.labelTenKhachKhachNo.Name = "labelTenKhachKhachNo";
            this.labelTenKhachKhachNo.Size = new System.Drawing.Size(127, 26);
            this.labelTenKhachKhachNo.TabIndex = 45;
            this.labelTenKhachKhachNo.Text = "Tên khách:";
            // 
            // labelThongTinToaKhachNo
            // 
            this.labelThongTinToaKhachNo.AutoSize = true;
            this.labelThongTinToaKhachNo.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinToaKhachNo.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinToaKhachNo.Location = new System.Drawing.Point(719, 48);
            this.labelThongTinToaKhachNo.Name = "labelThongTinToaKhachNo";
            this.labelThongTinToaKhachNo.Size = new System.Drawing.Size(212, 29);
            this.labelThongTinToaKhachNo.TabIndex = 43;
            this.labelThongTinToaKhachNo.Text = "THÔNG TIN TOA";
            // 
            // labelTraNoKhachNo
            // 
            this.labelTraNoKhachNo.AutoSize = true;
            this.labelTraNoKhachNo.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTraNoKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTraNoKhachNo.ForeColor = System.Drawing.Color.Black;
            this.labelTraNoKhachNo.Location = new System.Drawing.Point(719, 271);
            this.labelTraNoKhachNo.Name = "labelTraNoKhachNo";
            this.labelTraNoKhachNo.Size = new System.Drawing.Size(88, 26);
            this.labelTraNoKhachNo.TabIndex = 41;
            this.labelTraNoKhachNo.Text = "Trả nợ:";
            // 
            // buttonCapNhat
            // 
            this.buttonCapNhat.BackColor = System.Drawing.Color.Red;
            this.buttonCapNhat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonCapNhat.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhat.Location = new System.Drawing.Point(959, 364);
            this.buttonCapNhat.Name = "buttonCapNhat";
            this.buttonCapNhat.Size = new System.Drawing.Size(151, 50);
            this.buttonCapNhat.TabIndex = 8;
            this.buttonCapNhat.Text = "Cập nhật";
            this.buttonCapNhat.UseVisualStyleBackColor = false;
            this.buttonCapNhat.Click += new System.EventHandler(this.buttonCapNhat_Click);
            // 
            // labelDanhSachToaKhachNo
            // 
            this.labelDanhSachToaKhachNo.AutoSize = true;
            this.labelDanhSachToaKhachNo.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDanhSachToaKhachNo.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDanhSachToaKhachNo.Location = new System.Drawing.Point(0, 16);
            this.labelDanhSachToaKhachNo.Name = "labelDanhSachToaKhachNo";
            this.labelDanhSachToaKhachNo.Size = new System.Drawing.Size(356, 29);
            this.labelDanhSachToaKhachNo.TabIndex = 1;
            this.labelDanhSachToaKhachNo.Text = "DANH SÁCH TOA KHÁCH NỢ";
            // 
            // dataGridViewToaKhachNo
            // 
            this.dataGridViewToaKhachNo.AllowDrop = true;
            this.dataGridViewToaKhachNo.AllowUserToAddRows = false;
            this.dataGridViewToaKhachNo.AllowUserToDeleteRows = false;
            this.dataGridViewToaKhachNo.AllowUserToResizeColumns = false;
            this.dataGridViewToaKhachNo.AllowUserToResizeRows = false;
            this.dataGridViewToaKhachNo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewToaKhachNo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewToaKhachNo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnNgayLapToaKhachNo,
            this.ColumnSDTKhachKhachNo,
            this.ColumnTenKhachKhachNo,
            this.ColumnTongToaKhachNo,
            this.ColumnKhachNo});
            this.dataGridViewToaKhachNo.Location = new System.Drawing.Point(3, 48);
            this.dataGridViewToaKhachNo.MultiSelect = false;
            this.dataGridViewToaKhachNo.Name = "dataGridViewToaKhachNo";
            this.dataGridViewToaKhachNo.ReadOnly = true;
            this.dataGridViewToaKhachNo.RowHeadersVisible = false;
            this.dataGridViewToaKhachNo.RowHeadersWidth = 51;
            this.dataGridViewToaKhachNo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewToaKhachNo.RowTemplate.Height = 24;
            this.dataGridViewToaKhachNo.Size = new System.Drawing.Size(710, 488);
            this.dataGridViewToaKhachNo.TabIndex = 0;
            this.dataGridViewToaKhachNo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewToaKhachNo_CellClick);
            // 
            // ColumnNgayLapToaKhachNo
            // 
            this.ColumnNgayLapToaKhachNo.DataPropertyName = "NgayLapToa";
            this.ColumnNgayLapToaKhachNo.FillWeight = 112.2174F;
            this.ColumnNgayLapToaKhachNo.HeaderText = "Ngày lập toa";
            this.ColumnNgayLapToaKhachNo.MinimumWidth = 6;
            this.ColumnNgayLapToaKhachNo.Name = "ColumnNgayLapToaKhachNo";
            this.ColumnNgayLapToaKhachNo.ReadOnly = true;
            // 
            // ColumnSDTKhachKhachNo
            // 
            this.ColumnSDTKhachKhachNo.DataPropertyName = "MaToa";
            this.ColumnSDTKhachKhachNo.FillWeight = 74.86632F;
            this.ColumnSDTKhachKhachNo.HeaderText = "Mã toa";
            this.ColumnSDTKhachKhachNo.MinimumWidth = 6;
            this.ColumnSDTKhachKhachNo.Name = "ColumnSDTKhachKhachNo";
            this.ColumnSDTKhachKhachNo.ReadOnly = true;
            // 
            // ColumnTenKhachKhachNo
            // 
            this.ColumnTenKhachKhachNo.DataPropertyName = "TenKhachHang";
            this.ColumnTenKhachKhachNo.FillWeight = 103.5623F;
            this.ColumnTenKhachKhachNo.HeaderText = "Tên KH";
            this.ColumnTenKhachKhachNo.MinimumWidth = 6;
            this.ColumnTenKhachKhachNo.Name = "ColumnTenKhachKhachNo";
            this.ColumnTenKhachKhachNo.ReadOnly = true;
            // 
            // ColumnTongToaKhachNo
            // 
            this.ColumnTongToaKhachNo.DataPropertyName = "TongToa";
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = null;
            this.ColumnTongToaKhachNo.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnTongToaKhachNo.FillWeight = 99.35147F;
            this.ColumnTongToaKhachNo.HeaderText = "Tổng toa";
            this.ColumnTongToaKhachNo.MinimumWidth = 6;
            this.ColumnTongToaKhachNo.Name = "ColumnTongToaKhachNo";
            this.ColumnTongToaKhachNo.ReadOnly = true;
            // 
            // ColumnKhachNo
            // 
            this.ColumnKhachNo.DataPropertyName = "KhachNo";
            dataGridViewCellStyle4.Format = "C0";
            dataGridViewCellStyle4.NullValue = null;
            this.ColumnKhachNo.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnKhachNo.FillWeight = 110.0026F;
            this.ColumnKhachNo.HeaderText = "Khách nợ";
            this.ColumnKhachNo.MinimumWidth = 6;
            this.ColumnKhachNo.Name = "ColumnKhachNo";
            this.ColumnKhachNo.ReadOnly = true;
            // 
            // tabPageDanhSachToa
            // 
            this.tabPageDanhSachToa.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPageDanhSachToa.Controls.Add(this.labelTimKiem);
            this.tabPageDanhSachToa.Controls.Add(this.textBoxTimKiem);
            this.tabPageDanhSachToa.Controls.Add(this.buttonChiTietToa);
            this.tabPageDanhSachToa.Controls.Add(this.buttonHienDanhSachBill);
            this.tabPageDanhSachToa.Controls.Add(this.labelDenNgay);
            this.tabPageDanhSachToa.Controls.Add(this.labelTuNgay);
            this.tabPageDanhSachToa.Controls.Add(this.dateTimePickerDenNgay);
            this.tabPageDanhSachToa.Controls.Add(this.dataGridViewToa);
            this.tabPageDanhSachToa.Controls.Add(this.dateTimePickerTuNgay);
            this.tabPageDanhSachToa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageDanhSachToa.Location = new System.Drawing.Point(4, 34);
            this.tabPageDanhSachToa.Name = "tabPageDanhSachToa";
            this.tabPageDanhSachToa.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDanhSachToa.Size = new System.Drawing.Size(1117, 539);
            this.tabPageDanhSachToa.TabIndex = 0;
            this.tabPageDanhSachToa.Text = "Danh sách toa";
            // 
            // labelTimKiem
            // 
            this.labelTimKiem.AutoSize = true;
            this.labelTimKiem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTimKiem.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTimKiem.Location = new System.Drawing.Point(847, 13);
            this.labelTimKiem.Name = "labelTimKiem";
            this.labelTimKiem.Size = new System.Drawing.Size(117, 26);
            this.labelTimKiem.TabIndex = 11;
            this.labelTimKiem.Text = "Tìm kiếm:";
            // 
            // textBoxTimKiem
            // 
            this.textBoxTimKiem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimKiem.Location = new System.Drawing.Point(853, 45);
            this.textBoxTimKiem.Name = "textBoxTimKiem";
            this.textBoxTimKiem.Size = new System.Drawing.Size(260, 34);
            this.textBoxTimKiem.TabIndex = 10;
            this.textBoxTimKiem.TextChanged += new System.EventHandler(this.textBoxTimKiem_TextChanged);
            // 
            // buttonChiTietToa
            // 
            this.buttonChiTietToa.BackColor = System.Drawing.Color.Red;
            this.buttonChiTietToa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonChiTietToa.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonChiTietToa.Image = ((System.Drawing.Image)(resources.GetObject("buttonChiTietToa.Image")));
            this.buttonChiTietToa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonChiTietToa.Location = new System.Drawing.Point(335, 44);
            this.buttonChiTietToa.Name = "buttonChiTietToa";
            this.buttonChiTietToa.Size = new System.Drawing.Size(179, 39);
            this.buttonChiTietToa.TabIndex = 9;
            this.buttonChiTietToa.Text = "Chi tiết toa";
            this.buttonChiTietToa.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonChiTietToa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonChiTietToa.UseVisualStyleBackColor = false;
            this.buttonChiTietToa.Click += new System.EventHandler(this.buttonChiTietToa_Click);
            // 
            // buttonHienDanhSachBill
            // 
            this.buttonHienDanhSachBill.BackColor = System.Drawing.Color.Red;
            this.buttonHienDanhSachBill.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonHienDanhSachBill.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonHienDanhSachBill.Image = ((System.Drawing.Image)(resources.GetObject("buttonHienDanhSachBill.Image")));
            this.buttonHienDanhSachBill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHienDanhSachBill.Location = new System.Drawing.Point(335, 5);
            this.buttonHienDanhSachBill.Name = "buttonHienDanhSachBill";
            this.buttonHienDanhSachBill.Size = new System.Drawing.Size(179, 39);
            this.buttonHienDanhSachBill.TabIndex = 8;
            this.buttonHienDanhSachBill.Text = "Danh sách toa";
            this.buttonHienDanhSachBill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonHienDanhSachBill.UseVisualStyleBackColor = false;
            this.buttonHienDanhSachBill.Click += new System.EventHandler(this.buttonHienDanhSachBill_Click);
            // 
            // labelDenNgay
            // 
            this.labelDenNgay.AutoSize = true;
            this.labelDenNgay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDenNgay.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDenNgay.Location = new System.Drawing.Point(0, 53);
            this.labelDenNgay.Name = "labelDenNgay";
            this.labelDenNgay.Size = new System.Drawing.Size(61, 26);
            this.labelDenNgay.TabIndex = 4;
            this.labelDenNgay.Text = "Đến:";
            // 
            // labelTuNgay
            // 
            this.labelTuNgay.AutoSize = true;
            this.labelTuNgay.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTuNgay.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTuNgay.Location = new System.Drawing.Point(0, 10);
            this.labelTuNgay.Name = "labelTuNgay";
            this.labelTuNgay.Size = new System.Drawing.Size(49, 26);
            this.labelTuNgay.TabIndex = 3;
            this.labelTuNgay.Text = "Từ:";
            // 
            // dateTimePickerDenNgay
            // 
            this.dateTimePickerDenNgay.CustomFormat = "";
            this.dateTimePickerDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerDenNgay.Location = new System.Drawing.Point(129, 49);
            this.dateTimePickerDenNgay.Name = "dateTimePickerDenNgay";
            this.dateTimePickerDenNgay.Size = new System.Drawing.Size(200, 30);
            this.dateTimePickerDenNgay.TabIndex = 1;
            // 
            // dataGridViewToa
            // 
            this.dataGridViewToa.AllowDrop = true;
            this.dataGridViewToa.AllowUserToAddRows = false;
            this.dataGridViewToa.AllowUserToDeleteRows = false;
            this.dataGridViewToa.AllowUserToResizeColumns = false;
            this.dataGridViewToa.AllowUserToResizeRows = false;
            this.dataGridViewToa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewToa.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewToa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewToa.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnNgayLapToa,
            this.ColumnMaToa,
            this.ColumnTenKhachHang,
            this.ColumnSDTKH,
            this.ColumnTongToa,
            this.ColumnHinhThucThanhToan});
            this.dataGridViewToa.Location = new System.Drawing.Point(3, 89);
            this.dataGridViewToa.MultiSelect = false;
            this.dataGridViewToa.Name = "dataGridViewToa";
            this.dataGridViewToa.ReadOnly = true;
            this.dataGridViewToa.RowHeadersVisible = false;
            this.dataGridViewToa.RowHeadersWidth = 51;
            this.dataGridViewToa.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewToa.RowTemplate.Height = 24;
            this.dataGridViewToa.Size = new System.Drawing.Size(1111, 447);
            this.dataGridViewToa.TabIndex = 0;
            this.dataGridViewToa.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewToa_CellClick);
            // 
            // ColumnNgayLapToa
            // 
            this.ColumnNgayLapToa.DataPropertyName = "NgayLapToa";
            this.ColumnNgayLapToa.FillWeight = 95.68793F;
            this.ColumnNgayLapToa.HeaderText = "Ngày lập toa";
            this.ColumnNgayLapToa.MinimumWidth = 6;
            this.ColumnNgayLapToa.Name = "ColumnNgayLapToa";
            this.ColumnNgayLapToa.ReadOnly = true;
            this.ColumnNgayLapToa.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnMaToa
            // 
            this.ColumnMaToa.DataPropertyName = "MaToa";
            this.ColumnMaToa.FillWeight = 73.79681F;
            this.ColumnMaToa.HeaderText = "Mã toa";
            this.ColumnMaToa.MinimumWidth = 7;
            this.ColumnMaToa.Name = "ColumnMaToa";
            this.ColumnMaToa.ReadOnly = true;
            this.ColumnMaToa.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnTenKhachHang
            // 
            this.ColumnTenKhachHang.DataPropertyName = "TenKhachHang";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            this.ColumnTenKhachHang.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnTenKhachHang.FillWeight = 108.8907F;
            this.ColumnTenKhachHang.HeaderText = "Tên KH";
            this.ColumnTenKhachHang.MinimumWidth = 6;
            this.ColumnTenKhachHang.Name = "ColumnTenKhachHang";
            this.ColumnTenKhachHang.ReadOnly = true;
            this.ColumnTenKhachHang.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnSDTKH
            // 
            this.ColumnSDTKH.DataPropertyName = "SDTKhachHang";
            this.ColumnSDTKH.FillWeight = 85.86034F;
            this.ColumnSDTKH.HeaderText = "SĐT";
            this.ColumnSDTKH.MinimumWidth = 6;
            this.ColumnSDTKH.Name = "ColumnSDTKH";
            this.ColumnSDTKH.ReadOnly = true;
            // 
            // ColumnTongToa
            // 
            this.ColumnTongToa.DataPropertyName = "TongToa";
            dataGridViewCellStyle6.Format = "C0";
            dataGridViewCellStyle6.NullValue = null;
            this.ColumnTongToa.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnTongToa.FillWeight = 88.55297F;
            this.ColumnTongToa.HeaderText = "Tổng toa";
            this.ColumnTongToa.MinimumWidth = 6;
            this.ColumnTongToa.Name = "ColumnTongToa";
            this.ColumnTongToa.ReadOnly = true;
            // 
            // ColumnHinhThucThanhToan
            // 
            this.ColumnHinhThucThanhToan.DataPropertyName = "HinhThucThanhToan";
            this.ColumnHinhThucThanhToan.FillWeight = 147.2114F;
            this.ColumnHinhThucThanhToan.HeaderText = "Hình thức thanh toán";
            this.ColumnHinhThucThanhToan.MinimumWidth = 6;
            this.ColumnHinhThucThanhToan.Name = "ColumnHinhThucThanhToan";
            this.ColumnHinhThucThanhToan.ReadOnly = true;
            // 
            // dateTimePickerTuNgay
            // 
            this.dateTimePickerTuNgay.AllowDrop = true;
            this.dateTimePickerTuNgay.CustomFormat = "";
            this.dateTimePickerTuNgay.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerTuNgay.Location = new System.Drawing.Point(129, 6);
            this.dateTimePickerTuNgay.Name = "dateTimePickerTuNgay";
            this.dateTimePickerTuNgay.Size = new System.Drawing.Size(200, 30);
            this.dateTimePickerTuNgay.TabIndex = 108;
            this.dateTimePickerTuNgay.Value = new System.DateTime(2020, 1, 10, 0, 0, 0, 0);
            // 
            // tabControlToa
            // 
            this.tabControlToa.Controls.Add(this.tabPageDanhSachToa);
            this.tabControlToa.Controls.Add(this.tabPageToaKhachNo);
            this.tabControlToa.Controls.Add(this.tabPageToaNoKhach);
            this.tabControlToa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlToa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabControlToa.Location = new System.Drawing.Point(0, 35);
            this.tabControlToa.Name = "tabControlToa";
            this.tabControlToa.SelectedIndex = 0;
            this.tabControlToa.Size = new System.Drawing.Size(1125, 577);
            this.tabControlToa.TabIndex = 92;
            // 
            // formQuanLyToa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 612);
            this.Controls.Add(this.tabControlToa);
            this.Controls.Add(this.panelThanhTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formQuanLyToa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formQuanLyToa";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.tabPageToaNoKhach.ResumeLayout(false);
            this.tabPageToaNoKhach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToaNoKhach)).EndInit();
            this.tabPageToaKhachNo.ResumeLayout(false);
            this.tabPageToaKhachNo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToaKhachNo)).EndInit();
            this.tabPageDanhSachToa.ResumeLayout(false);
            this.tabPageDanhSachToa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewToa)).EndInit();
            this.tabControlToa.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.TabPage tabPageToaNoKhach;
        private System.Windows.Forms.Button buttonCapNhatNoKhach;
        private System.Windows.Forms.Label labelNoKhachNoKhach_Text;
        private System.Windows.Forms.Label labelTongToaNoKhach_Text;
        private System.Windows.Forms.Label labelTenKhachNoKhach_Text;
        private System.Windows.Forms.Label labelMaToaNoKhach_Text;
        private System.Windows.Forms.Label labelThongTinToaNoKhach;
        private System.Windows.Forms.Label labelDanhSachToaNoKhach;
        private System.Windows.Forms.Label labelNoKhachNoKhach;
        private System.Windows.Forms.Label labelTongToaNoKhach;
        private System.Windows.Forms.Label labelTenKhachNoKhach;
        private System.Windows.Forms.Label labelMaToaNoKhach;
        private System.Windows.Forms.TextBox textBoxTruNo;
        private System.Windows.Forms.TextBox textBoxTinhTrangNoKhach;
        private System.Windows.Forms.Label labelTruNo;
        private System.Windows.Forms.Label labelTinhTrangNoKhach;
        private System.Windows.Forms.DataGridView dataGridViewToaNoKhach;
        private System.Windows.Forms.TabPage tabPageToaKhachNo;
        private System.Windows.Forms.Label labelMaToaKhachNo_Text;
        private System.Windows.Forms.Label labelMaToaKhachNo;
        private System.Windows.Forms.TextBox textBoxTinhTrangKhachNo;
        private System.Windows.Forms.TextBox textBoxTraNoKhachNo;
        private System.Windows.Forms.Label labelKhachNo_Text;
        private System.Windows.Forms.Label labelTongToaKhachNo_Text;
        private System.Windows.Forms.Label labelTenKhachKhachNo_Text;
        private System.Windows.Forms.Label labelKhachNo;
        private System.Windows.Forms.Label labelTinhTrangKhachNo;
        private System.Windows.Forms.Label labelTongToaKhachNo;
        private System.Windows.Forms.Label labelTenKhachKhachNo;
        private System.Windows.Forms.Label labelThongTinToaKhachNo;
        private System.Windows.Forms.Label labelTraNoKhachNo;
        private System.Windows.Forms.Button buttonCapNhat;
        private System.Windows.Forms.Label labelDanhSachToaKhachNo;
        private System.Windows.Forms.DataGridView dataGridViewToaKhachNo;
        private System.Windows.Forms.TabPage tabPageDanhSachToa;
        private System.Windows.Forms.Label labelTimKiem;
        private System.Windows.Forms.TextBox textBoxTimKiem;
        private System.Windows.Forms.Button buttonChiTietToa;
        private System.Windows.Forms.Button buttonHienDanhSachBill;
        private System.Windows.Forms.Label labelDenNgay;
        private System.Windows.Forms.Label labelTuNgay;
        private System.Windows.Forms.DateTimePicker dateTimePickerDenNgay;
        private System.Windows.Forms.DataGridView dataGridViewToa;
        private System.Windows.Forms.TabControl tabControlToa;
        private System.Windows.Forms.DateTimePicker dateTimePickerTuNgay;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgayLapToaKhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSDTKhachKhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenKhachKhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongToaKhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnKhachNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgayLapToaNoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMaToaNoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenKHNoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongToaNoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNoKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgayLapToa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMaToa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenKhachHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSDTKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongToa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnHinhThucThanhToan;
    }
}