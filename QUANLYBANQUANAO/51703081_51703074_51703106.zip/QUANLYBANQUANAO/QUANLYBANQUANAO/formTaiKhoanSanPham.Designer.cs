﻿namespace QUANLYBANQUANAO
{
    partial class formTaiKhoanSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formTaiKhoanSanPham));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.tabControlTaiKhoanSanPham = new System.Windows.Forms.TabControl();
            this.tabPageTaiKhoan = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.buttonXoaAnhNhanVien = new System.Windows.Forms.Button();
            this.pictureBoxThongBaoTKTC = new System.Windows.Forms.PictureBox();
            this.buttonThemAnhNhanVien = new System.Windows.Forms.Button();
            this.pictureBoxNhanVien = new System.Windows.Forms.PictureBox();
            this.numericUpDownLoaiTaiKhoan = new System.Windows.Forms.NumericUpDown();
            this.textBoxTenHienThi = new System.Windows.Forms.TextBox();
            this.labelLoiTenHienThi = new System.Windows.Forms.Label();
            this.textBoxTaiKhoan = new System.Windows.Forms.TextBox();
            this.labelLoiTaiKhoan = new System.Windows.Forms.Label();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textBoxMatKhau = new System.Windows.Forms.TextBox();
            this.labelThongTinToaNoKhach = new System.Windows.Forms.Label();
            this.labelLoaiTaiKhoan = new System.Windows.Forms.Label();
            this.labelSDT = new System.Windows.Forms.Label();
            this.labelTenHienThi = new System.Windows.Forms.Label();
            this.labelMatKhau = new System.Windows.Forms.Label();
            this.labelTaiKhoan = new System.Windows.Forms.Label();
            this.textBoxTimKiem = new System.Windows.Forms.TextBox();
            this.buttonRefesh = new System.Windows.Forms.Button();
            this.buttonSua = new System.Windows.Forms.Button();
            this.buttonXoa = new System.Windows.Forms.Button();
            this.buttonThem = new System.Windows.Forms.Button();
            this.dataGridViewTaiKhoan = new System.Windows.Forms.DataGridView();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MatKhau = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHienThi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiTaiKhoan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageSanPham = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonXoaHinhSanPham = new System.Windows.Forms.Button();
            this.buttonThemHinhSanPham = new System.Windows.Forms.Button();
            this.pictureBoxHinhSanPham = new System.Windows.Forms.PictureBox();
            this.buttonDSPN = new System.Windows.Forms.Button();
            this.numericUpDownGiaGoc = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownGiaBan = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSLTon = new System.Windows.Forms.NumericUpDown();
            this.buttonThemDanhMuc = new System.Windows.Forms.Button();
            this.comboBoxDanhMuc = new System.Windows.Forms.ComboBox();
            this.textBoxTenSP = new System.Windows.Forms.TextBox();
            this.labelThongTinSanPham = new System.Windows.Forms.Label();
            this.textBoxTimKiemSP = new System.Windows.Forms.TextBox();
            this.labelSLTon = new System.Windows.Forms.Label();
            this.labelDanhMuc = new System.Windows.Forms.Label();
            this.labelGiaGoc = new System.Windows.Forms.Label();
            this.labelTenSP = new System.Windows.Forms.Label();
            this.labelGiaBan = new System.Windows.Forms.Label();
            this.labelMaSP = new System.Windows.Forms.Label();
            this.textBoxMaSP = new System.Windows.Forms.TextBox();
            this.buttonRefeshSP = new System.Windows.Forms.Button();
            this.buttonSuaSP = new System.Windows.Forms.Button();
            this.buttonXoaSP = new System.Windows.Forms.Button();
            this.buttonThemSP = new System.Windows.Forms.Button();
            this.dataGridViewSanPham = new System.Windows.Forms.DataGridView();
            this.MaSP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenSP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaGoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DanhMuc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongTon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBoxThongBaoSPTC = new System.Windows.Forms.PictureBox();
            this.timerTaiKhoan = new System.Windows.Forms.Timer(this.components);
            this.timerTenHienThi = new System.Windows.Forms.Timer(this.components);
            this.timerTTTK = new System.Windows.Forms.Timer(this.components);
            this.timerTCSP = new System.Windows.Forms.Timer(this.components);
            this.labelLoiMaSP = new System.Windows.Forms.Label();
            this.labelLoiTenSP = new System.Windows.Forms.Label();
            this.timerLoiMaSP = new System.Windows.Forms.Timer(this.components);
            this.timerLoiTenSP = new System.Windows.Forms.Timer(this.components);
            this.labelLoiDanhMucSP = new System.Windows.Forms.Label();
            this.timerLoiDanhMucSP = new System.Windows.Forms.Timer(this.components);
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.tabControlTaiKhoanSanPham.SuspendLayout();
            this.tabPageTaiKhoan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThongBaoTKTC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNhanVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLoaiTaiKhoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaiKhoan)).BeginInit();
            this.tabPageSanPham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHinhSanPham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaGoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSLTon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThongBaoSPTC)).BeginInit();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(1189, 35);
            this.panelThanhTieuDe.TabIndex = 18;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(358, 23);
            this.labelTieuDeForm.TabIndex = 91;
            this.labelTieuDeForm.Text = "QUẢN LÝ TÀI KHOẢN VÀ SẢN PHẨM";
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 50;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(1079, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(1135, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // tabControlTaiKhoanSanPham
            // 
            this.tabControlTaiKhoanSanPham.Controls.Add(this.tabPageTaiKhoan);
            this.tabControlTaiKhoanSanPham.Controls.Add(this.tabPageSanPham);
            this.tabControlTaiKhoanSanPham.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTaiKhoanSanPham.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabControlTaiKhoanSanPham.Location = new System.Drawing.Point(0, 35);
            this.tabControlTaiKhoanSanPham.Name = "tabControlTaiKhoanSanPham";
            this.tabControlTaiKhoanSanPham.SelectedIndex = 0;
            this.tabControlTaiKhoanSanPham.Size = new System.Drawing.Size(1189, 548);
            this.tabControlTaiKhoanSanPham.TabIndex = 92;
            // 
            // tabPageTaiKhoan
            // 
            this.tabPageTaiKhoan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPageTaiKhoan.Controls.Add(this.pictureBox3);
            this.tabPageTaiKhoan.Controls.Add(this.buttonXoaAnhNhanVien);
            this.tabPageTaiKhoan.Controls.Add(this.pictureBoxThongBaoTKTC);
            this.tabPageTaiKhoan.Controls.Add(this.buttonThemAnhNhanVien);
            this.tabPageTaiKhoan.Controls.Add(this.pictureBoxNhanVien);
            this.tabPageTaiKhoan.Controls.Add(this.numericUpDownLoaiTaiKhoan);
            this.tabPageTaiKhoan.Controls.Add(this.textBoxTenHienThi);
            this.tabPageTaiKhoan.Controls.Add(this.labelLoiTenHienThi);
            this.tabPageTaiKhoan.Controls.Add(this.textBoxTaiKhoan);
            this.tabPageTaiKhoan.Controls.Add(this.labelLoiTaiKhoan);
            this.tabPageTaiKhoan.Controls.Add(this.textBoxSDT);
            this.tabPageTaiKhoan.Controls.Add(this.textBoxMatKhau);
            this.tabPageTaiKhoan.Controls.Add(this.labelThongTinToaNoKhach);
            this.tabPageTaiKhoan.Controls.Add(this.labelLoaiTaiKhoan);
            this.tabPageTaiKhoan.Controls.Add(this.labelSDT);
            this.tabPageTaiKhoan.Controls.Add(this.labelTenHienThi);
            this.tabPageTaiKhoan.Controls.Add(this.labelMatKhau);
            this.tabPageTaiKhoan.Controls.Add(this.labelTaiKhoan);
            this.tabPageTaiKhoan.Controls.Add(this.textBoxTimKiem);
            this.tabPageTaiKhoan.Controls.Add(this.buttonRefesh);
            this.tabPageTaiKhoan.Controls.Add(this.buttonSua);
            this.tabPageTaiKhoan.Controls.Add(this.buttonXoa);
            this.tabPageTaiKhoan.Controls.Add(this.buttonThem);
            this.tabPageTaiKhoan.Controls.Add(this.dataGridViewTaiKhoan);
            this.tabPageTaiKhoan.Location = new System.Drawing.Point(4, 34);
            this.tabPageTaiKhoan.Name = "tabPageTaiKhoan";
            this.tabPageTaiKhoan.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTaiKhoan.Size = new System.Drawing.Size(1181, 510);
            this.tabPageTaiKhoan.TabIndex = 0;
            this.tabPageTaiKhoan.Text = "Danh sách tài khoản";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(981, 43);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 33);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 100;
            this.pictureBox3.TabStop = false;
            // 
            // buttonXoaAnhNhanVien
            // 
            this.buttonXoaAnhNhanVien.BackColor = System.Drawing.Color.Gray;
            this.buttonXoaAnhNhanVien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonXoaAnhNhanVien.BackgroundImage")));
            this.buttonXoaAnhNhanVien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonXoaAnhNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonXoaAnhNhanVien.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXoaAnhNhanVien.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXoaAnhNhanVien.Location = new System.Drawing.Point(864, 7);
            this.buttonXoaAnhNhanVien.Name = "buttonXoaAnhNhanVien";
            this.buttonXoaAnhNhanVien.Size = new System.Drawing.Size(20, 17);
            this.buttonXoaAnhNhanVien.TabIndex = 75;
            this.buttonXoaAnhNhanVien.UseVisualStyleBackColor = false;
            this.buttonXoaAnhNhanVien.Click += new System.EventHandler(this.buttonXoaAnhNhanVien_Click);
            // 
            // pictureBoxThongBaoTKTC
            // 
            this.pictureBoxThongBaoTKTC.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxThongBaoTKTC.Image")));
            this.pictureBoxThongBaoTKTC.Location = new System.Drawing.Point(1138, 179);
            this.pictureBoxThongBaoTKTC.Name = "pictureBoxThongBaoTKTC";
            this.pictureBoxThongBaoTKTC.Size = new System.Drawing.Size(48, 41);
            this.pictureBoxThongBaoTKTC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxThongBaoTKTC.TabIndex = 74;
            this.pictureBoxThongBaoTKTC.TabStop = false;
            this.pictureBoxThongBaoTKTC.Visible = false;
            // 
            // buttonThemAnhNhanVien
            // 
            this.buttonThemAnhNhanVien.BackColor = System.Drawing.Color.Gray;
            this.buttonThemAnhNhanVien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonThemAnhNhanVien.BackgroundImage")));
            this.buttonThemAnhNhanVien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonThemAnhNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonThemAnhNhanVien.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThemAnhNhanVien.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemAnhNhanVien.Location = new System.Drawing.Point(811, 148);
            this.buttonThemAnhNhanVien.Name = "buttonThemAnhNhanVien";
            this.buttonThemAnhNhanVien.Size = new System.Drawing.Size(73, 22);
            this.buttonThemAnhNhanVien.TabIndex = 64;
            this.buttonThemAnhNhanVien.UseVisualStyleBackColor = false;
            this.buttonThemAnhNhanVien.Click += new System.EventHandler(this.buttonThemAnhNhanVien_Click);
            // 
            // pictureBoxNhanVien
            // 
            this.pictureBoxNhanVien.BackColor = System.Drawing.Color.Tan;
            this.pictureBoxNhanVien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNhanVien.Location = new System.Drawing.Point(676, 6);
            this.pictureBoxNhanVien.Name = "pictureBoxNhanVien";
            this.pictureBoxNhanVien.Size = new System.Drawing.Size(209, 165);
            this.pictureBoxNhanVien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxNhanVien.TabIndex = 63;
            this.pictureBoxNhanVien.TabStop = false;
            // 
            // numericUpDownLoaiTaiKhoan
            // 
            this.numericUpDownLoaiTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.numericUpDownLoaiTaiKhoan.Location = new System.Drawing.Point(936, 472);
            this.numericUpDownLoaiTaiKhoan.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownLoaiTaiKhoan.Name = "numericUpDownLoaiTaiKhoan";
            this.numericUpDownLoaiTaiKhoan.Size = new System.Drawing.Size(242, 33);
            this.numericUpDownLoaiTaiKhoan.TabIndex = 61;
            this.numericUpDownLoaiTaiKhoan.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxTenHienThi
            // 
            this.textBoxTenHienThi.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTenHienThi.Location = new System.Drawing.Point(936, 346);
            this.textBoxTenHienThi.Name = "textBoxTenHienThi";
            this.textBoxTenHienThi.Size = new System.Drawing.Size(242, 33);
            this.textBoxTenHienThi.TabIndex = 56;
            this.textBoxTenHienThi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenHienThi_KeyPress);
            // 
            // labelLoiTenHienThi
            // 
            this.labelLoiTenHienThi.AutoSize = true;
            this.labelLoiTenHienThi.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoiTenHienThi.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiTenHienThi.ForeColor = System.Drawing.Color.Red;
            this.labelLoiTenHienThi.Location = new System.Drawing.Point(935, 380);
            this.labelLoiTenHienThi.Name = "labelLoiTenHienThi";
            this.labelLoiTenHienThi.Size = new System.Drawing.Size(233, 22);
            this.labelLoiTenHienThi.TabIndex = 60;
            this.labelLoiTenHienThi.Text = "Tên hiển thị đã tồn tại !!!!!";
            this.labelLoiTenHienThi.Visible = false;
            // 
            // textBoxTaiKhoan
            // 
            this.textBoxTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTaiKhoan.Location = new System.Drawing.Point(936, 221);
            this.textBoxTaiKhoan.Name = "textBoxTaiKhoan";
            this.textBoxTaiKhoan.Size = new System.Drawing.Size(242, 33);
            this.textBoxTaiKhoan.TabIndex = 54;
            this.textBoxTaiKhoan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTaiKhoan_KeyPress);
            // 
            // labelLoiTaiKhoan
            // 
            this.labelLoiTaiKhoan.AutoSize = true;
            this.labelLoiTaiKhoan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoiTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiTaiKhoan.ForeColor = System.Drawing.Color.Red;
            this.labelLoiTaiKhoan.Location = new System.Drawing.Point(932, 258);
            this.labelLoiTaiKhoan.Name = "labelLoiTaiKhoan";
            this.labelLoiTaiKhoan.Size = new System.Drawing.Size(219, 22);
            this.labelLoiTaiKhoan.TabIndex = 59;
            this.labelLoiTaiKhoan.Text = "Tài khoản đã tồn tại !!!!!";
            this.labelLoiTaiKhoan.Visible = false;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxSDT.Location = new System.Drawing.Point(936, 409);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.Size = new System.Drawing.Size(242, 33);
            this.textBoxSDT.TabIndex = 57;
            this.textBoxSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSDT_KeyPress);
            // 
            // textBoxMatKhau
            // 
            this.textBoxMatKhau.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMatKhau.Location = new System.Drawing.Point(936, 283);
            this.textBoxMatKhau.Name = "textBoxMatKhau";
            this.textBoxMatKhau.Size = new System.Drawing.Size(242, 33);
            this.textBoxMatKhau.TabIndex = 55;
            this.textBoxMatKhau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMatKhau_KeyPress);
            // 
            // labelThongTinToaNoKhach
            // 
            this.labelThongTinToaNoKhach.AutoSize = true;
            this.labelThongTinToaNoKhach.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelThongTinToaNoKhach.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinToaNoKhach.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinToaNoKhach.Location = new System.Drawing.Point(676, 186);
            this.labelThongTinToaNoKhach.Name = "labelThongTinToaNoKhach";
            this.labelThongTinToaNoKhach.Size = new System.Drawing.Size(302, 29);
            this.labelThongTinToaNoKhach.TabIndex = 53;
            this.labelThongTinToaNoKhach.Text = "THÔNG TIN TÀI KHOẢN";
            // 
            // labelLoaiTaiKhoan
            // 
            this.labelLoaiTaiKhoan.AutoSize = true;
            this.labelLoaiTaiKhoan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoaiTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoaiTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.labelLoaiTaiKhoan.Location = new System.Drawing.Point(676, 480);
            this.labelLoaiTaiKhoan.Name = "labelLoaiTaiKhoan";
            this.labelLoaiTaiKhoan.Size = new System.Drawing.Size(169, 26);
            this.labelLoaiTaiKhoan.TabIndex = 51;
            this.labelLoaiTaiKhoan.Text = "Loại tài khoản:";
            // 
            // labelSDT
            // 
            this.labelSDT.AutoSize = true;
            this.labelSDT.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSDT.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT.ForeColor = System.Drawing.Color.Black;
            this.labelSDT.Location = new System.Drawing.Point(676, 417);
            this.labelSDT.Name = "labelSDT";
            this.labelSDT.Size = new System.Drawing.Size(153, 26);
            this.labelSDT.TabIndex = 50;
            this.labelSDT.Text = "Số điện thoại:";
            // 
            // labelTenHienThi
            // 
            this.labelTenHienThi.AutoSize = true;
            this.labelTenHienThi.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenHienThi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenHienThi.ForeColor = System.Drawing.Color.Black;
            this.labelTenHienThi.Location = new System.Drawing.Point(676, 354);
            this.labelTenHienThi.Name = "labelTenHienThi";
            this.labelTenHienThi.Size = new System.Drawing.Size(143, 26);
            this.labelTenHienThi.TabIndex = 49;
            this.labelTenHienThi.Text = "Tên hiển thị:";
            // 
            // labelMatKhau
            // 
            this.labelMatKhau.AutoSize = true;
            this.labelMatKhau.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMatKhau.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMatKhau.ForeColor = System.Drawing.Color.Black;
            this.labelMatKhau.Location = new System.Drawing.Point(676, 291);
            this.labelMatKhau.Name = "labelMatKhau";
            this.labelMatKhau.Size = new System.Drawing.Size(120, 26);
            this.labelMatKhau.TabIndex = 48;
            this.labelMatKhau.Text = "Mật khẩu:";
            // 
            // labelTaiKhoan
            // 
            this.labelTaiKhoan.AutoSize = true;
            this.labelTaiKhoan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTaiKhoan.ForeColor = System.Drawing.Color.Black;
            this.labelTaiKhoan.Location = new System.Drawing.Point(676, 228);
            this.labelTaiKhoan.Name = "labelTaiKhoan";
            this.labelTaiKhoan.Size = new System.Drawing.Size(123, 26);
            this.labelTaiKhoan.TabIndex = 47;
            this.labelTaiKhoan.Text = "Tài khoản:";
            // 
            // textBoxTimKiem
            // 
            this.textBoxTimKiem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimKiem.Location = new System.Drawing.Point(1021, 43);
            this.textBoxTimKiem.Name = "textBoxTimKiem";
            this.textBoxTimKiem.Size = new System.Drawing.Size(156, 34);
            this.textBoxTimKiem.TabIndex = 13;
            this.textBoxTimKiem.TextChanged += new System.EventHandler(this.textBoxTimKiem_TextChanged);
            // 
            // buttonRefesh
            // 
            this.buttonRefesh.BackColor = System.Drawing.Color.Red;
            this.buttonRefesh.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonRefesh.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonRefesh.Location = new System.Drawing.Point(1081, 124);
            this.buttonRefesh.Name = "buttonRefesh";
            this.buttonRefesh.Size = new System.Drawing.Size(98, 44);
            this.buttonRefesh.TabIndex = 12;
            this.buttonRefesh.Text = "Refesh";
            this.buttonRefesh.UseVisualStyleBackColor = false;
            this.buttonRefesh.Click += new System.EventHandler(this.buttonRefesh_Click);
            // 
            // buttonSua
            // 
            this.buttonSua.BackColor = System.Drawing.Color.Red;
            this.buttonSua.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonSua.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonSua.Location = new System.Drawing.Point(980, 124);
            this.buttonSua.Name = "buttonSua";
            this.buttonSua.Size = new System.Drawing.Size(98, 44);
            this.buttonSua.TabIndex = 11;
            this.buttonSua.Text = "Sửa";
            this.buttonSua.UseVisualStyleBackColor = false;
            this.buttonSua.Click += new System.EventHandler(this.buttonSua_Click);
            // 
            // buttonXoa
            // 
            this.buttonXoa.BackColor = System.Drawing.Color.Red;
            this.buttonXoa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXoa.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXoa.Location = new System.Drawing.Point(1081, 80);
            this.buttonXoa.Name = "buttonXoa";
            this.buttonXoa.Size = new System.Drawing.Size(98, 44);
            this.buttonXoa.TabIndex = 10;
            this.buttonXoa.Text = "Xóa";
            this.buttonXoa.UseVisualStyleBackColor = false;
            this.buttonXoa.Click += new System.EventHandler(this.buttonXoa_Click);
            // 
            // buttonThem
            // 
            this.buttonThem.BackColor = System.Drawing.Color.Red;
            this.buttonThem.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThem.Location = new System.Drawing.Point(980, 80);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(98, 44);
            this.buttonThem.TabIndex = 9;
            this.buttonThem.Text = "Thêm";
            this.buttonThem.UseVisualStyleBackColor = false;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // dataGridViewTaiKhoan
            // 
            this.dataGridViewTaiKhoan.AllowDrop = true;
            this.dataGridViewTaiKhoan.AllowUserToAddRows = false;
            this.dataGridViewTaiKhoan.AllowUserToDeleteRows = false;
            this.dataGridViewTaiKhoan.AllowUserToResizeColumns = false;
            this.dataGridViewTaiKhoan.AllowUserToResizeRows = false;
            this.dataGridViewTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTaiKhoan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Username,
            this.MatKhau,
            this.TenHienThi,
            this.SDT,
            this.LoaiTaiKhoan});
            this.dataGridViewTaiKhoan.Location = new System.Drawing.Point(2, 6);
            this.dataGridViewTaiKhoan.MultiSelect = false;
            this.dataGridViewTaiKhoan.Name = "dataGridViewTaiKhoan";
            this.dataGridViewTaiKhoan.ReadOnly = true;
            this.dataGridViewTaiKhoan.RowHeadersVisible = false;
            this.dataGridViewTaiKhoan.RowHeadersWidth = 51;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewTaiKhoan.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTaiKhoan.RowTemplate.Height = 31;
            this.dataGridViewTaiKhoan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTaiKhoan.Size = new System.Drawing.Size(668, 501);
            this.dataGridViewTaiKhoan.TabIndex = 0;
            this.dataGridViewTaiKhoan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaiKhoan_CellClick);
            // 
            // Username
            // 
            this.Username.DataPropertyName = "Username";
            this.Username.HeaderText = "Tài khoản";
            this.Username.MinimumWidth = 6;
            this.Username.Name = "Username";
            this.Username.ReadOnly = true;
            this.Username.Width = 125;
            // 
            // MatKhau
            // 
            this.MatKhau.DataPropertyName = "MatKhau";
            this.MatKhau.HeaderText = "Mật khẩu";
            this.MatKhau.MinimumWidth = 6;
            this.MatKhau.Name = "MatKhau";
            this.MatKhau.ReadOnly = true;
            this.MatKhau.Width = 125;
            // 
            // TenHienThi
            // 
            this.TenHienThi.DataPropertyName = "TenHienThi";
            this.TenHienThi.HeaderText = "Tên hiển thị";
            this.TenHienThi.MinimumWidth = 6;
            this.TenHienThi.Name = "TenHienThi";
            this.TenHienThi.ReadOnly = true;
            this.TenHienThi.Width = 125;
            // 
            // SDT
            // 
            this.SDT.DataPropertyName = "SDT";
            this.SDT.HeaderText = "SDT";
            this.SDT.MinimumWidth = 6;
            this.SDT.Name = "SDT";
            this.SDT.ReadOnly = true;
            this.SDT.Width = 125;
            // 
            // LoaiTaiKhoan
            // 
            this.LoaiTaiKhoan.DataPropertyName = "LoaiTaiKhoan";
            this.LoaiTaiKhoan.HeaderText = "Loại tài khoản";
            this.LoaiTaiKhoan.MinimumWidth = 6;
            this.LoaiTaiKhoan.Name = "LoaiTaiKhoan";
            this.LoaiTaiKhoan.ReadOnly = true;
            this.LoaiTaiKhoan.Width = 125;
            // 
            // tabPageSanPham
            // 
            this.tabPageSanPham.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPageSanPham.Controls.Add(this.labelLoiDanhMucSP);
            this.tabPageSanPham.Controls.Add(this.labelLoiTenSP);
            this.tabPageSanPham.Controls.Add(this.labelLoiMaSP);
            this.tabPageSanPham.Controls.Add(this.pictureBox2);
            this.tabPageSanPham.Controls.Add(this.buttonXoaHinhSanPham);
            this.tabPageSanPham.Controls.Add(this.buttonThemHinhSanPham);
            this.tabPageSanPham.Controls.Add(this.pictureBoxHinhSanPham);
            this.tabPageSanPham.Controls.Add(this.buttonDSPN);
            this.tabPageSanPham.Controls.Add(this.numericUpDownGiaGoc);
            this.tabPageSanPham.Controls.Add(this.numericUpDownGiaBan);
            this.tabPageSanPham.Controls.Add(this.numericUpDownSLTon);
            this.tabPageSanPham.Controls.Add(this.buttonThemDanhMuc);
            this.tabPageSanPham.Controls.Add(this.comboBoxDanhMuc);
            this.tabPageSanPham.Controls.Add(this.textBoxTenSP);
            this.tabPageSanPham.Controls.Add(this.labelThongTinSanPham);
            this.tabPageSanPham.Controls.Add(this.textBoxTimKiemSP);
            this.tabPageSanPham.Controls.Add(this.labelSLTon);
            this.tabPageSanPham.Controls.Add(this.labelDanhMuc);
            this.tabPageSanPham.Controls.Add(this.labelGiaGoc);
            this.tabPageSanPham.Controls.Add(this.labelTenSP);
            this.tabPageSanPham.Controls.Add(this.labelGiaBan);
            this.tabPageSanPham.Controls.Add(this.labelMaSP);
            this.tabPageSanPham.Controls.Add(this.textBoxMaSP);
            this.tabPageSanPham.Controls.Add(this.buttonRefeshSP);
            this.tabPageSanPham.Controls.Add(this.buttonSuaSP);
            this.tabPageSanPham.Controls.Add(this.buttonXoaSP);
            this.tabPageSanPham.Controls.Add(this.buttonThemSP);
            this.tabPageSanPham.Controls.Add(this.dataGridViewSanPham);
            this.tabPageSanPham.Controls.Add(this.pictureBoxThongBaoSPTC);
            this.tabPageSanPham.Location = new System.Drawing.Point(4, 34);
            this.tabPageSanPham.Name = "tabPageSanPham";
            this.tabPageSanPham.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSanPham.Size = new System.Drawing.Size(1181, 510);
            this.tabPageSanPham.TabIndex = 1;
            this.tabPageSanPham.Text = "Danh sách sản phẩm";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(939, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(36, 33);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 99;
            this.pictureBox2.TabStop = false;
            // 
            // buttonXoaHinhSanPham
            // 
            this.buttonXoaHinhSanPham.BackColor = System.Drawing.Color.Gray;
            this.buttonXoaHinhSanPham.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonXoaHinhSanPham.BackgroundImage")));
            this.buttonXoaHinhSanPham.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonXoaHinhSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonXoaHinhSanPham.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXoaHinhSanPham.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXoaHinhSanPham.Location = new System.Drawing.Point(843, 7);
            this.buttonXoaHinhSanPham.Name = "buttonXoaHinhSanPham";
            this.buttonXoaHinhSanPham.Size = new System.Drawing.Size(20, 17);
            this.buttonXoaHinhSanPham.TabIndex = 97;
            this.buttonXoaHinhSanPham.UseVisualStyleBackColor = false;
            this.buttonXoaHinhSanPham.Click += new System.EventHandler(this.buttonXoaHinhSanPham_Click);
            // 
            // buttonThemHinhSanPham
            // 
            this.buttonThemHinhSanPham.BackColor = System.Drawing.Color.Gray;
            this.buttonThemHinhSanPham.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonThemHinhSanPham.BackgroundImage")));
            this.buttonThemHinhSanPham.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonThemHinhSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonThemHinhSanPham.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThemHinhSanPham.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemHinhSanPham.Location = new System.Drawing.Point(790, 107);
            this.buttonThemHinhSanPham.Name = "buttonThemHinhSanPham";
            this.buttonThemHinhSanPham.Size = new System.Drawing.Size(73, 22);
            this.buttonThemHinhSanPham.TabIndex = 96;
            this.buttonThemHinhSanPham.UseVisualStyleBackColor = false;
            this.buttonThemHinhSanPham.Click += new System.EventHandler(this.buttonThemHinhSanPham_Click);
            // 
            // pictureBoxHinhSanPham
            // 
            this.pictureBoxHinhSanPham.BackColor = System.Drawing.Color.Tan;
            this.pictureBoxHinhSanPham.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxHinhSanPham.Location = new System.Drawing.Point(680, 6);
            this.pictureBoxHinhSanPham.Name = "pictureBoxHinhSanPham";
            this.pictureBoxHinhSanPham.Size = new System.Drawing.Size(184, 124);
            this.pictureBoxHinhSanPham.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxHinhSanPham.TabIndex = 95;
            this.pictureBoxHinhSanPham.TabStop = false;
            // 
            // buttonDSPN
            // 
            this.buttonDSPN.BackColor = System.Drawing.Color.AntiqueWhite;
            this.buttonDSPN.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDSPN.BackgroundImage")));
            this.buttonDSPN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDSPN.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonDSPN.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonDSPN.Location = new System.Drawing.Point(1135, 133);
            this.buttonDSPN.Name = "buttonDSPN";
            this.buttonDSPN.Size = new System.Drawing.Size(43, 40);
            this.buttonDSPN.TabIndex = 94;
            this.buttonDSPN.UseVisualStyleBackColor = false;
            this.buttonDSPN.Click += new System.EventHandler(this.buttonDSPN_Click);
            // 
            // numericUpDownGiaGoc
            // 
            this.numericUpDownGiaGoc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownGiaGoc.Location = new System.Drawing.Point(907, 294);
            this.numericUpDownGiaGoc.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownGiaGoc.Name = "numericUpDownGiaGoc";
            this.numericUpDownGiaGoc.Size = new System.Drawing.Size(271, 34);
            this.numericUpDownGiaGoc.TabIndex = 65;
            // 
            // numericUpDownGiaBan
            // 
            this.numericUpDownGiaBan.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownGiaBan.Location = new System.Drawing.Point(907, 354);
            this.numericUpDownGiaBan.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownGiaBan.Name = "numericUpDownGiaBan";
            this.numericUpDownGiaBan.Size = new System.Drawing.Size(271, 34);
            this.numericUpDownGiaBan.TabIndex = 64;
            // 
            // numericUpDownSLTon
            // 
            this.numericUpDownSLTon.Location = new System.Drawing.Point(907, 474);
            this.numericUpDownSLTon.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownSLTon.Name = "numericUpDownSLTon";
            this.numericUpDownSLTon.Size = new System.Drawing.Size(271, 34);
            this.numericUpDownSLTon.TabIndex = 63;
            // 
            // buttonThemDanhMuc
            // 
            this.buttonThemDanhMuc.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonThemDanhMuc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonThemDanhMuc.BackgroundImage")));
            this.buttonThemDanhMuc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonThemDanhMuc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThemDanhMuc.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemDanhMuc.Location = new System.Drawing.Point(1135, 414);
            this.buttonThemDanhMuc.Name = "buttonThemDanhMuc";
            this.buttonThemDanhMuc.Size = new System.Drawing.Size(45, 37);
            this.buttonThemDanhMuc.TabIndex = 62;
            this.buttonThemDanhMuc.UseVisualStyleBackColor = false;
            this.buttonThemDanhMuc.Click += new System.EventHandler(this.buttonThemDanhMuc_Click);
            // 
            // comboBoxDanhMuc
            // 
            this.comboBoxDanhMuc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDanhMuc.FormattingEnabled = true;
            this.comboBoxDanhMuc.Location = new System.Drawing.Point(907, 415);
            this.comboBoxDanhMuc.Name = "comboBoxDanhMuc";
            this.comboBoxDanhMuc.Size = new System.Drawing.Size(225, 33);
            this.comboBoxDanhMuc.TabIndex = 61;
            // 
            // textBoxTenSP
            // 
            this.textBoxTenSP.BackColor = System.Drawing.Color.White;
            this.textBoxTenSP.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTenSP.Location = new System.Drawing.Point(907, 235);
            this.textBoxTenSP.Name = "textBoxTenSP";
            this.textBoxTenSP.Size = new System.Drawing.Size(271, 33);
            this.textBoxTenSP.TabIndex = 56;
            this.textBoxTenSP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenSP_KeyPress);
            // 
            // labelThongTinSanPham
            // 
            this.labelThongTinSanPham.AutoSize = true;
            this.labelThongTinSanPham.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelThongTinSanPham.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinSanPham.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinSanPham.Location = new System.Drawing.Point(680, 144);
            this.labelThongTinSanPham.Name = "labelThongTinSanPham";
            this.labelThongTinSanPham.Size = new System.Drawing.Size(291, 29);
            this.labelThongTinSanPham.TabIndex = 55;
            this.labelThongTinSanPham.Text = "THÔNG TIN SẢN PHẨM";
            // 
            // textBoxTimKiemSP
            // 
            this.textBoxTimKiemSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimKiemSP.Location = new System.Drawing.Point(976, 5);
            this.textBoxTimKiemSP.Name = "textBoxTimKiemSP";
            this.textBoxTimKiemSP.Size = new System.Drawing.Size(201, 34);
            this.textBoxTimKiemSP.TabIndex = 53;
            this.textBoxTimKiemSP.TextChanged += new System.EventHandler(this.textBoxTimKiemSP_TextChanged);
            // 
            // labelSLTon
            // 
            this.labelSLTon.AutoSize = true;
            this.labelSLTon.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelSLTon.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLTon.ForeColor = System.Drawing.Color.Black;
            this.labelSLTon.Location = new System.Drawing.Point(680, 482);
            this.labelSLTon.Name = "labelSLTon";
            this.labelSLTon.Size = new System.Drawing.Size(149, 26);
            this.labelSLTon.TabIndex = 52;
            this.labelSLTon.Text = "Số lượng tồn:";
            // 
            // labelDanhMuc
            // 
            this.labelDanhMuc.AutoSize = true;
            this.labelDanhMuc.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelDanhMuc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDanhMuc.ForeColor = System.Drawing.Color.Black;
            this.labelDanhMuc.Location = new System.Drawing.Point(680, 422);
            this.labelDanhMuc.Name = "labelDanhMuc";
            this.labelDanhMuc.Size = new System.Drawing.Size(124, 26);
            this.labelDanhMuc.TabIndex = 51;
            this.labelDanhMuc.Text = "Danh mục:";
            // 
            // labelGiaGoc
            // 
            this.labelGiaGoc.AutoSize = true;
            this.labelGiaGoc.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelGiaGoc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiaGoc.ForeColor = System.Drawing.Color.Black;
            this.labelGiaGoc.Location = new System.Drawing.Point(680, 302);
            this.labelGiaGoc.Name = "labelGiaGoc";
            this.labelGiaGoc.Size = new System.Drawing.Size(98, 26);
            this.labelGiaGoc.TabIndex = 50;
            this.labelGiaGoc.Text = "Giá gốc:";
            // 
            // labelTenSP
            // 
            this.labelTenSP.AutoSize = true;
            this.labelTenSP.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelTenSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenSP.ForeColor = System.Drawing.Color.Black;
            this.labelTenSP.Location = new System.Drawing.Point(680, 242);
            this.labelTenSP.Name = "labelTenSP";
            this.labelTenSP.Size = new System.Drawing.Size(93, 26);
            this.labelTenSP.TabIndex = 49;
            this.labelTenSP.Text = "Tên SP:";
            // 
            // labelGiaBan
            // 
            this.labelGiaBan.AutoSize = true;
            this.labelGiaBan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelGiaBan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiaBan.ForeColor = System.Drawing.Color.Black;
            this.labelGiaBan.Location = new System.Drawing.Point(680, 362);
            this.labelGiaBan.Name = "labelGiaBan";
            this.labelGiaBan.Size = new System.Drawing.Size(101, 26);
            this.labelGiaBan.TabIndex = 48;
            this.labelGiaBan.Text = "Giá bán:";
            // 
            // labelMaSP
            // 
            this.labelMaSP.AutoSize = true;
            this.labelMaSP.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelMaSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaSP.ForeColor = System.Drawing.Color.Black;
            this.labelMaSP.Location = new System.Drawing.Point(680, 182);
            this.labelMaSP.Name = "labelMaSP";
            this.labelMaSP.Size = new System.Drawing.Size(89, 26);
            this.labelMaSP.TabIndex = 47;
            this.labelMaSP.Text = "Mã SP:";
            // 
            // textBoxMaSP
            // 
            this.textBoxMaSP.BackColor = System.Drawing.Color.White;
            this.textBoxMaSP.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMaSP.Location = new System.Drawing.Point(907, 175);
            this.textBoxMaSP.Name = "textBoxMaSP";
            this.textBoxMaSP.Size = new System.Drawing.Size(271, 33);
            this.textBoxMaSP.TabIndex = 38;
            this.textBoxMaSP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMaSP_KeyPress);
            // 
            // buttonRefeshSP
            // 
            this.buttonRefeshSP.BackColor = System.Drawing.Color.Red;
            this.buttonRefeshSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonRefeshSP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonRefeshSP.Location = new System.Drawing.Point(1060, 87);
            this.buttonRefeshSP.Name = "buttonRefeshSP";
            this.buttonRefeshSP.Size = new System.Drawing.Size(121, 43);
            this.buttonRefeshSP.TabIndex = 11;
            this.buttonRefeshSP.Text = "Refesh";
            this.buttonRefeshSP.UseVisualStyleBackColor = false;
            this.buttonRefeshSP.Click += new System.EventHandler(this.buttonRefeshSP_Click);
            // 
            // buttonSuaSP
            // 
            this.buttonSuaSP.BackColor = System.Drawing.Color.Red;
            this.buttonSuaSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonSuaSP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonSuaSP.Location = new System.Drawing.Point(937, 87);
            this.buttonSuaSP.Name = "buttonSuaSP";
            this.buttonSuaSP.Size = new System.Drawing.Size(121, 43);
            this.buttonSuaSP.TabIndex = 10;
            this.buttonSuaSP.Text = "Sửa SP";
            this.buttonSuaSP.UseVisualStyleBackColor = false;
            this.buttonSuaSP.Click += new System.EventHandler(this.buttonSuaSP_Click);
            // 
            // buttonXoaSP
            // 
            this.buttonXoaSP.BackColor = System.Drawing.Color.Red;
            this.buttonXoaSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXoaSP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXoaSP.Location = new System.Drawing.Point(1060, 43);
            this.buttonXoaSP.Name = "buttonXoaSP";
            this.buttonXoaSP.Size = new System.Drawing.Size(121, 43);
            this.buttonXoaSP.TabIndex = 9;
            this.buttonXoaSP.Text = "Xóa SP";
            this.buttonXoaSP.UseVisualStyleBackColor = false;
            this.buttonXoaSP.Click += new System.EventHandler(this.buttonXoaSP_Click);
            // 
            // buttonThemSP
            // 
            this.buttonThemSP.BackColor = System.Drawing.Color.Red;
            this.buttonThemSP.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThemSP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemSP.Location = new System.Drawing.Point(937, 43);
            this.buttonThemSP.Name = "buttonThemSP";
            this.buttonThemSP.Size = new System.Drawing.Size(121, 43);
            this.buttonThemSP.TabIndex = 8;
            this.buttonThemSP.Text = "Thêm SP";
            this.buttonThemSP.UseVisualStyleBackColor = false;
            this.buttonThemSP.Click += new System.EventHandler(this.buttonThemSP_Click);
            // 
            // dataGridViewSanPham
            // 
            this.dataGridViewSanPham.AllowDrop = true;
            this.dataGridViewSanPham.AllowUserToAddRows = false;
            this.dataGridViewSanPham.AllowUserToDeleteRows = false;
            this.dataGridViewSanPham.AllowUserToResizeColumns = false;
            this.dataGridViewSanPham.AllowUserToResizeRows = false;
            this.dataGridViewSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSanPham.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSP,
            this.TenSP,
            this.GiaGoc,
            this.GiaBan,
            this.DanhMuc,
            this.SoLuongTon});
            this.dataGridViewSanPham.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewSanPham.MultiSelect = false;
            this.dataGridViewSanPham.Name = "dataGridViewSanPham";
            this.dataGridViewSanPham.ReadOnly = true;
            this.dataGridViewSanPham.RowHeadersVisible = false;
            this.dataGridViewSanPham.RowHeadersWidth = 51;
            this.dataGridViewSanPham.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewSanPham.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewSanPham.RowTemplate.Height = 31;
            this.dataGridViewSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSanPham.Size = new System.Drawing.Size(668, 504);
            this.dataGridViewSanPham.TabIndex = 0;
            this.dataGridViewSanPham.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSanPham_CellClick);
            // 
            // MaSP
            // 
            this.MaSP.DataPropertyName = "MaSP";
            this.MaSP.HeaderText = "Mã SP";
            this.MaSP.MinimumWidth = 6;
            this.MaSP.Name = "MaSP";
            this.MaSP.ReadOnly = true;
            this.MaSP.Width = 125;
            // 
            // TenSP
            // 
            this.TenSP.DataPropertyName = "TenSP";
            this.TenSP.HeaderText = "Tên SP";
            this.TenSP.MinimumWidth = 6;
            this.TenSP.Name = "TenSP";
            this.TenSP.ReadOnly = true;
            this.TenSP.Width = 160;
            // 
            // GiaGoc
            // 
            this.GiaGoc.DataPropertyName = "GiaGoc";
            dataGridViewCellStyle6.Format = "C0";
            dataGridViewCellStyle6.NullValue = null;
            this.GiaGoc.DefaultCellStyle = dataGridViewCellStyle6;
            this.GiaGoc.HeaderText = "Giá gốc";
            this.GiaGoc.MinimumWidth = 6;
            this.GiaGoc.Name = "GiaGoc";
            this.GiaGoc.ReadOnly = true;
            this.GiaGoc.Width = 125;
            // 
            // GiaBan
            // 
            this.GiaBan.DataPropertyName = "GiaBan";
            dataGridViewCellStyle7.Format = "C0";
            dataGridViewCellStyle7.NullValue = null;
            this.GiaBan.DefaultCellStyle = dataGridViewCellStyle7;
            this.GiaBan.HeaderText = "Giá bán";
            this.GiaBan.MinimumWidth = 6;
            this.GiaBan.Name = "GiaBan";
            this.GiaBan.ReadOnly = true;
            this.GiaBan.Width = 125;
            // 
            // DanhMuc
            // 
            this.DanhMuc.DataPropertyName = "DanhMuc";
            this.DanhMuc.HeaderText = "Danh mục";
            this.DanhMuc.MinimumWidth = 6;
            this.DanhMuc.Name = "DanhMuc";
            this.DanhMuc.ReadOnly = true;
            this.DanhMuc.Width = 125;
            // 
            // SoLuongTon
            // 
            this.SoLuongTon.DataPropertyName = "SoLuongTon";
            this.SoLuongTon.HeaderText = "Số lượng tồn";
            this.SoLuongTon.MinimumWidth = 6;
            this.SoLuongTon.Name = "SoLuongTon";
            this.SoLuongTon.ReadOnly = true;
            this.SoLuongTon.Width = 125;
            // 
            // pictureBoxThongBaoSPTC
            // 
            this.pictureBoxThongBaoSPTC.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxThongBaoSPTC.Image")));
            this.pictureBoxThongBaoSPTC.Location = new System.Drawing.Point(977, 135);
            this.pictureBoxThongBaoSPTC.Name = "pictureBoxThongBaoSPTC";
            this.pictureBoxThongBaoSPTC.Size = new System.Drawing.Size(48, 41);
            this.pictureBoxThongBaoSPTC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxThongBaoSPTC.TabIndex = 98;
            this.pictureBoxThongBaoSPTC.TabStop = false;
            this.pictureBoxThongBaoSPTC.Visible = false;
            // 
            // timerTaiKhoan
            // 
            this.timerTaiKhoan.Interval = 1000;
            this.timerTaiKhoan.Tick += new System.EventHandler(this.timerTaiKhoan_Tick);
            // 
            // timerTenHienThi
            // 
            this.timerTenHienThi.Interval = 2000;
            this.timerTenHienThi.Tick += new System.EventHandler(this.timerTenHienThi_Tick);
            // 
            // timerTTTK
            // 
            this.timerTTTK.Interval = 1000;
            this.timerTTTK.Tick += new System.EventHandler(this.timerTTTK_Tick);
            // 
            // timerTCSP
            // 
            this.timerTCSP.Interval = 1000;
            this.timerTCSP.Tick += new System.EventHandler(this.timerTCSP_Tick);
            // 
            // labelLoiMaSP
            // 
            this.labelLoiMaSP.AutoSize = true;
            this.labelLoiMaSP.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoiMaSP.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiMaSP.ForeColor = System.Drawing.Color.Red;
            this.labelLoiMaSP.Location = new System.Drawing.Point(904, 210);
            this.labelLoiMaSP.Name = "labelLoiMaSP";
            this.labelLoiMaSP.Size = new System.Drawing.Size(231, 22);
            this.labelLoiMaSP.TabIndex = 100;
            this.labelLoiMaSP.Text = "Mã sản phẩm đã tồn tại !!!";
            this.labelLoiMaSP.Visible = false;
            // 
            // labelLoiTenSP
            // 
            this.labelLoiTenSP.AutoSize = true;
            this.labelLoiTenSP.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoiTenSP.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiTenSP.ForeColor = System.Drawing.Color.Red;
            this.labelLoiTenSP.Location = new System.Drawing.Point(904, 270);
            this.labelLoiTenSP.Name = "labelLoiTenSP";
            this.labelLoiTenSP.Size = new System.Drawing.Size(251, 22);
            this.labelLoiTenSP.TabIndex = 101;
            this.labelLoiTenSP.Text = "Tên sản phẩm đã tồn tại !!!!!";
            this.labelLoiTenSP.Visible = false;
            // 
            // timerLoiMaSP
            // 
            this.timerLoiMaSP.Interval = 1000;
            this.timerLoiMaSP.Tick += new System.EventHandler(this.timerLoiMaSP_Tick);
            // 
            // timerLoiTenSP
            // 
            this.timerLoiTenSP.Interval = 1000;
            this.timerLoiTenSP.Tick += new System.EventHandler(this.timerLoiTenSP_Tick);
            // 
            // labelLoiDanhMucSP
            // 
            this.labelLoiDanhMucSP.AutoSize = true;
            this.labelLoiDanhMucSP.BackColor = System.Drawing.Color.AntiqueWhite;
            this.labelLoiDanhMucSP.Font = new System.Drawing.Font("Times New Roman", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiDanhMucSP.ForeColor = System.Drawing.Color.Red;
            this.labelLoiDanhMucSP.Location = new System.Drawing.Point(904, 450);
            this.labelLoiDanhMucSP.Name = "labelLoiDanhMucSP";
            this.labelLoiDanhMucSP.Size = new System.Drawing.Size(246, 22);
            this.labelLoiDanhMucSP.TabIndex = 102;
            this.labelLoiDanhMucSP.Text = "Bạn chưa chọn danh mục !!!";
            this.labelLoiDanhMucSP.Visible = false;
            // 
            // timerLoiDanhMucSP
            // 
            this.timerLoiDanhMucSP.Interval = 1000;
            this.timerLoiDanhMucSP.Tick += new System.EventHandler(this.timerLoiDanhMucSP_Tick);
            // 
            // formTaiKhoanSanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1189, 583);
            this.Controls.Add(this.tabControlTaiKhoanSanPham);
            this.Controls.Add(this.panelThanhTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formTaiKhoanSanPham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formTaiKhoanSanPham";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.tabControlTaiKhoanSanPham.ResumeLayout(false);
            this.tabPageTaiKhoan.ResumeLayout(false);
            this.tabPageTaiKhoan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThongBaoTKTC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNhanVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLoaiTaiKhoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaiKhoan)).EndInit();
            this.tabPageSanPham.ResumeLayout(false);
            this.tabPageSanPham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHinhSanPham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaGoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiaBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSLTon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThongBaoSPTC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.TabControl tabControlTaiKhoanSanPham;
        private System.Windows.Forms.TabPage tabPageTaiKhoan;
        private System.Windows.Forms.DataGridView dataGridViewTaiKhoan;
        private System.Windows.Forms.TabPage tabPageSanPham;
        private System.Windows.Forms.Button buttonRefesh;
        private System.Windows.Forms.Button buttonSua;
        private System.Windows.Forms.Button buttonXoa;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.TextBox textBoxTimKiem;
        private System.Windows.Forms.Label labelLoaiTaiKhoan;
        private System.Windows.Forms.Label labelSDT;
        private System.Windows.Forms.Label labelTenHienThi;
        private System.Windows.Forms.Label labelMatKhau;
        private System.Windows.Forms.Label labelTaiKhoan;
        private System.Windows.Forms.Label labelThongTinToaNoKhach;
        private System.Windows.Forms.Label labelLoiTaiKhoan;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.TextBox textBoxTenHienThi;
        private System.Windows.Forms.TextBox textBoxMatKhau;
        private System.Windows.Forms.TextBox textBoxTaiKhoan;
        private System.Windows.Forms.NumericUpDown numericUpDownLoaiTaiKhoan;
        private System.Windows.Forms.Label labelLoiTenHienThi;
        private System.Windows.Forms.Timer timerTaiKhoan;
        private System.Windows.Forms.Timer timerTenHienThi;
        private System.Windows.Forms.Timer timerTTTK;
        private System.Windows.Forms.DataGridView dataGridViewSanPham;
        private System.Windows.Forms.Button buttonRefeshSP;
        private System.Windows.Forms.Button buttonSuaSP;
        private System.Windows.Forms.Button buttonXoaSP;
        private System.Windows.Forms.Button buttonThemSP;
        private System.Windows.Forms.TextBox textBoxMaSP;
        private System.Windows.Forms.NumericUpDown numericUpDownGiaGoc;
        private System.Windows.Forms.NumericUpDown numericUpDownGiaBan;
        private System.Windows.Forms.NumericUpDown numericUpDownSLTon;
        private System.Windows.Forms.Button buttonThemDanhMuc;
        private System.Windows.Forms.ComboBox comboBoxDanhMuc;
        private System.Windows.Forms.TextBox textBoxTenSP;
        private System.Windows.Forms.Label labelThongTinSanPham;
        private System.Windows.Forms.TextBox textBoxTimKiemSP;
        private System.Windows.Forms.Label labelSLTon;
        private System.Windows.Forms.Label labelDanhMuc;
        private System.Windows.Forms.Label labelGiaGoc;
        private System.Windows.Forms.Label labelTenSP;
        private System.Windows.Forms.Label labelGiaBan;
        private System.Windows.Forms.Label labelMaSP;
        private System.Windows.Forms.Timer timerTCSP;
        private System.Windows.Forms.Button buttonDSPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn MatKhau;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHienThi;
        private System.Windows.Forms.DataGridViewTextBoxColumn SDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiTaiKhoan;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaGoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaBan;
        private System.Windows.Forms.DataGridViewTextBoxColumn DanhMuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongTon;
        private System.Windows.Forms.PictureBox pictureBoxNhanVien;
        private System.Windows.Forms.PictureBox pictureBoxThongBaoTKTC;
        private System.Windows.Forms.Button buttonXoaAnhNhanVien;
        private System.Windows.Forms.Button buttonThemAnhNhanVien;
        private System.Windows.Forms.Button buttonXoaHinhSanPham;
        private System.Windows.Forms.Button buttonThemHinhSanPham;
        private System.Windows.Forms.PictureBox pictureBoxHinhSanPham;
        private System.Windows.Forms.PictureBox pictureBoxThongBaoSPTC;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label labelLoiTenSP;
        private System.Windows.Forms.Label labelLoiMaSP;
        private System.Windows.Forms.Timer timerLoiMaSP;
        private System.Windows.Forms.Timer timerLoiTenSP;
        private System.Windows.Forms.Label labelLoiDanhMucSP;
        private System.Windows.Forms.Timer timerLoiDanhMucSP;
    }
}