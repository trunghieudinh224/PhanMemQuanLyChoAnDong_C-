﻿namespace QUANLYBANQUANAO
{
    partial class formThongTinTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formThongTinTaiKhoan));
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.panelDuoi = new System.Windows.Forms.Panel();
            this.panelPhai = new System.Windows.Forms.Panel();
            this.panelTrai = new System.Windows.Forms.Panel();
            this.buttonTTTK = new System.Windows.Forms.Button();
            this.buttonMK = new System.Windows.Forms.Button();
            this.panelTTTK = new System.Windows.Forms.Panel();
            this.labelLoiTTTK = new System.Windows.Forms.Label();
            this.textBoxMatKhau = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxTenHienThi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.labelSDT = new System.Windows.Forms.Label();
            this.buttonCapNhatTTTK = new System.Windows.Forms.Button();
            this.labelMatKhau = new System.Windows.Forms.Label();
            this.labelTenHienThi = new System.Windows.Forms.Label();
            this.textBoxTaiKhoan = new System.Windows.Forms.TextBox();
            this.labelTaiKhoan = new System.Windows.Forms.Label();
            this.panelMK = new System.Windows.Forms.Panel();
            this.labelLoiMK = new System.Windows.Forms.Label();
            this.buttonCapNhatMK = new System.Windows.Forms.Button();
            this.textBoxMKMoi = new System.Windows.Forms.TextBox();
            this.labelMKMoi = new System.Windows.Forms.Label();
            this.textBoxNhapLai = new System.Windows.Forms.TextBox();
            this.labelNhapLai = new System.Windows.Forms.Label();
            this.textBoxMKHienTai = new System.Windows.Forms.TextBox();
            this.labelMKHienTai = new System.Windows.Forms.Label();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.panelTTTK.SuspendLayout();
            this.panelMK.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.TabIndex = 16;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 93;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(240, 23);
            this.labelTieuDeForm.TabIndex = 92;
            this.labelTieuDeForm.Text = "THÔNG TIN TÀI KHOẢN";
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(373, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(432, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // panelDuoi
            // 
            this.panelDuoi.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDuoi.Location = new System.Drawing.Point(6, 351);
            this.panelDuoi.Name = "panelDuoi";
            this.panelDuoi.Size = new System.Drawing.Size(474, 6);
            this.panelDuoi.TabIndex = 63;
            // 
            // panelPhai
            // 
            this.panelPhai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelPhai.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelPhai.Location = new System.Drawing.Point(480, 35);
            this.panelPhai.Name = "panelPhai";
            this.panelPhai.Size = new System.Drawing.Size(6, 322);
            this.panelPhai.TabIndex = 62;
            // 
            // panelTrai
            // 
            this.panelTrai.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelTrai.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTrai.Location = new System.Drawing.Point(0, 35);
            this.panelTrai.Name = "panelTrai";
            this.panelTrai.Size = new System.Drawing.Size(6, 322);
            this.panelTrai.TabIndex = 61;
            // 
            // buttonTTTK
            // 
            this.buttonTTTK.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonTTTK.FlatAppearance.BorderSize = 0;
            this.buttonTTTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTTTK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonTTTK.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonTTTK.Image = ((System.Drawing.Image)(resources.GetObject("buttonTTTK.Image")));
            this.buttonTTTK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTTTK.Location = new System.Drawing.Point(6, 35);
            this.buttonTTTK.Name = "buttonTTTK";
            this.buttonTTTK.Size = new System.Drawing.Size(238, 40);
            this.buttonTTTK.TabIndex = 78;
            this.buttonTTTK.Text = "Thông tin tài khoản";
            this.buttonTTTK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonTTTK.UseVisualStyleBackColor = false;
            this.buttonTTTK.Click += new System.EventHandler(this.buttonTTTK_Click);
            // 
            // buttonMK
            // 
            this.buttonMK.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonMK.FlatAppearance.BorderSize = 0;
            this.buttonMK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonMK.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonMK.Image = ((System.Drawing.Image)(resources.GetObject("buttonMK.Image")));
            this.buttonMK.Location = new System.Drawing.Point(243, 35);
            this.buttonMK.Name = "buttonMK";
            this.buttonMK.Size = new System.Drawing.Size(238, 40);
            this.buttonMK.TabIndex = 79;
            this.buttonMK.Text = "Mật khẩu";
            this.buttonMK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonMK.UseVisualStyleBackColor = false;
            this.buttonMK.Click += new System.EventHandler(this.buttonMK_Click);
            // 
            // panelTTTK
            // 
            this.panelTTTK.Controls.Add(this.labelLoiTTTK);
            this.panelTTTK.Controls.Add(this.textBoxMatKhau);
            this.panelTTTK.Controls.Add(this.label6);
            this.panelTTTK.Controls.Add(this.textBoxTenHienThi);
            this.panelTTTK.Controls.Add(this.label5);
            this.panelTTTK.Controls.Add(this.textBoxSDT);
            this.panelTTTK.Controls.Add(this.label4);
            this.panelTTTK.Controls.Add(this.labelSDT);
            this.panelTTTK.Controls.Add(this.buttonCapNhatTTTK);
            this.panelTTTK.Controls.Add(this.labelMatKhau);
            this.panelTTTK.Controls.Add(this.labelTenHienThi);
            this.panelTTTK.Controls.Add(this.textBoxTaiKhoan);
            this.panelTTTK.Controls.Add(this.labelTaiKhoan);
            this.panelTTTK.Location = new System.Drawing.Point(6, 81);
            this.panelTTTK.Name = "panelTTTK";
            this.panelTTTK.Size = new System.Drawing.Size(475, 268);
            this.panelTTTK.TabIndex = 80;
            // 
            // labelLoiTTTK
            // 
            this.labelLoiTTTK.AutoSize = true;
            this.labelLoiTTTK.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiTTTK.ForeColor = System.Drawing.Color.Red;
            this.labelLoiTTTK.Location = new System.Drawing.Point(3, 242);
            this.labelLoiTTTK.Name = "labelLoiTTTK";
            this.labelLoiTTTK.Size = new System.Drawing.Size(246, 23);
            this.labelLoiTTTK.TabIndex = 90;
            this.labelLoiTTTK.Text = "Bạn phải nhập mật khẩu !!!";
            this.labelLoiTTTK.Visible = false;
            // 
            // textBoxMatKhau
            // 
            this.textBoxMatKhau.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMatKhau.Location = new System.Drawing.Point(216, 185);
            this.textBoxMatKhau.Name = "textBoxMatKhau";
            this.textBoxMatKhau.Size = new System.Drawing.Size(254, 34);
            this.textBoxMatKhau.TabIndex = 83;
            this.textBoxMatKhau.UseSystemPasswordChar = true;
            this.textBoxMatKhau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMatKhau_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(195, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 26);
            this.label6.TabIndex = 89;
            this.label6.Text = "*";
            // 
            // textBoxTenHienThi
            // 
            this.textBoxTenHienThi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTenHienThi.Location = new System.Drawing.Point(216, 65);
            this.textBoxTenHienThi.Name = "textBoxTenHienThi";
            this.textBoxTenHienThi.Size = new System.Drawing.Size(254, 34);
            this.textBoxTenHienThi.TabIndex = 81;
            this.textBoxTenHienThi.TextChanged += new System.EventHandler(this.textBoxTenHienThi_TextChanged);
            this.textBoxTenHienThi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenHienThi_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(195, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 26);
            this.label5.TabIndex = 88;
            this.label5.Text = "*";
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxSDT.Location = new System.Drawing.Point(216, 125);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.Size = new System.Drawing.Size(254, 34);
            this.textBoxSDT.TabIndex = 86;
            this.textBoxSDT.TextChanged += new System.EventHandler(this.textBoxSDT_TextChanged);
            this.textBoxSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSDT_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(195, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 26);
            this.label4.TabIndex = 87;
            this.label4.Text = "*";
            // 
            // labelSDT
            // 
            this.labelSDT.AutoSize = true;
            this.labelSDT.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT.Location = new System.Drawing.Point(0, 130);
            this.labelSDT.Name = "labelSDT";
            this.labelSDT.Size = new System.Drawing.Size(63, 26);
            this.labelSDT.TabIndex = 85;
            this.labelSDT.Text = "SĐT:";
            // 
            // buttonCapNhatTTTK
            // 
            this.buttonCapNhatTTTK.BackColor = System.Drawing.Color.Red;
            this.buttonCapNhatTTTK.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonCapNhatTTTK.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhatTTTK.Location = new System.Drawing.Point(332, 225);
            this.buttonCapNhatTTTK.Name = "buttonCapNhatTTTK";
            this.buttonCapNhatTTTK.Size = new System.Drawing.Size(142, 40);
            this.buttonCapNhatTTTK.TabIndex = 84;
            this.buttonCapNhatTTTK.Text = "Cập nhật";
            this.buttonCapNhatTTTK.UseVisualStyleBackColor = false;
            this.buttonCapNhatTTTK.Click += new System.EventHandler(this.buttonCapNhatTTTK_Click);
            // 
            // labelMatKhau
            // 
            this.labelMatKhau.AutoSize = true;
            this.labelMatKhau.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMatKhau.Location = new System.Drawing.Point(0, 190);
            this.labelMatKhau.Name = "labelMatKhau";
            this.labelMatKhau.Size = new System.Drawing.Size(120, 26);
            this.labelMatKhau.TabIndex = 82;
            this.labelMatKhau.Text = "Mật khẩu:";
            // 
            // labelTenHienThi
            // 
            this.labelTenHienThi.AutoSize = true;
            this.labelTenHienThi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenHienThi.Location = new System.Drawing.Point(0, 70);
            this.labelTenHienThi.Name = "labelTenHienThi";
            this.labelTenHienThi.Size = new System.Drawing.Size(143, 26);
            this.labelTenHienThi.TabIndex = 80;
            this.labelTenHienThi.Text = "Tên hiển thị:";
            // 
            // textBoxTaiKhoan
            // 
            this.textBoxTaiKhoan.BackColor = System.Drawing.SystemColors.Window;
            this.textBoxTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTaiKhoan.Location = new System.Drawing.Point(216, 5);
            this.textBoxTaiKhoan.Name = "textBoxTaiKhoan";
            this.textBoxTaiKhoan.ReadOnly = true;
            this.textBoxTaiKhoan.Size = new System.Drawing.Size(254, 34);
            this.textBoxTaiKhoan.TabIndex = 79;
            // 
            // labelTaiKhoan
            // 
            this.labelTaiKhoan.AutoSize = true;
            this.labelTaiKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTaiKhoan.Location = new System.Drawing.Point(0, 10);
            this.labelTaiKhoan.Name = "labelTaiKhoan";
            this.labelTaiKhoan.Size = new System.Drawing.Size(123, 26);
            this.labelTaiKhoan.TabIndex = 78;
            this.labelTaiKhoan.Text = "Tài khoản:";
            // 
            // panelMK
            // 
            this.panelMK.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panelMK.Controls.Add(this.labelLoiMK);
            this.panelMK.Controls.Add(this.buttonCapNhatMK);
            this.panelMK.Controls.Add(this.textBoxMKMoi);
            this.panelMK.Controls.Add(this.labelMKMoi);
            this.panelMK.Controls.Add(this.textBoxNhapLai);
            this.panelMK.Controls.Add(this.labelNhapLai);
            this.panelMK.Controls.Add(this.textBoxMKHienTai);
            this.panelMK.Controls.Add(this.labelMKHienTai);
            this.panelMK.Location = new System.Drawing.Point(6, 81);
            this.panelMK.Name = "panelMK";
            this.panelMK.Size = new System.Drawing.Size(476, 268);
            this.panelMK.TabIndex = 81;
            // 
            // labelLoiMK
            // 
            this.labelLoiMK.AutoSize = true;
            this.labelLoiMK.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLoiMK.ForeColor = System.Drawing.Color.Red;
            this.labelLoiMK.Location = new System.Drawing.Point(1, 182);
            this.labelLoiMK.Name = "labelLoiMK";
            this.labelLoiMK.Size = new System.Drawing.Size(246, 23);
            this.labelLoiMK.TabIndex = 94;
            this.labelLoiMK.Text = "Bạn phải nhập mật khẩu !!!";
            this.labelLoiMK.Visible = false;
            // 
            // buttonCapNhatMK
            // 
            this.buttonCapNhatMK.BackColor = System.Drawing.Color.Red;
            this.buttonCapNhatMK.Enabled = false;
            this.buttonCapNhatMK.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonCapNhatMK.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCapNhatMK.Location = new System.Drawing.Point(332, 166);
            this.buttonCapNhatMK.Name = "buttonCapNhatMK";
            this.buttonCapNhatMK.Size = new System.Drawing.Size(142, 40);
            this.buttonCapNhatMK.TabIndex = 93;
            this.buttonCapNhatMK.Text = "Cập nhật";
            this.buttonCapNhatMK.UseVisualStyleBackColor = false;
            this.buttonCapNhatMK.Click += new System.EventHandler(this.buttonCapNhatMK_Click);
            // 
            // textBoxMKMoi
            // 
            this.textBoxMKMoi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMKMoi.Location = new System.Drawing.Point(216, 65);
            this.textBoxMKMoi.Name = "textBoxMKMoi";
            this.textBoxMKMoi.Size = new System.Drawing.Size(254, 34);
            this.textBoxMKMoi.TabIndex = 92;
            this.textBoxMKMoi.UseSystemPasswordChar = true;
            this.textBoxMKMoi.TextChanged += new System.EventHandler(this.textBoxMKMoi_TextChanged);
            this.textBoxMKMoi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMKMoi_KeyPress);
            // 
            // labelMKMoi
            // 
            this.labelMKMoi.AutoSize = true;
            this.labelMKMoi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMKMoi.Location = new System.Drawing.Point(0, 70);
            this.labelMKMoi.Name = "labelMKMoi";
            this.labelMKMoi.Size = new System.Drawing.Size(107, 26);
            this.labelMKMoi.TabIndex = 91;
            this.labelMKMoi.Text = "MK mới:";
            // 
            // textBoxNhapLai
            // 
            this.textBoxNhapLai.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxNhapLai.Location = new System.Drawing.Point(216, 125);
            this.textBoxNhapLai.Name = "textBoxNhapLai";
            this.textBoxNhapLai.Size = new System.Drawing.Size(254, 34);
            this.textBoxNhapLai.TabIndex = 90;
            this.textBoxNhapLai.UseSystemPasswordChar = true;
            this.textBoxNhapLai.TextChanged += new System.EventHandler(this.textBoxNhapLai_TextChanged);
            this.textBoxNhapLai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNhapLai_KeyPress);
            // 
            // labelNhapLai
            // 
            this.labelNhapLai.AutoSize = true;
            this.labelNhapLai.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhapLai.Location = new System.Drawing.Point(0, 130);
            this.labelNhapLai.Name = "labelNhapLai";
            this.labelNhapLai.Size = new System.Drawing.Size(164, 26);
            this.labelNhapLai.TabIndex = 89;
            this.labelNhapLai.Text = "Xác nhận MK:";
            // 
            // textBoxMKHienTai
            // 
            this.textBoxMKHienTai.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMKHienTai.Location = new System.Drawing.Point(216, 5);
            this.textBoxMKHienTai.Name = "textBoxMKHienTai";
            this.textBoxMKHienTai.Size = new System.Drawing.Size(254, 34);
            this.textBoxMKHienTai.TabIndex = 88;
            this.textBoxMKHienTai.UseSystemPasswordChar = true;
            this.textBoxMKHienTai.TextChanged += new System.EventHandler(this.textBoxMKHienTai_TextChanged);
            this.textBoxMKHienTai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMKHienTai_KeyPress);
            // 
            // labelMKHienTai
            // 
            this.labelMKHienTai.AutoSize = true;
            this.labelMKHienTai.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMKHienTai.Location = new System.Drawing.Point(0, 10);
            this.labelMKHienTai.Name = "labelMKHienTai";
            this.labelMKHienTai.Size = new System.Drawing.Size(145, 26);
            this.labelMKHienTai.TabIndex = 87;
            this.labelMKHienTai.Text = "MK hiện tại:";
            // 
            // formThongTinTaiKhoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(486, 357);
            this.Controls.Add(this.buttonMK);
            this.Controls.Add(this.buttonTTTK);
            this.Controls.Add(this.panelDuoi);
            this.Controls.Add(this.panelPhai);
            this.Controls.Add(this.panelTrai);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.panelTTTK);
            this.Controls.Add(this.panelMK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formThongTinTaiKhoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formThongTinTaiKhoan";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.panelTTTK.ResumeLayout(false);
            this.panelTTTK.PerformLayout();
            this.panelMK.ResumeLayout(false);
            this.panelMK.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Panel panelDuoi;
        private System.Windows.Forms.Panel panelPhai;
        private System.Windows.Forms.Panel panelTrai;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonTTTK;
        private System.Windows.Forms.Button buttonMK;
        private System.Windows.Forms.Panel panelTTTK;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.Label labelSDT;
        private System.Windows.Forms.Button buttonCapNhatTTTK;
        private System.Windows.Forms.TextBox textBoxMatKhau;
        private System.Windows.Forms.Label labelMatKhau;
        private System.Windows.Forms.TextBox textBoxTenHienThi;
        private System.Windows.Forms.Label labelTenHienThi;
        private System.Windows.Forms.TextBox textBoxTaiKhoan;
        private System.Windows.Forms.Label labelTaiKhoan;
        private System.Windows.Forms.Panel panelMK;
        private System.Windows.Forms.TextBox textBoxMKMoi;
        private System.Windows.Forms.Label labelMKMoi;
        private System.Windows.Forms.TextBox textBoxNhapLai;
        private System.Windows.Forms.Label labelNhapLai;
        private System.Windows.Forms.TextBox textBoxMKHienTai;
        private System.Windows.Forms.Label labelMKHienTai;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelLoiTTTK;
        private System.Windows.Forms.Button buttonCapNhatMK;
        private System.Windows.Forms.Label labelLoiMK;
    }
}