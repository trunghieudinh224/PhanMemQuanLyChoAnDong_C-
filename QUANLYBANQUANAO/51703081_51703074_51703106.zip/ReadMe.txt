Cấu hình tối thiểu để chạy setup: 1920 x 1080 (Cấu hình thấp hơn sẽ bị mất đi 1 phần giao diện).
---------------
1. Giải nén file App.
2. Chạy setup.
3. Tạo 2 folder "Toa" và "PhieuNhap" ở folder của phần mềm.
4. Chạy phần mềm.
-------
Database sẽ nằm chung trong thư mục của phần mềm.
-------
Link video hướng dẫn sử dụng: 
Phần 1: https://youtu.be/K3BAtYaSYvw
Phần 2: https://youtu.be/S8h9ZTAXUMo
Phần 3: https://www.youtube.com/watch?v=JyAqxD-FXVw
