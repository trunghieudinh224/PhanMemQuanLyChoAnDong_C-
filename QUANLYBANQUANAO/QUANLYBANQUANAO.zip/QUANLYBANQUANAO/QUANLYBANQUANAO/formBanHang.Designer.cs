﻿namespace QUANLYBANQUANAO
{
    partial class formBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formBanHang));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStripMenu = new System.Windows.Forms.MenuStrip();
            this.quảnLýSạpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýLươngNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýDoanhThuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TaiKhoanNVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThongTinTaiKhoanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxThongTinKhachHang = new System.Windows.Forms.GroupBox();
            this.panelThongTinKhachHang = new System.Windows.Forms.Panel();
            this.textBoxTenKhachVangLai = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxKhachHang = new System.Windows.Forms.ComboBox();
            this.checkBoxKhachQuen = new System.Windows.Forms.CheckBox();
            this.checkBoxKhachVangLai = new System.Windows.Forms.CheckBox();
            this.labelTenKhachMoi = new System.Windows.Forms.Label();
            this.labelSDTKhachCu_Text = new System.Windows.Forms.Label();
            this.labelSDT = new System.Windows.Forms.Label();
            this.labelSDTKhachCu = new System.Windows.Forms.Label();
            this.labelDiaChi = new System.Windows.Forms.Label();
            this.textBoxSDTKhachVangLai = new System.Windows.Forms.TextBox();
            this.textBoxDiaChiKhachVangLai = new System.Windows.Forms.TextBox();
            this.labelDiaChiKhachMoi = new System.Windows.Forms.Label();
            this.labelDiaChi_Text = new System.Windows.Forms.Label();
            this.listViewMuaHang = new System.Windows.Forms.ListView();
            this.columnHeaderTenSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderThanhTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewTraHang = new System.Windows.Forms.ListView();
            this.columnHeaderTenSP_TraHang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoLuong_TraHang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDonGia_TraHang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderThanhTien_TraHang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dataGridViewSanPham = new System.Windows.Forms.DataGridView();
            this.TenSP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DanhMuc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongTon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.labelAnDong = new System.Windows.Forms.Label();
            this.labelTenSap = new System.Windows.Forms.Label();
            this.labelSDT2 = new System.Windows.Forms.Label();
            this.labelSDT1 = new System.Windows.Forms.Label();
            this.labelDiaChi2 = new System.Windows.Forms.Label();
            this.labelDiaChi1 = new System.Windows.Forms.Label();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.labelDanhMuc = new System.Windows.Forms.Label();
            this.checkBoxMuaHang = new System.Windows.Forms.CheckBox();
            this.buttonThanhToan = new System.Windows.Forms.Button();
            this.checkBoxTraHang = new System.Windows.Forms.CheckBox();
            this.textBoxTimKiem = new System.Windows.Forms.TextBox();
            this.comboBoxDanhMucSanPham = new System.Windows.Forms.ComboBox();
            this.numericUpDownSL = new System.Windows.Forms.NumericUpDown();
            this.labelSoLuong = new System.Windows.Forms.Label();
            this.timerTenSap = new System.Windows.Forms.Timer(this.components);
            this.tabControlThanhToan = new System.Windows.Forms.TabControl();
            this.tabPageTienMat = new System.Windows.Forms.TabPage();
            this.textBoxGiamGiaTienMat = new System.Windows.Forms.TextBox();
            this.labelTongSL1_Cost = new System.Windows.Forms.Label();
            this.labelTongSL1 = new System.Windows.Forms.Label();
            this.labelTienThua_Cost = new System.Windows.Forms.Label();
            this.labelKhachThieuTienMat_Cost = new System.Windows.Forms.Label();
            this.labelTienThua = new System.Windows.Forms.Label();
            this.labelKhachThieuTienMat = new System.Windows.Forms.Label();
            this.labelMuaTraTienMat_Cost = new System.Windows.Forms.Label();
            this.labelTongTienMat_Cost = new System.Windows.Forms.Label();
            this.textBoxTienMatKhachTra = new System.Windows.Forms.TextBox();
            this.labelTienMatKhachTra = new System.Windows.Forms.Label();
            this.labelTongTienMat = new System.Windows.Forms.Label();
            this.labelMuaTraTienMat = new System.Windows.Forms.Label();
            this.labelGiamGiaTienMat = new System.Windows.Forms.Label();
            this.tabPageCreditCard = new System.Windows.Forms.TabPage();
            this.textBoxGiamGiaCredit = new System.Windows.Forms.TextBox();
            this.labelTongSL2 = new System.Windows.Forms.Label();
            this.labelTongSL2_Cost = new System.Windows.Forms.Label();
            this.labelMuaTraCredit = new System.Windows.Forms.Label();
            this.labelKhachThieuCredit_Cost = new System.Windows.Forms.Label();
            this.labelMuaTraCredit_Cost = new System.Windows.Forms.Label();
            this.labelTongTienCredit_Cost = new System.Windows.Forms.Label();
            this.labelKhachThieuCredit = new System.Windows.Forms.Label();
            this.labelGiamGiaCredit = new System.Windows.Forms.Label();
            this.textBoxTienChuyenKhoan = new System.Windows.Forms.TextBox();
            this.labelTienChuyenKhoan = new System.Windows.Forms.Label();
            this.labelTongTienCredit = new System.Windows.Forms.Label();
            this.groupBoxThanhToan = new System.Windows.Forms.GroupBox();
            this.buttonX = new System.Windows.Forms.Button();
            this.panelDuoi = new System.Windows.Forms.Panel();
            this.labelThoiGian = new System.Windows.Forms.Label();
            this.labelNguoiTaoApp = new System.Windows.Forms.Label();
            this.timerGio = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStripMenu.SuspendLayout();
            this.groupBoxThongTinKhachHang.SuspendLayout();
            this.panelThongTinKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSL)).BeginInit();
            this.tabControlThanhToan.SuspendLayout();
            this.tabPageTienMat.SuspendLayout();
            this.tabPageCreditCard.SuspendLayout();
            this.groupBoxThanhToan.SuspendLayout();
            this.panelDuoi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStripMenu
            // 
            this.menuStripMenu.BackColor = System.Drawing.Color.CornflowerBlue;
            this.menuStripMenu.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.menuStripMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýSạpToolStripMenuItem,
            this.danhSáchKháchHàngToolStripMenuItem,
            this.TaiKhoanNVToolStripMenuItem});
            this.menuStripMenu.Location = new System.Drawing.Point(0, 0);
            this.menuStripMenu.MinimumSize = new System.Drawing.Size(1482, 39);
            this.menuStripMenu.Name = "menuStripMenu";
            this.menuStripMenu.Padding = new System.Windows.Forms.Padding(45, 2, 0, 2);
            this.menuStripMenu.Size = new System.Drawing.Size(1537, 39);
            this.menuStripMenu.TabIndex = 0;
            // 
            // quảnLýSạpToolStripMenuItem
            // 
            this.quảnLýSạpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tàiKhoảnSảnPhẩmToolStripMenuItem,
            this.quảnLýToaToolStripMenuItem1,
            this.nhậpHàngToolStripMenuItem,
            this.quảnLýLươngNhânViênToolStripMenuItem,
            this.quảnLýDoanhThuToolStripMenuItem});
            this.quảnLýSạpToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.quảnLýSạpToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýSạpToolStripMenuItem.Image")));
            this.quảnLýSạpToolStripMenuItem.Name = "quảnLýSạpToolStripMenuItem";
            this.quảnLýSạpToolStripMenuItem.Size = new System.Drawing.Size(172, 35);
            this.quảnLýSạpToolStripMenuItem.Text = "Quản lý Sạp";
            // 
            // tàiKhoảnSảnPhẩmToolStripMenuItem
            // 
            this.tàiKhoảnSảnPhẩmToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tàiKhoảnSảnPhẩmToolStripMenuItem.Image")));
            this.tàiKhoảnSảnPhẩmToolStripMenuItem.Name = "tàiKhoảnSảnPhẩmToolStripMenuItem";
            this.tàiKhoảnSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(350, 30);
            this.tàiKhoảnSảnPhẩmToolStripMenuItem.Text = "Tài khoản -- Sản phẩm";
            this.tàiKhoảnSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.tàiKhoảnSảnPhẩmToolStripMenuItem_Click);
            // 
            // quảnLýToaToolStripMenuItem1
            // 
            this.quảnLýToaToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýToaToolStripMenuItem1.Image")));
            this.quảnLýToaToolStripMenuItem1.Name = "quảnLýToaToolStripMenuItem1";
            this.quảnLýToaToolStripMenuItem1.Size = new System.Drawing.Size(350, 30);
            this.quảnLýToaToolStripMenuItem1.Text = "Quản lý toa";
            this.quảnLýToaToolStripMenuItem1.Click += new System.EventHandler(this.quảnLýToaToolStripMenuItem1_Click);
            // 
            // nhậpHàngToolStripMenuItem
            // 
            this.nhậpHàngToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("nhậpHàngToolStripMenuItem.Image")));
            this.nhậpHàngToolStripMenuItem.Name = "nhậpHàngToolStripMenuItem";
            this.nhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(350, 30);
            this.nhậpHàngToolStripMenuItem.Text = "Quản lý nhập hàng";
            this.nhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.nhậpHàngToolStripMenuItem_Click);
            // 
            // quảnLýLươngNhânViênToolStripMenuItem
            // 
            this.quảnLýLươngNhânViênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýLươngNhânViênToolStripMenuItem.Image")));
            this.quảnLýLươngNhânViênToolStripMenuItem.Name = "quảnLýLươngNhânViênToolStripMenuItem";
            this.quảnLýLươngNhânViênToolStripMenuItem.Size = new System.Drawing.Size(350, 30);
            this.quảnLýLươngNhânViênToolStripMenuItem.Text = "Quản lý lương nhân viên";
            this.quảnLýLươngNhânViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýLươngNhânViênToolStripMenuItem_Click);
            // 
            // quảnLýDoanhThuToolStripMenuItem
            // 
            this.quảnLýDoanhThuToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýDoanhThuToolStripMenuItem.Image")));
            this.quảnLýDoanhThuToolStripMenuItem.Name = "quảnLýDoanhThuToolStripMenuItem";
            this.quảnLýDoanhThuToolStripMenuItem.Size = new System.Drawing.Size(350, 30);
            this.quảnLýDoanhThuToolStripMenuItem.Text = "Quản lý doanh thu";
            this.quảnLýDoanhThuToolStripMenuItem.Click += new System.EventHandler(this.quảnLýDoanhThuToolStripMenuItem_Click);
            // 
            // danhSáchKháchHàngToolStripMenuItem
            // 
            this.danhSáchKháchHàngToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.danhSáchKháchHàngToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("danhSáchKháchHàngToolStripMenuItem.Image")));
            this.danhSáchKháchHàngToolStripMenuItem.Name = "danhSáchKháchHàngToolStripMenuItem";
            this.danhSáchKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(276, 35);
            this.danhSáchKháchHàngToolStripMenuItem.Text = "Danh sách khách hàng";
            this.danhSáchKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.danhSáchKháchHàngToolStripMenuItem_Click);
            // 
            // TaiKhoanNVToolStripMenuItem
            // 
            this.TaiKhoanNVToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ThongTinTaiKhoanToolStripMenuItem});
            this.TaiKhoanNVToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.TaiKhoanNVToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("TaiKhoanNVToolStripMenuItem.Image")));
            this.TaiKhoanNVToolStripMenuItem.Name = "TaiKhoanNVToolStripMenuItem";
            this.TaiKhoanNVToolStripMenuItem.Size = new System.Drawing.Size(190, 35);
            this.TaiKhoanNVToolStripMenuItem.Text = "Tên nhân viên";
            // 
            // ThongTinTaiKhoanToolStripMenuItem
            // 
            this.ThongTinTaiKhoanToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ThongTinTaiKhoanToolStripMenuItem.Image")));
            this.ThongTinTaiKhoanToolStripMenuItem.Name = "ThongTinTaiKhoanToolStripMenuItem";
            this.ThongTinTaiKhoanToolStripMenuItem.Size = new System.Drawing.Size(299, 30);
            this.ThongTinTaiKhoanToolStripMenuItem.Text = "Thông tin tài khoản";
            this.ThongTinTaiKhoanToolStripMenuItem.Click += new System.EventHandler(this.ThongTinTaiKhoanToolStripMenuItem_Click);
            // 
            // groupBoxThongTinKhachHang
            // 
            this.groupBoxThongTinKhachHang.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBoxThongTinKhachHang.Controls.Add(this.panelThongTinKhachHang);
            this.groupBoxThongTinKhachHang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxThongTinKhachHang.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxThongTinKhachHang.Location = new System.Drawing.Point(649, 434);
            this.groupBoxThongTinKhachHang.Name = "groupBoxThongTinKhachHang";
            this.groupBoxThongTinKhachHang.Size = new System.Drawing.Size(416, 348);
            this.groupBoxThongTinKhachHang.TabIndex = 19;
            this.groupBoxThongTinKhachHang.TabStop = false;
            this.groupBoxThongTinKhachHang.Text = "THÔNG TIN KHÁCH HÀNG";
            this.groupBoxThongTinKhachHang.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxThongTinKhachHang_Paint);
            // 
            // panelThongTinKhachHang
            // 
            this.panelThongTinKhachHang.BackColor = System.Drawing.Color.Khaki;
            this.panelThongTinKhachHang.Controls.Add(this.textBoxTenKhachVangLai);
            this.panelThongTinKhachHang.Controls.Add(this.label1);
            this.panelThongTinKhachHang.Controls.Add(this.comboBoxKhachHang);
            this.panelThongTinKhachHang.Controls.Add(this.checkBoxKhachQuen);
            this.panelThongTinKhachHang.Controls.Add(this.checkBoxKhachVangLai);
            this.panelThongTinKhachHang.Controls.Add(this.labelTenKhachMoi);
            this.panelThongTinKhachHang.Controls.Add(this.labelSDTKhachCu_Text);
            this.panelThongTinKhachHang.Controls.Add(this.labelSDT);
            this.panelThongTinKhachHang.Controls.Add(this.labelSDTKhachCu);
            this.panelThongTinKhachHang.Controls.Add(this.labelDiaChi);
            this.panelThongTinKhachHang.Controls.Add(this.textBoxSDTKhachVangLai);
            this.panelThongTinKhachHang.Controls.Add(this.textBoxDiaChiKhachVangLai);
            this.panelThongTinKhachHang.Controls.Add(this.labelDiaChiKhachMoi);
            this.panelThongTinKhachHang.Controls.Add(this.labelDiaChi_Text);
            this.panelThongTinKhachHang.Location = new System.Drawing.Point(6, 22);
            this.panelThongTinKhachHang.Name = "panelThongTinKhachHang";
            this.panelThongTinKhachHang.Size = new System.Drawing.Size(404, 320);
            this.panelThongTinKhachHang.TabIndex = 20;
            // 
            // textBoxTenKhachVangLai
            // 
            this.textBoxTenKhachVangLai.BackColor = System.Drawing.Color.White;
            this.textBoxTenKhachVangLai.Enabled = false;
            this.textBoxTenKhachVangLai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTenKhachVangLai.Location = new System.Drawing.Point(147, 241);
            this.textBoxTenKhachVangLai.Name = "textBoxTenKhachVangLai";
            this.textBoxTenKhachVangLai.Size = new System.Drawing.Size(249, 30);
            this.textBoxTenKhachVangLai.TabIndex = 29;
            this.textBoxTenKhachVangLai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenKhachVangLai_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Khaki;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(3, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 41;
            this.label1.Text = "Tên KH:";
            // 
            // comboBoxKhachHang
            // 
            this.comboBoxKhachHang.BackColor = System.Drawing.Color.White;
            this.comboBoxKhachHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxKhachHang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.comboBoxKhachHang.FormattingEnabled = true;
            this.comboBoxKhachHang.Location = new System.Drawing.Point(106, 33);
            this.comboBoxKhachHang.Name = "comboBoxKhachHang";
            this.comboBoxKhachHang.Size = new System.Drawing.Size(290, 28);
            this.comboBoxKhachHang.TabIndex = 20;
            this.comboBoxKhachHang.SelectedIndexChanged += new System.EventHandler(this.comboBoxKhachHang_SelectedIndexChanged);
            // 
            // checkBoxKhachQuen
            // 
            this.checkBoxKhachQuen.AutoSize = true;
            this.checkBoxKhachQuen.Checked = true;
            this.checkBoxKhachQuen.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxKhachQuen.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBoxKhachQuen.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBoxKhachQuen.Location = new System.Drawing.Point(8, 5);
            this.checkBoxKhachQuen.Name = "checkBoxKhachQuen";
            this.checkBoxKhachQuen.Size = new System.Drawing.Size(130, 27);
            this.checkBoxKhachQuen.TabIndex = 40;
            this.checkBoxKhachQuen.Text = "Khách quen";
            this.checkBoxKhachQuen.UseVisualStyleBackColor = true;
            this.checkBoxKhachQuen.CheckedChanged += new System.EventHandler(this.checkBoxKhachQuen_CheckedChanged);
            // 
            // checkBoxKhachVangLai
            // 
            this.checkBoxKhachVangLai.AutoSize = true;
            this.checkBoxKhachVangLai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBoxKhachVangLai.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBoxKhachVangLai.Location = new System.Drawing.Point(8, 170);
            this.checkBoxKhachVangLai.Name = "checkBoxKhachVangLai";
            this.checkBoxKhachVangLai.Size = new System.Drawing.Size(155, 27);
            this.checkBoxKhachVangLai.TabIndex = 39;
            this.checkBoxKhachVangLai.Text = "Khách vãng lai";
            this.checkBoxKhachVangLai.UseVisualStyleBackColor = true;
            this.checkBoxKhachVangLai.CheckedChanged += new System.EventHandler(this.checkBoxKhachVangLai_CheckedChanged);
            // 
            // labelTenKhachMoi
            // 
            this.labelTenKhachMoi.AutoSize = true;
            this.labelTenKhachMoi.BackColor = System.Drawing.Color.Khaki;
            this.labelTenKhachMoi.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhachMoi.ForeColor = System.Drawing.Color.Black;
            this.labelTenKhachMoi.Location = new System.Drawing.Point(3, 247);
            this.labelTenKhachMoi.Name = "labelTenKhachMoi";
            this.labelTenKhachMoi.Size = new System.Drawing.Size(97, 25);
            this.labelTenKhachMoi.TabIndex = 32;
            this.labelTenKhachMoi.Text = "Tên KH:";
            // 
            // labelSDTKhachCu_Text
            // 
            this.labelSDTKhachCu_Text.AutoSize = true;
            this.labelSDTKhachCu_Text.BackColor = System.Drawing.Color.Khaki;
            this.labelSDTKhachCu_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDTKhachCu_Text.ForeColor = System.Drawing.Color.Black;
            this.labelSDTKhachCu_Text.Location = new System.Drawing.Point(101, 71);
            this.labelSDTKhachCu_Text.MaximumSize = new System.Drawing.Size(292, 26);
            this.labelSDTKhachCu_Text.MinimumSize = new System.Drawing.Size(292, 26);
            this.labelSDTKhachCu_Text.Name = "labelSDTKhachCu_Text";
            this.labelSDTKhachCu_Text.Size = new System.Drawing.Size(292, 26);
            this.labelSDTKhachCu_Text.TabIndex = 32;
            this.labelSDTKhachCu_Text.Text = "ádcawcawcaw";
            // 
            // labelSDT
            // 
            this.labelSDT.AutoSize = true;
            this.labelSDT.BackColor = System.Drawing.Color.Khaki;
            this.labelSDT.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT.ForeColor = System.Drawing.Color.Black;
            this.labelSDT.Location = new System.Drawing.Point(3, 209);
            this.labelSDT.Name = "labelSDT";
            this.labelSDT.Size = new System.Drawing.Size(60, 25);
            this.labelSDT.TabIndex = 35;
            this.labelSDT.Text = "SĐT:";
            // 
            // labelSDTKhachCu
            // 
            this.labelSDTKhachCu.AutoSize = true;
            this.labelSDTKhachCu.BackColor = System.Drawing.Color.Khaki;
            this.labelSDTKhachCu.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDTKhachCu.ForeColor = System.Drawing.Color.Black;
            this.labelSDTKhachCu.Location = new System.Drawing.Point(3, 71);
            this.labelSDTKhachCu.Name = "labelSDTKhachCu";
            this.labelSDTKhachCu.Size = new System.Drawing.Size(60, 25);
            this.labelSDTKhachCu.TabIndex = 31;
            this.labelSDTKhachCu.Text = "SĐT:";
            // 
            // labelDiaChi
            // 
            this.labelDiaChi.AutoSize = true;
            this.labelDiaChi.BackColor = System.Drawing.Color.Khaki;
            this.labelDiaChi.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChi.ForeColor = System.Drawing.Color.Black;
            this.labelDiaChi.Location = new System.Drawing.Point(3, 104);
            this.labelDiaChi.Name = "labelDiaChi";
            this.labelDiaChi.Size = new System.Drawing.Size(86, 25);
            this.labelDiaChi.TabIndex = 29;
            this.labelDiaChi.Text = "Địa chỉ:";
            // 
            // textBoxSDTKhachVangLai
            // 
            this.textBoxSDTKhachVangLai.BackColor = System.Drawing.Color.White;
            this.textBoxSDTKhachVangLai.Enabled = false;
            this.textBoxSDTKhachVangLai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxSDTKhachVangLai.Location = new System.Drawing.Point(147, 201);
            this.textBoxSDTKhachVangLai.Name = "textBoxSDTKhachVangLai";
            this.textBoxSDTKhachVangLai.Size = new System.Drawing.Size(249, 30);
            this.textBoxSDTKhachVangLai.TabIndex = 36;
            this.textBoxSDTKhachVangLai.TextChanged += new System.EventHandler(this.textBoxSDTKhachVangLai_TextChanged);
            this.textBoxSDTKhachVangLai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSDTKhachVangLai_KeyPress);
            // 
            // textBoxDiaChiKhachVangLai
            // 
            this.textBoxDiaChiKhachVangLai.BackColor = System.Drawing.Color.White;
            this.textBoxDiaChiKhachVangLai.Enabled = false;
            this.textBoxDiaChiKhachVangLai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxDiaChiKhachVangLai.Location = new System.Drawing.Point(147, 281);
            this.textBoxDiaChiKhachVangLai.Name = "textBoxDiaChiKhachVangLai";
            this.textBoxDiaChiKhachVangLai.Size = new System.Drawing.Size(249, 30);
            this.textBoxDiaChiKhachVangLai.TabIndex = 34;
            // 
            // labelDiaChiKhachMoi
            // 
            this.labelDiaChiKhachMoi.AutoSize = true;
            this.labelDiaChiKhachMoi.BackColor = System.Drawing.Color.Khaki;
            this.labelDiaChiKhachMoi.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiKhachMoi.ForeColor = System.Drawing.Color.Black;
            this.labelDiaChiKhachMoi.Location = new System.Drawing.Point(3, 285);
            this.labelDiaChiKhachMoi.Name = "labelDiaChiKhachMoi";
            this.labelDiaChiKhachMoi.Size = new System.Drawing.Size(86, 25);
            this.labelDiaChiKhachMoi.TabIndex = 33;
            this.labelDiaChiKhachMoi.Text = "Địa chỉ:";
            // 
            // labelDiaChi_Text
            // 
            this.labelDiaChi_Text.AutoSize = true;
            this.labelDiaChi_Text.BackColor = System.Drawing.Color.Khaki;
            this.labelDiaChi_Text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChi_Text.ForeColor = System.Drawing.Color.Black;
            this.labelDiaChi_Text.Location = new System.Drawing.Point(101, 104);
            this.labelDiaChi_Text.MaximumSize = new System.Drawing.Size(292, 56);
            this.labelDiaChi_Text.MinimumSize = new System.Drawing.Size(292, 56);
            this.labelDiaChi_Text.Name = "labelDiaChi_Text";
            this.labelDiaChi_Text.Size = new System.Drawing.Size(292, 56);
            this.labelDiaChi_Text.TabIndex = 30;
            this.labelDiaChi_Text.Text = "ac ascawecawc ăcecawsdcsdssd asdc á csdcscs ";
            // 
            // listViewMuaHang
            // 
            this.listViewMuaHang.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewMuaHang.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.listViewMuaHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewMuaHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTenSP,
            this.columnHeaderSoLuong,
            this.columnHeaderDonGia,
            this.columnHeaderThanhTien});
            this.listViewMuaHang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewMuaHang.FullRowSelect = true;
            this.listViewMuaHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewMuaHang.HideSelection = false;
            this.listViewMuaHang.HoverSelection = true;
            this.listViewMuaHang.Location = new System.Drawing.Point(649, 89);
            this.listViewMuaHang.MultiSelect = false;
            this.listViewMuaHang.Name = "listViewMuaHang";
            this.listViewMuaHang.Size = new System.Drawing.Size(445, 338);
            this.listViewMuaHang.TabIndex = 21;
            this.listViewMuaHang.UseCompatibleStateImageBehavior = false;
            this.listViewMuaHang.View = System.Windows.Forms.View.Details;
            this.listViewMuaHang.DoubleClick += new System.EventHandler(this.listViewMuaHang_DoubleClick);
            // 
            // columnHeaderTenSP
            // 
            this.columnHeaderTenSP.Text = "Tên sản phẩm";
            this.columnHeaderTenSP.Width = 138;
            // 
            // columnHeaderSoLuong
            // 
            this.columnHeaderSoLuong.Text = "SL";
            this.columnHeaderSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSoLuong.Width = 40;
            // 
            // columnHeaderDonGia
            // 
            this.columnHeaderDonGia.Text = "Đơn giá";
            this.columnHeaderDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderDonGia.Width = 70;
            // 
            // columnHeaderThanhTien
            // 
            this.columnHeaderThanhTien.Text = "Thành tiền";
            this.columnHeaderThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderThanhTien.Width = 85;
            // 
            // listViewTraHang
            // 
            this.listViewTraHang.BackColor = System.Drawing.Color.Chocolate;
            this.listViewTraHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewTraHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTenSP_TraHang,
            this.columnHeaderSoLuong_TraHang,
            this.columnHeaderDonGia_TraHang,
            this.columnHeaderThanhTien_TraHang});
            this.listViewTraHang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewTraHang.FullRowSelect = true;
            this.listViewTraHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewTraHang.HideSelection = false;
            this.listViewTraHang.Location = new System.Drawing.Point(1110, 89);
            this.listViewTraHang.MultiSelect = false;
            this.listViewTraHang.Name = "listViewTraHang";
            this.listViewTraHang.Size = new System.Drawing.Size(423, 338);
            this.listViewTraHang.TabIndex = 22;
            this.listViewTraHang.UseCompatibleStateImageBehavior = false;
            this.listViewTraHang.View = System.Windows.Forms.View.Details;
            this.listViewTraHang.DoubleClick += new System.EventHandler(this.listViewTraHang_DoubleClick);
            // 
            // columnHeaderTenSP_TraHang
            // 
            this.columnHeaderTenSP_TraHang.Text = "Tên sản phẩm";
            this.columnHeaderTenSP_TraHang.Width = 130;
            // 
            // columnHeaderSoLuong_TraHang
            // 
            this.columnHeaderSoLuong_TraHang.Text = "SL";
            this.columnHeaderSoLuong_TraHang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSoLuong_TraHang.Width = 35;
            // 
            // columnHeaderDonGia_TraHang
            // 
            this.columnHeaderDonGia_TraHang.Text = "Đơn giá";
            this.columnHeaderDonGia_TraHang.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderDonGia_TraHang.Width = 70;
            // 
            // columnHeaderThanhTien_TraHang
            // 
            this.columnHeaderThanhTien_TraHang.Text = "Thành tiền";
            this.columnHeaderThanhTien_TraHang.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderThanhTien_TraHang.Width = 80;
            // 
            // dataGridViewSanPham
            // 
            this.dataGridViewSanPham.AllowUserToAddRows = false;
            this.dataGridViewSanPham.AllowUserToDeleteRows = false;
            this.dataGridViewSanPham.AllowUserToResizeColumns = false;
            this.dataGridViewSanPham.AllowUserToResizeRows = false;
            this.dataGridViewSanPham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSanPham.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewSanPham.ColumnHeadersHeight = 29;
            this.dataGridViewSanPham.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TenSP,
            this.DanhMuc,
            this.GiaBan,
            this.SoLuongTon});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSanPham.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewSanPham.Location = new System.Drawing.Point(4, 286);
            this.dataGridViewSanPham.MultiSelect = false;
            this.dataGridViewSanPham.Name = "dataGridViewSanPham";
            this.dataGridViewSanPham.ReadOnly = true;
            this.dataGridViewSanPham.RowHeadersVisible = false;
            this.dataGridViewSanPham.RowHeadersWidth = 51;
            this.dataGridViewSanPham.RowTemplate.Height = 34;
            this.dataGridViewSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSanPham.Size = new System.Drawing.Size(628, 545);
            this.dataGridViewSanPham.TabIndex = 37;
            this.dataGridViewSanPham.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSanPham_CellDoubleClick);
            // 
            // TenSP
            // 
            this.TenSP.DataPropertyName = "TenSP";
            this.TenSP.HeaderText = "Tên SP";
            this.TenSP.MinimumWidth = 6;
            this.TenSP.Name = "TenSP";
            this.TenSP.ReadOnly = true;
            // 
            // DanhMuc
            // 
            this.DanhMuc.DataPropertyName = "DanhMuc";
            this.DanhMuc.HeaderText = "Danh mục";
            this.DanhMuc.MinimumWidth = 6;
            this.DanhMuc.Name = "DanhMuc";
            this.DanhMuc.ReadOnly = true;
            // 
            // GiaBan
            // 
            this.GiaBan.DataPropertyName = "GiaBan";
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = "0";
            this.GiaBan.DefaultCellStyle = dataGridViewCellStyle2;
            this.GiaBan.HeaderText = "Giá bán";
            this.GiaBan.MinimumWidth = 6;
            this.GiaBan.Name = "GiaBan";
            this.GiaBan.ReadOnly = true;
            // 
            // SoLuongTon
            // 
            this.SoLuongTon.DataPropertyName = "SoLuongTon";
            this.SoLuongTon.HeaderText = "SL tồn";
            this.SoLuongTon.MinimumWidth = 6;
            this.SoLuongTon.Name = "SoLuongTon";
            this.SoLuongTon.ReadOnly = true;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.Location = new System.Drawing.Point(1, 48);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(198, 167);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabIndex = 38;
            this.pictureBoxLogo.TabStop = false;
            // 
            // labelAnDong
            // 
            this.labelAnDong.AutoSize = true;
            this.labelAnDong.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelAnDong.Location = new System.Drawing.Point(176, 54);
            this.labelAnDong.Name = "labelAnDong";
            this.labelAnDong.Size = new System.Drawing.Size(441, 22);
            this.labelAnDong.TabIndex = 40;
            this.labelAnDong.Text = "TRUNG TÂM THƯƠNG MẠI DỊCH VỤ AN ĐÔNG";
            // 
            // labelTenSap
            // 
            this.labelTenSap.AutoSize = true;
            this.labelTenSap.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenSap.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTenSap.Location = new System.Drawing.Point(181, 89);
            this.labelTenSap.Name = "labelTenSap";
            this.labelTenSap.Size = new System.Drawing.Size(425, 44);
            this.labelTenSap.TabIndex = 39;
            this.labelTenSap.Text = "LỢI DUNG (THIỆN VY)";
            // 
            // labelSDT2
            // 
            this.labelSDT2.AutoSize = true;
            this.labelSDT2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT2.Location = new System.Drawing.Point(459, 166);
            this.labelSDT2.Name = "labelSDT2";
            this.labelSDT2.Size = new System.Drawing.Size(170, 22);
            this.labelSDT2.TabIndex = 44;
            this.labelSDT2.Text = "0906.363.120 (Mai)";
            // 
            // labelSDT1
            // 
            this.labelSDT1.AutoSize = true;
            this.labelSDT1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT1.Location = new System.Drawing.Point(421, 141);
            this.labelSDT1.Name = "labelSDT1";
            this.labelSDT1.Size = new System.Drawing.Size(206, 22);
            this.labelSDT1.TabIndex = 43;
            this.labelSDT1.Text = "ĐT: 0903.972.674 (Mai)";
            // 
            // labelDiaChi2
            // 
            this.labelDiaChi2.AutoSize = true;
            this.labelDiaChi2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChi2.Location = new System.Drawing.Point(230, 166);
            this.labelDiaChi2.Name = "labelDiaChi2";
            this.labelDiaChi2.Size = new System.Drawing.Size(122, 22);
            this.labelDiaChi2.TabIndex = 42;
            this.labelDiaChi2.Text = "C54-55 Lầu 1";
            // 
            // labelDiaChi1
            // 
            this.labelDiaChi1.AutoSize = true;
            this.labelDiaChi1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChi1.Location = new System.Drawing.Point(187, 141);
            this.labelDiaChi1.Name = "labelDiaChi1";
            this.labelDiaChi1.Size = new System.Drawing.Size(163, 22);
            this.labelDiaChi1.TabIndex = 41;
            this.labelDiaChi1.Text = "Sạp: C65-66 Lầu 1";
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 45;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(1428, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 38);
            this.buttonAn.TabIndex = 47;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // labelDanhMuc
            // 
            this.labelDanhMuc.AutoSize = true;
            this.labelDanhMuc.BackColor = System.Drawing.Color.Transparent;
            this.labelDanhMuc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDanhMuc.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDanhMuc.Location = new System.Drawing.Point(-1, 218);
            this.labelDanhMuc.Name = "labelDanhMuc";
            this.labelDanhMuc.Size = new System.Drawing.Size(145, 26);
            this.labelDanhMuc.TabIndex = 48;
            this.labelDanhMuc.Text = "DANH MỤC";
            // 
            // checkBoxMuaHang
            // 
            this.checkBoxMuaHang.AutoSize = true;
            this.checkBoxMuaHang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBoxMuaHang.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBoxMuaHang.Location = new System.Drawing.Point(649, 53);
            this.checkBoxMuaHang.Name = "checkBoxMuaHang";
            this.checkBoxMuaHang.Size = new System.Drawing.Size(167, 30);
            this.checkBoxMuaHang.TabIndex = 17;
            this.checkBoxMuaHang.Text = "MUA HÀNG";
            this.checkBoxMuaHang.UseVisualStyleBackColor = true;
            this.checkBoxMuaHang.CheckedChanged += new System.EventHandler(this.checkBoxMuaHang_CheckedChanged);
            this.checkBoxMuaHang.Click += new System.EventHandler(this.checkBoxMuaHang_Click);
            // 
            // buttonThanhToan
            // 
            this.buttonThanhToan.BackColor = System.Drawing.Color.Red;
            this.buttonThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThanhToan.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThanhToan.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonThanhToan.Location = new System.Drawing.Point(1381, 783);
            this.buttonThanhToan.Name = "buttonThanhToan";
            this.buttonThanhToan.Size = new System.Drawing.Size(155, 47);
            this.buttonThanhToan.TabIndex = 7;
            this.buttonThanhToan.Text = "Thanh toán";
            this.buttonThanhToan.UseVisualStyleBackColor = false;
            this.buttonThanhToan.Click += new System.EventHandler(this.buttonThanhToan_Click);
            // 
            // checkBoxTraHang
            // 
            this.checkBoxTraHang.AutoSize = true;
            this.checkBoxTraHang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.checkBoxTraHang.ForeColor = System.Drawing.Color.DarkRed;
            this.checkBoxTraHang.Location = new System.Drawing.Point(1110, 54);
            this.checkBoxTraHang.Name = "checkBoxTraHang";
            this.checkBoxTraHang.Size = new System.Drawing.Size(160, 30);
            this.checkBoxTraHang.TabIndex = 49;
            this.checkBoxTraHang.Text = "TRẢ HÀNG";
            this.checkBoxTraHang.UseVisualStyleBackColor = true;
            this.checkBoxTraHang.CheckedChanged += new System.EventHandler(this.checkBoxTraHang_CheckedChanged);
            this.checkBoxTraHang.Click += new System.EventHandler(this.checkBoxTraHang_Click);
            // 
            // textBoxTimKiem
            // 
            this.textBoxTimKiem.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimKiem.Location = new System.Drawing.Point(488, 211);
            this.textBoxTimKiem.Name = "textBoxTimKiem";
            this.textBoxTimKiem.Size = new System.Drawing.Size(144, 33);
            this.textBoxTimKiem.TabIndex = 51;
            this.textBoxTimKiem.TextChanged += new System.EventHandler(this.textBoxTimKiem_TextChanged);
            this.textBoxTimKiem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTimKiem_KeyPress);
            // 
            // comboBoxDanhMucSanPham
            // 
            this.comboBoxDanhMucSanPham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDanhMucSanPham.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.comboBoxDanhMucSanPham.FormattingEnabled = true;
            this.comboBoxDanhMucSanPham.Location = new System.Drawing.Point(4, 248);
            this.comboBoxDanhMucSanPham.Name = "comboBoxDanhMucSanPham";
            this.comboBoxDanhMucSanPham.Size = new System.Drawing.Size(140, 33);
            this.comboBoxDanhMucSanPham.TabIndex = 35;
            this.comboBoxDanhMucSanPham.SelectedIndexChanged += new System.EventHandler(this.comboBoxDanhMucSanPham_SelectedIndexChanged);
            // 
            // numericUpDownSL
            // 
            this.numericUpDownSL.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.numericUpDownSL.Location = new System.Drawing.Point(571, 249);
            this.numericUpDownSL.Name = "numericUpDownSL";
            this.numericUpDownSL.Size = new System.Drawing.Size(61, 33);
            this.numericUpDownSL.TabIndex = 54;
            // 
            // labelSoLuong
            // 
            this.labelSoLuong.AutoSize = true;
            this.labelSoLuong.BackColor = System.Drawing.Color.Transparent;
            this.labelSoLuong.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSoLuong.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSoLuong.Location = new System.Drawing.Point(419, 257);
            this.labelSoLuong.Name = "labelSoLuong";
            this.labelSoLuong.Size = new System.Drawing.Size(145, 26);
            this.labelSoLuong.TabIndex = 55;
            this.labelSoLuong.Text = "SỐ LƯỢNG ";
            // 
            // timerTenSap
            // 
            this.timerTenSap.Interval = 300;
            this.timerTenSap.Tick += new System.EventHandler(this.timerTenSap_Tick);
            // 
            // tabControlThanhToan
            // 
            this.tabControlThanhToan.Controls.Add(this.tabPageTienMat);
            this.tabControlThanhToan.Controls.Add(this.tabPageCreditCard);
            this.tabControlThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabControlThanhToan.Location = new System.Drawing.Point(6, 28);
            this.tabControlThanhToan.Name = "tabControlThanhToan";
            this.tabControlThanhToan.SelectedIndex = 0;
            this.tabControlThanhToan.Size = new System.Drawing.Size(454, 316);
            this.tabControlThanhToan.TabIndex = 1;
            this.tabControlThanhToan.SelectedIndexChanged += new System.EventHandler(this.tabControlThanhToan_SelectedIndexChanged);
            // 
            // tabPageTienMat
            // 
            this.tabPageTienMat.BackColor = System.Drawing.Color.Khaki;
            this.tabPageTienMat.Controls.Add(this.textBoxGiamGiaTienMat);
            this.tabPageTienMat.Controls.Add(this.labelTongSL1_Cost);
            this.tabPageTienMat.Controls.Add(this.labelTongSL1);
            this.tabPageTienMat.Controls.Add(this.labelTienThua_Cost);
            this.tabPageTienMat.Controls.Add(this.labelKhachThieuTienMat_Cost);
            this.tabPageTienMat.Controls.Add(this.labelTienThua);
            this.tabPageTienMat.Controls.Add(this.labelKhachThieuTienMat);
            this.tabPageTienMat.Controls.Add(this.labelMuaTraTienMat_Cost);
            this.tabPageTienMat.Controls.Add(this.labelTongTienMat_Cost);
            this.tabPageTienMat.Controls.Add(this.textBoxTienMatKhachTra);
            this.tabPageTienMat.Controls.Add(this.labelTienMatKhachTra);
            this.tabPageTienMat.Controls.Add(this.labelTongTienMat);
            this.tabPageTienMat.Controls.Add(this.labelMuaTraTienMat);
            this.tabPageTienMat.Controls.Add(this.labelGiamGiaTienMat);
            this.tabPageTienMat.Location = new System.Drawing.Point(4, 34);
            this.tabPageTienMat.Name = "tabPageTienMat";
            this.tabPageTienMat.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTienMat.Size = new System.Drawing.Size(446, 278);
            this.tabPageTienMat.TabIndex = 0;
            this.tabPageTienMat.Text = "Tiền mặt";
            // 
            // textBoxGiamGiaTienMat
            // 
            this.textBoxGiamGiaTienMat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxGiamGiaTienMat.Location = new System.Drawing.Point(279, 79);
            this.textBoxGiamGiaTienMat.Name = "textBoxGiamGiaTienMat";
            this.textBoxGiamGiaTienMat.Size = new System.Drawing.Size(155, 34);
            this.textBoxGiamGiaTienMat.TabIndex = 21;
            this.textBoxGiamGiaTienMat.Text = "0";
            this.textBoxGiamGiaTienMat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxGiamGiaTienMat.TextChanged += new System.EventHandler(this.textBoxGiamGiaTienMat_TextChanged);
            this.textBoxGiamGiaTienMat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxGiamGiaTienMat_KeyPress);
            // 
            // labelTongSL1_Cost
            // 
            this.labelTongSL1_Cost.AutoSize = true;
            this.labelTongSL1_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongSL1_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelTongSL1_Cost.Location = new System.Drawing.Point(301, 3);
            this.labelTongSL1_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelTongSL1_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelTongSL1_Cost.Name = "labelTongSL1_Cost";
            this.labelTongSL1_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelTongSL1_Cost.TabIndex = 20;
            this.labelTongSL1_Cost.Text = "0";
            this.labelTongSL1_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongSL1
            // 
            this.labelTongSL1.AutoSize = true;
            this.labelTongSL1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongSL1.ForeColor = System.Drawing.Color.Black;
            this.labelTongSL1.Location = new System.Drawing.Point(7, 3);
            this.labelTongSL1.Name = "labelTongSL1";
            this.labelTongSL1.Size = new System.Drawing.Size(211, 26);
            this.labelTongSL1.TabIndex = 19;
            this.labelTongSL1.Text = "Tổng SL (mua-trả):";
            // 
            // labelTienThua_Cost
            // 
            this.labelTienThua_Cost.AutoSize = true;
            this.labelTienThua_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienThua_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelTienThua_Cost.Location = new System.Drawing.Point(301, 243);
            this.labelTienThua_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelTienThua_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelTienThua_Cost.Name = "labelTienThua_Cost";
            this.labelTienThua_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelTienThua_Cost.TabIndex = 16;
            this.labelTienThua_Cost.Text = "0";
            this.labelTienThua_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachThieuTienMat_Cost
            // 
            this.labelKhachThieuTienMat_Cost.AutoSize = true;
            this.labelKhachThieuTienMat_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachThieuTienMat_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelKhachThieuTienMat_Cost.Location = new System.Drawing.Point(301, 203);
            this.labelKhachThieuTienMat_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelKhachThieuTienMat_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelKhachThieuTienMat_Cost.Name = "labelKhachThieuTienMat_Cost";
            this.labelKhachThieuTienMat_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelKhachThieuTienMat_Cost.TabIndex = 15;
            this.labelKhachThieuTienMat_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTienThua
            // 
            this.labelTienThua.AutoSize = true;
            this.labelTienThua.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienThua.ForeColor = System.Drawing.Color.Black;
            this.labelTienThua.Location = new System.Drawing.Point(7, 243);
            this.labelTienThua.Name = "labelTienThua";
            this.labelTienThua.Size = new System.Drawing.Size(119, 26);
            this.labelTienThua.TabIndex = 13;
            this.labelTienThua.Text = "Tiền thừa:";
            // 
            // labelKhachThieuTienMat
            // 
            this.labelKhachThieuTienMat.AutoSize = true;
            this.labelKhachThieuTienMat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachThieuTienMat.ForeColor = System.Drawing.Color.Black;
            this.labelKhachThieuTienMat.Location = new System.Drawing.Point(7, 203);
            this.labelKhachThieuTienMat.Name = "labelKhachThieuTienMat";
            this.labelKhachThieuTienMat.Size = new System.Drawing.Size(146, 26);
            this.labelKhachThieuTienMat.TabIndex = 12;
            this.labelKhachThieuTienMat.Text = "Khách thiếu:";
            // 
            // labelMuaTraTienMat_Cost
            // 
            this.labelMuaTraTienMat_Cost.AutoSize = true;
            this.labelMuaTraTienMat_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMuaTraTienMat_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelMuaTraTienMat_Cost.Location = new System.Drawing.Point(193, 43);
            this.labelMuaTraTienMat_Cost.MaximumSize = new System.Drawing.Size(248, 26);
            this.labelMuaTraTienMat_Cost.MinimumSize = new System.Drawing.Size(248, 26);
            this.labelMuaTraTienMat_Cost.Name = "labelMuaTraTienMat_Cost";
            this.labelMuaTraTienMat_Cost.Size = new System.Drawing.Size(248, 26);
            this.labelMuaTraTienMat_Cost.TabIndex = 11;
            this.labelMuaTraTienMat_Cost.Text = "0";
            this.labelMuaTraTienMat_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongTienMat_Cost
            // 
            this.labelTongTienMat_Cost.AutoSize = true;
            this.labelTongTienMat_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienMat_Cost.ForeColor = System.Drawing.Color.Red;
            this.labelTongTienMat_Cost.Location = new System.Drawing.Point(301, 123);
            this.labelTongTienMat_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelTongTienMat_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelTongTienMat_Cost.Name = "labelTongTienMat_Cost";
            this.labelTongTienMat_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelTongTienMat_Cost.TabIndex = 9;
            this.labelTongTienMat_Cost.Text = "0";
            this.labelTongTienMat_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.labelTongTienMat_Cost.TextChanged += new System.EventHandler(this.labelTongTienMat_Cost_TextChanged);
            // 
            // textBoxTienMatKhachTra
            // 
            this.textBoxTienMatKhachTra.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTienMatKhachTra.Location = new System.Drawing.Point(279, 155);
            this.textBoxTienMatKhachTra.MaxLength = 1000000000;
            this.textBoxTienMatKhachTra.Name = "textBoxTienMatKhachTra";
            this.textBoxTienMatKhachTra.Size = new System.Drawing.Size(155, 34);
            this.textBoxTienMatKhachTra.TabIndex = 8;
            this.textBoxTienMatKhachTra.Text = "0";
            this.textBoxTienMatKhachTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTienMatKhachTra.TextChanged += new System.EventHandler(this.textBoxTienMatKhachTra_TextChanged);
            this.textBoxTienMatKhachTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTienMatKhachTra_KeyPress);
            // 
            // labelTienMatKhachTra
            // 
            this.labelTienMatKhachTra.AutoSize = true;
            this.labelTienMatKhachTra.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienMatKhachTra.ForeColor = System.Drawing.Color.Black;
            this.labelTienMatKhachTra.Location = new System.Drawing.Point(7, 163);
            this.labelTienMatKhachTra.Name = "labelTienMatKhachTra";
            this.labelTienMatKhachTra.Size = new System.Drawing.Size(171, 26);
            this.labelTienMatKhachTra.TabIndex = 7;
            this.labelTienMatKhachTra.Text = "Tiền khách trả:";
            // 
            // labelTongTienMat
            // 
            this.labelTongTienMat.AutoSize = true;
            this.labelTongTienMat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienMat.ForeColor = System.Drawing.Color.Black;
            this.labelTongTienMat.Location = new System.Drawing.Point(7, 123);
            this.labelTongTienMat.Name = "labelTongTienMat";
            this.labelTongTienMat.Size = new System.Drawing.Size(117, 26);
            this.labelTongTienMat.TabIndex = 6;
            this.labelTongTienMat.Text = "Tổng tiền:";
            // 
            // labelMuaTraTienMat
            // 
            this.labelMuaTraTienMat.AutoSize = true;
            this.labelMuaTraTienMat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMuaTraTienMat.ForeColor = System.Drawing.Color.Black;
            this.labelMuaTraTienMat.Location = new System.Drawing.Point(7, 43);
            this.labelMuaTraTienMat.Name = "labelMuaTraTienMat";
            this.labelMuaTraTienMat.Size = new System.Drawing.Size(124, 26);
            this.labelMuaTraTienMat.TabIndex = 3;
            this.labelMuaTraTienMat.Text = "Mua - Trả:";
            // 
            // labelGiamGiaTienMat
            // 
            this.labelGiamGiaTienMat.AutoSize = true;
            this.labelGiamGiaTienMat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiamGiaTienMat.ForeColor = System.Drawing.Color.Black;
            this.labelGiamGiaTienMat.Location = new System.Drawing.Point(7, 83);
            this.labelGiamGiaTienMat.Name = "labelGiamGiaTienMat";
            this.labelGiamGiaTienMat.Size = new System.Drawing.Size(113, 26);
            this.labelGiamGiaTienMat.TabIndex = 5;
            this.labelGiamGiaTienMat.Text = "Giảm giá:";
            // 
            // tabPageCreditCard
            // 
            this.tabPageCreditCard.BackColor = System.Drawing.Color.Khaki;
            this.tabPageCreditCard.Controls.Add(this.textBoxGiamGiaCredit);
            this.tabPageCreditCard.Controls.Add(this.labelTongSL2);
            this.tabPageCreditCard.Controls.Add(this.labelTongSL2_Cost);
            this.tabPageCreditCard.Controls.Add(this.labelMuaTraCredit);
            this.tabPageCreditCard.Controls.Add(this.labelKhachThieuCredit_Cost);
            this.tabPageCreditCard.Controls.Add(this.labelMuaTraCredit_Cost);
            this.tabPageCreditCard.Controls.Add(this.labelTongTienCredit_Cost);
            this.tabPageCreditCard.Controls.Add(this.labelKhachThieuCredit);
            this.tabPageCreditCard.Controls.Add(this.labelGiamGiaCredit);
            this.tabPageCreditCard.Controls.Add(this.textBoxTienChuyenKhoan);
            this.tabPageCreditCard.Controls.Add(this.labelTienChuyenKhoan);
            this.tabPageCreditCard.Controls.Add(this.labelTongTienCredit);
            this.tabPageCreditCard.Location = new System.Drawing.Point(4, 34);
            this.tabPageCreditCard.Name = "tabPageCreditCard";
            this.tabPageCreditCard.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCreditCard.Size = new System.Drawing.Size(446, 278);
            this.tabPageCreditCard.TabIndex = 1;
            this.tabPageCreditCard.Text = "Credit card";
            // 
            // textBoxGiamGiaCredit
            // 
            this.textBoxGiamGiaCredit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxGiamGiaCredit.Location = new System.Drawing.Point(279, 79);
            this.textBoxGiamGiaCredit.Name = "textBoxGiamGiaCredit";
            this.textBoxGiamGiaCredit.Size = new System.Drawing.Size(155, 34);
            this.textBoxGiamGiaCredit.TabIndex = 31;
            this.textBoxGiamGiaCredit.Text = "0";
            this.textBoxGiamGiaCredit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxGiamGiaCredit.TextChanged += new System.EventHandler(this.textBoxGiamGiaCredit_TextChanged);
            this.textBoxGiamGiaCredit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxGiamGiaCredit_KeyPress);
            // 
            // labelTongSL2
            // 
            this.labelTongSL2.AutoSize = true;
            this.labelTongSL2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongSL2.ForeColor = System.Drawing.Color.Black;
            this.labelTongSL2.Location = new System.Drawing.Point(7, 3);
            this.labelTongSL2.Name = "labelTongSL2";
            this.labelTongSL2.Size = new System.Drawing.Size(211, 26);
            this.labelTongSL2.TabIndex = 29;
            this.labelTongSL2.Text = "Tổng SL (mua-trả):";
            // 
            // labelTongSL2_Cost
            // 
            this.labelTongSL2_Cost.AutoSize = true;
            this.labelTongSL2_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongSL2_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelTongSL2_Cost.Location = new System.Drawing.Point(301, 3);
            this.labelTongSL2_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelTongSL2_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelTongSL2_Cost.Name = "labelTongSL2_Cost";
            this.labelTongSL2_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelTongSL2_Cost.TabIndex = 30;
            this.labelTongSL2_Cost.Text = "0";
            this.labelTongSL2_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelMuaTraCredit
            // 
            this.labelMuaTraCredit.AutoSize = true;
            this.labelMuaTraCredit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMuaTraCredit.ForeColor = System.Drawing.Color.Black;
            this.labelMuaTraCredit.Location = new System.Drawing.Point(7, 43);
            this.labelMuaTraCredit.Name = "labelMuaTraCredit";
            this.labelMuaTraCredit.Size = new System.Drawing.Size(124, 26);
            this.labelMuaTraCredit.TabIndex = 17;
            this.labelMuaTraCredit.Text = "Mua - Trả:";
            // 
            // labelKhachThieuCredit_Cost
            // 
            this.labelKhachThieuCredit_Cost.AutoSize = true;
            this.labelKhachThieuCredit_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachThieuCredit_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelKhachThieuCredit_Cost.Location = new System.Drawing.Point(301, 203);
            this.labelKhachThieuCredit_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelKhachThieuCredit_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelKhachThieuCredit_Cost.Name = "labelKhachThieuCredit_Cost";
            this.labelKhachThieuCredit_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelKhachThieuCredit_Cost.TabIndex = 28;
            this.labelKhachThieuCredit_Cost.Text = "0";
            this.labelKhachThieuCredit_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelMuaTraCredit_Cost
            // 
            this.labelMuaTraCredit_Cost.AutoSize = true;
            this.labelMuaTraCredit_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMuaTraCredit_Cost.ForeColor = System.Drawing.Color.Black;
            this.labelMuaTraCredit_Cost.Location = new System.Drawing.Point(193, 43);
            this.labelMuaTraCredit_Cost.MaximumSize = new System.Drawing.Size(248, 26);
            this.labelMuaTraCredit_Cost.MinimumSize = new System.Drawing.Size(248, 26);
            this.labelMuaTraCredit_Cost.Name = "labelMuaTraCredit_Cost";
            this.labelMuaTraCredit_Cost.Size = new System.Drawing.Size(248, 26);
            this.labelMuaTraCredit_Cost.TabIndex = 24;
            this.labelMuaTraCredit_Cost.Text = "0";
            this.labelMuaTraCredit_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongTienCredit_Cost
            // 
            this.labelTongTienCredit_Cost.AutoSize = true;
            this.labelTongTienCredit_Cost.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienCredit_Cost.ForeColor = System.Drawing.Color.Red;
            this.labelTongTienCredit_Cost.Location = new System.Drawing.Point(301, 123);
            this.labelTongTienCredit_Cost.MaximumSize = new System.Drawing.Size(140, 29);
            this.labelTongTienCredit_Cost.MinimumSize = new System.Drawing.Size(140, 29);
            this.labelTongTienCredit_Cost.Name = "labelTongTienCredit_Cost";
            this.labelTongTienCredit_Cost.Size = new System.Drawing.Size(140, 29);
            this.labelTongTienCredit_Cost.TabIndex = 22;
            this.labelTongTienCredit_Cost.Text = "0";
            this.labelTongTienCredit_Cost.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.labelTongTienCredit_Cost.TextChanged += new System.EventHandler(this.labelTongTienCredit_Cost_TextChanged);
            // 
            // labelKhachThieuCredit
            // 
            this.labelKhachThieuCredit.AutoSize = true;
            this.labelKhachThieuCredit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachThieuCredit.ForeColor = System.Drawing.Color.Black;
            this.labelKhachThieuCredit.Location = new System.Drawing.Point(7, 203);
            this.labelKhachThieuCredit.Name = "labelKhachThieuCredit";
            this.labelKhachThieuCredit.Size = new System.Drawing.Size(138, 26);
            this.labelKhachThieuCredit.TabIndex = 25;
            this.labelKhachThieuCredit.Text = "Khách thiếu";
            // 
            // labelGiamGiaCredit
            // 
            this.labelGiamGiaCredit.AutoSize = true;
            this.labelGiamGiaCredit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelGiamGiaCredit.ForeColor = System.Drawing.Color.Black;
            this.labelGiamGiaCredit.Location = new System.Drawing.Point(7, 83);
            this.labelGiamGiaCredit.Name = "labelGiamGiaCredit";
            this.labelGiamGiaCredit.Size = new System.Drawing.Size(113, 26);
            this.labelGiamGiaCredit.TabIndex = 18;
            this.labelGiamGiaCredit.Text = "Giảm giá:";
            // 
            // textBoxTienChuyenKhoan
            // 
            this.textBoxTienChuyenKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTienChuyenKhoan.Location = new System.Drawing.Point(279, 155);
            this.textBoxTienChuyenKhoan.Name = "textBoxTienChuyenKhoan";
            this.textBoxTienChuyenKhoan.Size = new System.Drawing.Size(155, 34);
            this.textBoxTienChuyenKhoan.TabIndex = 21;
            this.textBoxTienChuyenKhoan.Text = "0";
            this.textBoxTienChuyenKhoan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTienChuyenKhoan.TextChanged += new System.EventHandler(this.textBoxTienChuyenKhoan_TextChanged);
            this.textBoxTienChuyenKhoan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTienChuyenKhoan_KeyPress);
            // 
            // labelTienChuyenKhoan
            // 
            this.labelTienChuyenKhoan.AutoSize = true;
            this.labelTienChuyenKhoan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTienChuyenKhoan.ForeColor = System.Drawing.Color.Black;
            this.labelTienChuyenKhoan.Location = new System.Drawing.Point(7, 163);
            this.labelTienChuyenKhoan.Name = "labelTienChuyenKhoan";
            this.labelTienChuyenKhoan.Size = new System.Drawing.Size(214, 26);
            this.labelTienChuyenKhoan.TabIndex = 20;
            this.labelTienChuyenKhoan.Text = "Tiền chuyển khoản:";
            // 
            // labelTongTienCredit
            // 
            this.labelTongTienCredit.AutoSize = true;
            this.labelTongTienCredit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTienCredit.ForeColor = System.Drawing.Color.Black;
            this.labelTongTienCredit.Location = new System.Drawing.Point(7, 123);
            this.labelTongTienCredit.Name = "labelTongTienCredit";
            this.labelTongTienCredit.Size = new System.Drawing.Size(117, 26);
            this.labelTongTienCredit.TabIndex = 19;
            this.labelTongTienCredit.Text = "Tổng tiền:";
            // 
            // groupBoxThanhToan
            // 
            this.groupBoxThanhToan.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBoxThanhToan.Controls.Add(this.tabControlThanhToan);
            this.groupBoxThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxThanhToan.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBoxThanhToan.Location = new System.Drawing.Point(1073, 434);
            this.groupBoxThanhToan.Name = "groupBoxThanhToan";
            this.groupBoxThanhToan.Size = new System.Drawing.Size(463, 348);
            this.groupBoxThanhToan.TabIndex = 0;
            this.groupBoxThanhToan.TabStop = false;
            this.groupBoxThanhToan.Text = "THANH TOÁN";
            this.groupBoxThanhToan.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBoxThanhToan_Paint);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonX.BackgroundImage")));
            this.buttonX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(1483, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 39);
            this.buttonX.TabIndex = 58;
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonDangXuat_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonDangXuat_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonDangXuat_MouseHover);
            // 
            // panelDuoi
            // 
            this.panelDuoi.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelDuoi.Controls.Add(this.labelThoiGian);
            this.panelDuoi.Controls.Add(this.labelNguoiTaoApp);
            this.panelDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDuoi.Location = new System.Drawing.Point(0, 831);
            this.panelDuoi.Name = "panelDuoi";
            this.panelDuoi.Size = new System.Drawing.Size(1537, 28);
            this.panelDuoi.TabIndex = 96;
            // 
            // labelThoiGian
            // 
            this.labelThoiGian.AutoSize = true;
            this.labelThoiGian.BackColor = System.Drawing.Color.Transparent;
            this.labelThoiGian.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThoiGian.ForeColor = System.Drawing.Color.Black;
            this.labelThoiGian.Location = new System.Drawing.Point(0, 3);
            this.labelThoiGian.Name = "labelThoiGian";
            this.labelThoiGian.Size = new System.Drawing.Size(140, 23);
            this.labelThoiGian.TabIndex = 43;
            this.labelThoiGian.Text = "Ngày làm việc: ";
            // 
            // labelNguoiTaoApp
            // 
            this.labelNguoiTaoApp.AutoSize = true;
            this.labelNguoiTaoApp.BackColor = System.Drawing.Color.Transparent;
            this.labelNguoiTaoApp.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNguoiTaoApp.ForeColor = System.Drawing.Color.Black;
            this.labelNguoiTaoApp.Location = new System.Drawing.Point(1057, 3);
            this.labelNguoiTaoApp.Name = "labelNguoiTaoApp";
            this.labelNguoiTaoApp.Size = new System.Drawing.Size(451, 23);
            this.labelNguoiTaoApp.TabIndex = 42;
            this.labelNguoiTaoApp.Text = "Phát triển bởi nhóm Hiếu Hải Kha. All right reserved";
            // 
            // timerGio
            // 
            this.timerGio.Enabled = true;
            this.timerGio.Interval = 1000;
            this.timerGio.Tick += new System.EventHandler(this.timerGio_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(446, 211);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 97;
            this.pictureBox1.TabStop = false;
            // 
            // formBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1537, 859);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelDuoi);
            this.Controls.Add(this.buttonX);
            this.Controls.Add(this.labelTenSap);
            this.Controls.Add(this.numericUpDownSL);
            this.Controls.Add(this.textBoxTimKiem);
            this.Controls.Add(this.labelSoLuong);
            this.Controls.Add(this.comboBoxDanhMucSanPham);
            this.Controls.Add(this.checkBoxTraHang);
            this.Controls.Add(this.checkBoxMuaHang);
            this.Controls.Add(this.labelDanhMuc);
            this.Controls.Add(this.buttonAn);
            this.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.Controls.Add(this.listViewMuaHang);
            this.Controls.Add(this.labelAnDong);
            this.Controls.Add(this.labelSDT2);
            this.Controls.Add(this.labelSDT1);
            this.Controls.Add(this.labelDiaChi2);
            this.Controls.Add(this.labelDiaChi1);
            this.Controls.Add(this.pictureBoxLogo);
            this.Controls.Add(this.dataGridViewSanPham);
            this.Controls.Add(this.listViewTraHang);
            this.Controls.Add(this.groupBoxThongTinKhachHang);
            this.Controls.Add(this.buttonThanhToan);
            this.Controls.Add(this.groupBoxThanhToan);
            this.Controls.Add(this.menuStripMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStripMenu;
            this.MaximizeBox = false;
            this.Name = "formBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SẠP QUẦN ÁO NỮ SỈ LẺ LỢI DUNG (THIỆN VY)";
            this.menuStripMenu.ResumeLayout(false);
            this.menuStripMenu.PerformLayout();
            this.groupBoxThongTinKhachHang.ResumeLayout(false);
            this.panelThongTinKhachHang.ResumeLayout(false);
            this.panelThongTinKhachHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSL)).EndInit();
            this.tabControlThanhToan.ResumeLayout(false);
            this.tabPageTienMat.ResumeLayout(false);
            this.tabPageTienMat.PerformLayout();
            this.tabPageCreditCard.ResumeLayout(false);
            this.tabPageCreditCard.PerformLayout();
            this.groupBoxThanhToan.ResumeLayout(false);
            this.panelDuoi.ResumeLayout(false);
            this.panelDuoi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripMenu;
        private System.Windows.Forms.ToolStripMenuItem quảnLýSạpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchKháchHàngToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBoxThongTinKhachHang;
        private System.Windows.Forms.ListView listViewMuaHang;
        private System.Windows.Forms.ListView listViewTraHang;
        private System.Windows.Forms.DataGridView dataGridViewSanPham;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Label labelAnDong;
        private System.Windows.Forms.Label labelTenSap;
        private System.Windows.Forms.Label labelSDT2;
        private System.Windows.Forms.Label labelSDT1;
        private System.Windows.Forms.Label labelDiaChi2;
        private System.Windows.Forms.Label labelDiaChi1;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Label labelDanhMuc;
        private System.Windows.Forms.CheckBox checkBoxMuaHang;
        private System.Windows.Forms.Button buttonThanhToan;
        private System.Windows.Forms.ColumnHeader columnHeaderTenSP;
        private System.Windows.Forms.ColumnHeader columnHeaderSoLuong;
        private System.Windows.Forms.ColumnHeader columnHeaderDonGia;
        private System.Windows.Forms.ColumnHeader columnHeaderThanhTien;
        private System.Windows.Forms.CheckBox checkBoxTraHang;
        private System.Windows.Forms.TextBox textBoxTimKiem;
        private System.Windows.Forms.ComboBox comboBoxDanhMucSanPham;
        private System.Windows.Forms.ColumnHeader columnHeaderTenSP_TraHang;
        private System.Windows.Forms.ColumnHeader columnHeaderSoLuong_TraHang;
        private System.Windows.Forms.ColumnHeader columnHeaderDonGia_TraHang;
        private System.Windows.Forms.ColumnHeader columnHeaderThanhTien_TraHang;
        private System.Windows.Forms.NumericUpDown numericUpDownSL;
        private System.Windows.Forms.Label labelSoLuong;
        private System.Windows.Forms.Timer timerTenSap;
        private System.Windows.Forms.TabControl tabControlThanhToan;
        private System.Windows.Forms.TabPage tabPageTienMat;
        private System.Windows.Forms.Label labelTongSL1_Cost;
        private System.Windows.Forms.Label labelTongSL1;
        private System.Windows.Forms.Label labelTienThua;
        private System.Windows.Forms.Label labelKhachThieuTienMat;
        private System.Windows.Forms.Label labelMuaTraTienMat_Cost;
        private System.Windows.Forms.Label labelTongTienMat_Cost;
        private System.Windows.Forms.TextBox textBoxTienMatKhachTra;
        private System.Windows.Forms.Label labelTienMatKhachTra;
        private System.Windows.Forms.Label labelTongTienMat;
        private System.Windows.Forms.Label labelMuaTraTienMat;
        private System.Windows.Forms.Label labelGiamGiaTienMat;
        private System.Windows.Forms.TabPage tabPageCreditCard;
        private System.Windows.Forms.Label labelTongSL2;
        private System.Windows.Forms.Label labelTongSL2_Cost;
        private System.Windows.Forms.Label labelMuaTraCredit;
        private System.Windows.Forms.Label labelKhachThieuCredit_Cost;
        private System.Windows.Forms.Label labelMuaTraCredit_Cost;
        private System.Windows.Forms.Label labelTongTienCredit_Cost;
        private System.Windows.Forms.Label labelKhachThieuCredit;
        private System.Windows.Forms.Label labelGiamGiaCredit;
        private System.Windows.Forms.TextBox textBoxTienChuyenKhoan;
        private System.Windows.Forms.Label labelTienChuyenKhoan;
        private System.Windows.Forms.Label labelTongTienCredit;
        private System.Windows.Forms.GroupBox groupBoxThanhToan;
        private System.Windows.Forms.Label labelTienThua_Cost;
        private System.Windows.Forms.Label labelKhachThieuTienMat_Cost;
        private System.Windows.Forms.TextBox textBoxGiamGiaCredit;
        private System.Windows.Forms.TextBox textBoxGiamGiaTienMat;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDoanhThuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýLươngNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TaiKhoanNVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ThongTinTaiKhoanToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn DanhMuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaBan;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongTon;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Panel panelThongTinKhachHang;
        private System.Windows.Forms.TextBox textBoxTenKhachVangLai;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxKhachHang;
        private System.Windows.Forms.CheckBox checkBoxKhachQuen;
        private System.Windows.Forms.CheckBox checkBoxKhachVangLai;
        private System.Windows.Forms.Label labelTenKhachMoi;
        private System.Windows.Forms.Label labelSDTKhachCu_Text;
        private System.Windows.Forms.Label labelSDT;
        private System.Windows.Forms.Label labelSDTKhachCu;
        private System.Windows.Forms.Label labelDiaChi;
        private System.Windows.Forms.TextBox textBoxSDTKhachVangLai;
        private System.Windows.Forms.TextBox textBoxDiaChiKhachVangLai;
        private System.Windows.Forms.Label labelDiaChiKhachMoi;
        private System.Windows.Forms.Label labelDiaChi_Text;
        private System.Windows.Forms.Panel panelDuoi;
        private System.Windows.Forms.Label labelThoiGian;
        private System.Windows.Forms.Label labelNguoiTaoApp;
        private System.Windows.Forms.Timer timerGio;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}