﻿namespace QUANLYBANQUANAO
{
    partial class formNhapHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formNhapHang));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.panelNhapHang = new System.Windows.Forms.Panel();
            this.comboBoxNhanVienLapPhieu = new System.Windows.Forms.ComboBox();
            this.textBoxTimPhieu = new System.Windows.Forms.TextBox();
            this.labelCheck = new System.Windows.Forms.Label();
            this.buttonTimPhieu = new System.Windows.Forms.Button();
            this.comboBoxNVNhanHang = new System.Windows.Forms.ComboBox();
            this.textBoxMaNCC = new System.Windows.Forms.TextBox();
            this.labelMaNCC = new System.Windows.Forms.Label();
            this.dataGridViewThongTinSPNhap = new System.Windows.Forms.DataGridView();
            this.ColumnTenSP = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ColumnSL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDanhMuc = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ColumnGiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonLuuPhieu = new System.Windows.Forms.Button();
            this.pictureBoxCheckNH = new System.Windows.Forms.PictureBox();
            this.textBoxTongPhieu = new System.Windows.Forms.TextBox();
            this.labelThongTinSPNhap = new System.Windows.Forms.Label();
            this.labelThongTinPhieuNhap = new System.Windows.Forms.Label();
            this.labelNVLapPhieu = new System.Windows.Forms.Label();
            this.textBoxDiaChiNCC = new System.Windows.Forms.TextBox();
            this.textBoxSDTNCC = new System.Windows.Forms.TextBox();
            this.labelTongPhieu = new System.Windows.Forms.Label();
            this.textBoxMaPhieu = new System.Windows.Forms.TextBox();
            this.labelNgayNhap = new System.Windows.Forms.Label();
            this.dateTimePickerNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.buttonThemNCC = new System.Windows.Forms.Button();
            this.comboBoxNCC = new System.Windows.Forms.ComboBox();
            this.labelNVNhanHang = new System.Windows.Forms.Label();
            this.labelDiaChiNCC = new System.Windows.Forms.Label();
            this.labelSDTNCC = new System.Windows.Forms.Label();
            this.labelNCC = new System.Windows.Forms.Label();
            this.labelMaPhieu = new System.Windows.Forms.Label();
            this.buttonNhapHang = new System.Windows.Forms.Button();
            this.buttonDanhSachPhieuNhap = new System.Windows.Forms.Button();
            this.panelDanhSachPhieuNhap = new System.Windows.Forms.Panel();
            this.textBoxTimPhieuNhap_DSPN = new System.Windows.Forms.TextBox();
            this.buttonXoaPhieu = new System.Windows.Forms.Button();
            this.dataGridViewDSPN = new System.Windows.Forms.DataGridView();
            this.ColumnNgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTongPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonXemPhieu = new System.Windows.Forms.Button();
            this.labelTimPhieuNhap = new System.Windows.Forms.Label();
            this.labelDSPN = new System.Windows.Forms.Label();
            this.timerTC = new System.Windows.Forms.Timer(this.components);
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            this.panelNhapHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThongTinSPNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckNH)).BeginInit();
            this.panelDanhSachPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSPN)).BeginInit();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(1038, 35);
            this.panelThanhTieuDe.TabIndex = 16;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(923, 0);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.CornflowerBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(982, 0);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 93;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(128, 23);
            this.labelTieuDeForm.TabIndex = 92;
            this.labelTieuDeForm.Text = "NHẬP HÀNG";
            // 
            // panelNhapHang
            // 
            this.panelNhapHang.Controls.Add(this.comboBoxNhanVienLapPhieu);
            this.panelNhapHang.Controls.Add(this.textBoxTimPhieu);
            this.panelNhapHang.Controls.Add(this.labelCheck);
            this.panelNhapHang.Controls.Add(this.buttonTimPhieu);
            this.panelNhapHang.Controls.Add(this.comboBoxNVNhanHang);
            this.panelNhapHang.Controls.Add(this.textBoxMaNCC);
            this.panelNhapHang.Controls.Add(this.labelMaNCC);
            this.panelNhapHang.Controls.Add(this.dataGridViewThongTinSPNhap);
            this.panelNhapHang.Controls.Add(this.buttonLuuPhieu);
            this.panelNhapHang.Controls.Add(this.pictureBoxCheckNH);
            this.panelNhapHang.Controls.Add(this.textBoxTongPhieu);
            this.panelNhapHang.Controls.Add(this.labelThongTinSPNhap);
            this.panelNhapHang.Controls.Add(this.labelThongTinPhieuNhap);
            this.panelNhapHang.Controls.Add(this.labelNVLapPhieu);
            this.panelNhapHang.Controls.Add(this.textBoxDiaChiNCC);
            this.panelNhapHang.Controls.Add(this.textBoxSDTNCC);
            this.panelNhapHang.Controls.Add(this.labelTongPhieu);
            this.panelNhapHang.Controls.Add(this.textBoxMaPhieu);
            this.panelNhapHang.Controls.Add(this.labelNgayNhap);
            this.panelNhapHang.Controls.Add(this.dateTimePickerNgayNhap);
            this.panelNhapHang.Controls.Add(this.buttonThemNCC);
            this.panelNhapHang.Controls.Add(this.comboBoxNCC);
            this.panelNhapHang.Controls.Add(this.labelNVNhanHang);
            this.panelNhapHang.Controls.Add(this.labelDiaChiNCC);
            this.panelNhapHang.Controls.Add(this.labelSDTNCC);
            this.panelNhapHang.Controls.Add(this.labelNCC);
            this.panelNhapHang.Controls.Add(this.labelMaPhieu);
            this.panelNhapHang.Location = new System.Drawing.Point(140, 36);
            this.panelNhapHang.Name = "panelNhapHang";
            this.panelNhapHang.Size = new System.Drawing.Size(896, 465);
            this.panelNhapHang.TabIndex = 84;
            // 
            // comboBoxNhanVienLapPhieu
            // 
            this.comboBoxNhanVienLapPhieu.BackColor = System.Drawing.SystemColors.HighlightText;
            this.comboBoxNhanVienLapPhieu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNhanVienLapPhieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.comboBoxNhanVienLapPhieu.FormattingEnabled = true;
            this.comboBoxNhanVienLapPhieu.Location = new System.Drawing.Point(515, 174);
            this.comboBoxNhanVienLapPhieu.Name = "comboBoxNhanVienLapPhieu";
            this.comboBoxNhanVienLapPhieu.Size = new System.Drawing.Size(159, 30);
            this.comboBoxNhanVienLapPhieu.TabIndex = 89;
            // 
            // textBoxTimPhieu
            // 
            this.textBoxTimPhieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimPhieu.Location = new System.Drawing.Point(752, 5);
            this.textBoxTimPhieu.Name = "textBoxTimPhieu";
            this.textBoxTimPhieu.Size = new System.Drawing.Size(95, 30);
            this.textBoxTimPhieu.TabIndex = 85;
            this.textBoxTimPhieu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTimPhieu_KeyPress);
            // 
            // labelCheck
            // 
            this.labelCheck.AutoSize = true;
            this.labelCheck.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelCheck.ForeColor = System.Drawing.Color.Red;
            this.labelCheck.Location = new System.Drawing.Point(730, 3);
            this.labelCheck.Name = "labelCheck";
            this.labelCheck.Size = new System.Drawing.Size(24, 26);
            this.labelCheck.TabIndex = 88;
            this.labelCheck.Text = "*";
            this.labelCheck.Visible = false;
            // 
            // buttonTimPhieu
            // 
            this.buttonTimPhieu.BackColor = System.Drawing.Color.AntiqueWhite;
            this.buttonTimPhieu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonTimPhieu.BackgroundImage")));
            this.buttonTimPhieu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonTimPhieu.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonTimPhieu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonTimPhieu.Location = new System.Drawing.Point(844, 4);
            this.buttonTimPhieu.Name = "buttonTimPhieu";
            this.buttonTimPhieu.Size = new System.Drawing.Size(49, 34);
            this.buttonTimPhieu.TabIndex = 86;
            this.buttonTimPhieu.UseVisualStyleBackColor = false;
            this.buttonTimPhieu.Click += new System.EventHandler(this.buttonTimPhieu_Click);
            // 
            // comboBoxNVNhanHang
            // 
            this.comboBoxNVNhanHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNVNhanHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.comboBoxNVNhanHang.FormattingEnabled = true;
            this.comboBoxNVNhanHang.Location = new System.Drawing.Point(177, 174);
            this.comboBoxNVNhanHang.Name = "comboBoxNVNhanHang";
            this.comboBoxNVNhanHang.Size = new System.Drawing.Size(159, 30);
            this.comboBoxNVNhanHang.TabIndex = 84;
            // 
            // textBoxMaNCC
            // 
            this.textBoxMaNCC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBoxMaNCC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMaNCC.Location = new System.Drawing.Point(752, 94);
            this.textBoxMaNCC.Name = "textBoxMaNCC";
            this.textBoxMaNCC.ReadOnly = true;
            this.textBoxMaNCC.Size = new System.Drawing.Size(140, 30);
            this.textBoxMaNCC.TabIndex = 83;
            this.textBoxMaNCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelMaNCC
            // 
            this.labelMaNCC.AutoSize = true;
            this.labelMaNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaNCC.Location = new System.Drawing.Point(616, 98);
            this.labelMaNCC.Name = "labelMaNCC";
            this.labelMaNCC.Size = new System.Drawing.Size(112, 26);
            this.labelMaNCC.TabIndex = 82;
            this.labelMaNCC.Text = "Mã NCC:";
            // 
            // dataGridViewThongTinSPNhap
            // 
            this.dataGridViewThongTinSPNhap.AllowDrop = true;
            this.dataGridViewThongTinSPNhap.AllowUserToResizeColumns = false;
            this.dataGridViewThongTinSPNhap.AllowUserToResizeRows = false;
            this.dataGridViewThongTinSPNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewThongTinSPNhap.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewThongTinSPNhap.ColumnHeadersHeight = 42;
            this.dataGridViewThongTinSPNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewThongTinSPNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTenSP,
            this.ColumnSL,
            this.ColumnDanhMuc,
            this.ColumnGiaNhap});
            this.dataGridViewThongTinSPNhap.Location = new System.Drawing.Point(4, 264);
            this.dataGridViewThongTinSPNhap.MultiSelect = false;
            this.dataGridViewThongTinSPNhap.Name = "dataGridViewThongTinSPNhap";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewThongTinSPNhap.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewThongTinSPNhap.RowHeadersVisible = false;
            this.dataGridViewThongTinSPNhap.RowHeadersWidth = 24;
            this.dataGridViewThongTinSPNhap.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewThongTinSPNhap.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewThongTinSPNhap.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewThongTinSPNhap.RowTemplate.Height = 24;
            this.dataGridViewThongTinSPNhap.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewThongTinSPNhap.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridViewThongTinSPNhap.Size = new System.Drawing.Size(890, 200);
            this.dataGridViewThongTinSPNhap.TabIndex = 77;
            // 
            // ColumnTenSP
            // 
            this.ColumnTenSP.FillWeight = 149.7326F;
            this.ColumnTenSP.HeaderText = "Tên sản phẩm";
            this.ColumnTenSP.MinimumWidth = 6;
            this.ColumnTenSP.Name = "ColumnTenSP";
            this.ColumnTenSP.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnTenSP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // ColumnSL
            // 
            this.ColumnSL.FillWeight = 83.42245F;
            this.ColumnSL.HeaderText = "Số lượng";
            this.ColumnSL.MinimumWidth = 6;
            this.ColumnSL.Name = "ColumnSL";
            this.ColumnSL.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnDanhMuc
            // 
            this.ColumnDanhMuc.FillWeight = 83.42245F;
            this.ColumnDanhMuc.HeaderText = "Danh mục";
            this.ColumnDanhMuc.MinimumWidth = 6;
            this.ColumnDanhMuc.Name = "ColumnDanhMuc";
            this.ColumnDanhMuc.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnDanhMuc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // ColumnGiaNhap
            // 
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = null;
            this.ColumnGiaNhap.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnGiaNhap.FillWeight = 83.42245F;
            this.ColumnGiaNhap.HeaderText = "Giá nhập";
            this.ColumnGiaNhap.MinimumWidth = 6;
            this.ColumnGiaNhap.Name = "ColumnGiaNhap";
            this.ColumnGiaNhap.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // buttonLuuPhieu
            // 
            this.buttonLuuPhieu.BackColor = System.Drawing.Color.Red;
            this.buttonLuuPhieu.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonLuuPhieu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonLuuPhieu.Location = new System.Drawing.Point(752, 172);
            this.buttonLuuPhieu.Name = "buttonLuuPhieu";
            this.buttonLuuPhieu.Size = new System.Drawing.Size(143, 38);
            this.buttonLuuPhieu.TabIndex = 80;
            this.buttonLuuPhieu.Text = "Lưu";
            this.buttonLuuPhieu.UseVisualStyleBackColor = false;
            this.buttonLuuPhieu.Click += new System.EventHandler(this.buttonLuuPhieu_Click);
            // 
            // pictureBoxCheckNH
            // 
            this.pictureBoxCheckNH.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCheckNH.Image")));
            this.pictureBoxCheckNH.Location = new System.Drawing.Point(828, 201);
            this.pictureBoxCheckNH.Name = "pictureBoxCheckNH";
            this.pictureBoxCheckNH.Size = new System.Drawing.Size(81, 73);
            this.pictureBoxCheckNH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCheckNH.TabIndex = 81;
            this.pictureBoxCheckNH.TabStop = false;
            this.pictureBoxCheckNH.Visible = false;
            // 
            // textBoxTongPhieu
            // 
            this.textBoxTongPhieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTongPhieu.Location = new System.Drawing.Point(752, 54);
            this.textBoxTongPhieu.Name = "textBoxTongPhieu";
            this.textBoxTongPhieu.Size = new System.Drawing.Size(140, 30);
            this.textBoxTongPhieu.TabIndex = 71;
            this.textBoxTongPhieu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxTongPhieu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTongPhieu_KeyPress);
            // 
            // labelThongTinSPNhap
            // 
            this.labelThongTinSPNhap.AutoSize = true;
            this.labelThongTinSPNhap.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinSPNhap.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinSPNhap.Location = new System.Drawing.Point(4, 227);
            this.labelThongTinSPNhap.Name = "labelThongTinSPNhap";
            this.labelThongTinSPNhap.Size = new System.Drawing.Size(416, 32);
            this.labelThongTinSPNhap.TabIndex = 79;
            this.labelThongTinSPNhap.Text = "THÔNG TIN SẢN PHẨM NHẬP";
            // 
            // labelThongTinPhieuNhap
            // 
            this.labelThongTinPhieuNhap.AutoSize = true;
            this.labelThongTinPhieuNhap.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThongTinPhieuNhap.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThongTinPhieuNhap.Location = new System.Drawing.Point(4, 3);
            this.labelThongTinPhieuNhap.Name = "labelThongTinPhieuNhap";
            this.labelThongTinPhieuNhap.Size = new System.Drawing.Size(356, 32);
            this.labelThongTinPhieuNhap.TabIndex = 78;
            this.labelThongTinPhieuNhap.Text = "THÔNG TIN PHIẾU NHẬP";
            // 
            // labelNVLapPhieu
            // 
            this.labelNVLapPhieu.AutoSize = true;
            this.labelNVLapPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVLapPhieu.Location = new System.Drawing.Point(354, 178);
            this.labelNVLapPhieu.Name = "labelNVLapPhieu";
            this.labelNVLapPhieu.Size = new System.Drawing.Size(155, 26);
            this.labelNVLapPhieu.TabIndex = 75;
            this.labelNVLapPhieu.Text = "NV lập phiếu:";
            // 
            // textBoxDiaChiNCC
            // 
            this.textBoxDiaChiNCC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBoxDiaChiNCC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxDiaChiNCC.Location = new System.Drawing.Point(177, 134);
            this.textBoxDiaChiNCC.Name = "textBoxDiaChiNCC";
            this.textBoxDiaChiNCC.ReadOnly = true;
            this.textBoxDiaChiNCC.Size = new System.Drawing.Size(396, 30);
            this.textBoxDiaChiNCC.TabIndex = 73;
            // 
            // textBoxSDTNCC
            // 
            this.textBoxSDTNCC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBoxSDTNCC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxSDTNCC.Location = new System.Drawing.Point(752, 134);
            this.textBoxSDTNCC.Name = "textBoxSDTNCC";
            this.textBoxSDTNCC.ReadOnly = true;
            this.textBoxSDTNCC.Size = new System.Drawing.Size(140, 30);
            this.textBoxSDTNCC.TabIndex = 72;
            this.textBoxSDTNCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelTongPhieu
            // 
            this.labelTongPhieu.AutoSize = true;
            this.labelTongPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongPhieu.Location = new System.Drawing.Point(616, 58);
            this.labelTongPhieu.Name = "labelTongPhieu";
            this.labelTongPhieu.Size = new System.Drawing.Size(135, 26);
            this.labelTongPhieu.TabIndex = 70;
            this.labelTongPhieu.Text = "Tổng phiếu:";
            // 
            // textBoxMaPhieu
            // 
            this.textBoxMaPhieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxMaPhieu.Location = new System.Drawing.Point(452, 54);
            this.textBoxMaPhieu.Name = "textBoxMaPhieu";
            this.textBoxMaPhieu.Size = new System.Drawing.Size(121, 30);
            this.textBoxMaPhieu.TabIndex = 64;
            this.textBoxMaPhieu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMaPhieu_KeyPress);
            // 
            // labelNgayNhap
            // 
            this.labelNgayNhap.AutoSize = true;
            this.labelNgayNhap.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgayNhap.Location = new System.Drawing.Point(4, 58);
            this.labelNgayNhap.Name = "labelNgayNhap";
            this.labelNgayNhap.Size = new System.Drawing.Size(73, 26);
            this.labelNgayNhap.TabIndex = 69;
            this.labelNgayNhap.Text = "Ngày:";
            // 
            // dateTimePickerNgayNhap
            // 
            this.dateTimePickerNgayNhap.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerNgayNhap.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerNgayNhap.Location = new System.Drawing.Point(86, 54);
            this.dateTimePickerNgayNhap.Name = "dateTimePickerNgayNhap";
            this.dateTimePickerNgayNhap.Size = new System.Drawing.Size(151, 30);
            this.dateTimePickerNgayNhap.TabIndex = 68;
            // 
            // buttonThemNCC
            // 
            this.buttonThemNCC.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonThemNCC.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonThemNCC.BackgroundImage")));
            this.buttonThemNCC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonThemNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonThemNCC.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonThemNCC.Location = new System.Drawing.Point(530, 92);
            this.buttonThemNCC.Name = "buttonThemNCC";
            this.buttonThemNCC.Size = new System.Drawing.Size(45, 36);
            this.buttonThemNCC.TabIndex = 67;
            this.buttonThemNCC.UseVisualStyleBackColor = false;
            this.buttonThemNCC.Click += new System.EventHandler(this.buttonThemNCC_Click);
            // 
            // comboBoxNCC
            // 
            this.comboBoxNCC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNCC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.comboBoxNCC.FormattingEnabled = true;
            this.comboBoxNCC.Location = new System.Drawing.Point(177, 94);
            this.comboBoxNCC.Name = "comboBoxNCC";
            this.comboBoxNCC.Size = new System.Drawing.Size(350, 30);
            this.comboBoxNCC.TabIndex = 66;
            this.comboBoxNCC.TextChanged += new System.EventHandler(this.comboBoxNCC_TextChanged);
            // 
            // labelNVNhanHang
            // 
            this.labelNVNhanHang.AutoSize = true;
            this.labelNVNhanHang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNVNhanHang.Location = new System.Drawing.Point(4, 178);
            this.labelNVNhanHang.Name = "labelNVNhanHang";
            this.labelNVNhanHang.Size = new System.Drawing.Size(167, 26);
            this.labelNVNhanHang.TabIndex = 62;
            this.labelNVNhanHang.Text = "NV nhận hàng:";
            // 
            // labelDiaChiNCC
            // 
            this.labelDiaChiNCC.AutoSize = true;
            this.labelDiaChiNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiNCC.Location = new System.Drawing.Point(4, 138);
            this.labelDiaChiNCC.Name = "labelDiaChiNCC";
            this.labelDiaChiNCC.Size = new System.Drawing.Size(150, 26);
            this.labelDiaChiNCC.TabIndex = 61;
            this.labelDiaChiNCC.Text = "Địa chỉ NCC:";
            // 
            // labelSDTNCC
            // 
            this.labelSDTNCC.AutoSize = true;
            this.labelSDTNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDTNCC.Location = new System.Drawing.Point(616, 138);
            this.labelSDTNCC.Name = "labelSDTNCC";
            this.labelSDTNCC.Size = new System.Drawing.Size(122, 26);
            this.labelSDTNCC.TabIndex = 60;
            this.labelSDTNCC.Text = "SĐT NCC:";
            // 
            // labelNCC
            // 
            this.labelNCC.AutoSize = true;
            this.labelNCC.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNCC.Location = new System.Drawing.Point(4, 98);
            this.labelNCC.Name = "labelNCC";
            this.labelNCC.Size = new System.Drawing.Size(159, 26);
            this.labelNCC.TabIndex = 59;
            this.labelNCC.Text = "Nhà cung cấp:";
            // 
            // labelMaPhieu
            // 
            this.labelMaPhieu.AutoSize = true;
            this.labelMaPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelMaPhieu.Location = new System.Drawing.Point(334, 58);
            this.labelMaPhieu.Name = "labelMaPhieu";
            this.labelMaPhieu.Size = new System.Drawing.Size(118, 26);
            this.labelMaPhieu.TabIndex = 58;
            this.labelMaPhieu.Text = "Mã phiếu:";
            // 
            // buttonNhapHang
            // 
            this.buttonNhapHang.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonNhapHang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonNhapHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNhapHang.FlatAppearance.BorderSize = 0;
            this.buttonNhapHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNhapHang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonNhapHang.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonNhapHang.Image = ((System.Drawing.Image)(resources.GetObject("buttonNhapHang.Image")));
            this.buttonNhapHang.Location = new System.Drawing.Point(0, 35);
            this.buttonNhapHang.Name = "buttonNhapHang";
            this.buttonNhapHang.Size = new System.Drawing.Size(139, 234);
            this.buttonNhapHang.TabIndex = 74;
            this.buttonNhapHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonNhapHang.UseVisualStyleBackColor = false;
            this.buttonNhapHang.Click += new System.EventHandler(this.buttonNhapHang_Click);
            // 
            // buttonDanhSachPhieuNhap
            // 
            this.buttonDanhSachPhieuNhap.BackColor = System.Drawing.Color.SandyBrown;
            this.buttonDanhSachPhieuNhap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDanhSachPhieuNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDanhSachPhieuNhap.FlatAppearance.BorderSize = 0;
            this.buttonDanhSachPhieuNhap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDanhSachPhieuNhap.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonDanhSachPhieuNhap.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonDanhSachPhieuNhap.Image = ((System.Drawing.Image)(resources.GetObject("buttonDanhSachPhieuNhap.Image")));
            this.buttonDanhSachPhieuNhap.Location = new System.Drawing.Point(0, 268);
            this.buttonDanhSachPhieuNhap.Name = "buttonDanhSachPhieuNhap";
            this.buttonDanhSachPhieuNhap.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.buttonDanhSachPhieuNhap.Size = new System.Drawing.Size(139, 234);
            this.buttonDanhSachPhieuNhap.TabIndex = 85;
            this.buttonDanhSachPhieuNhap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonDanhSachPhieuNhap.UseVisualStyleBackColor = false;
            this.buttonDanhSachPhieuNhap.Click += new System.EventHandler(this.buttonDanhSachPhieuNhap_Click);
            // 
            // panelDanhSachPhieuNhap
            // 
            this.panelDanhSachPhieuNhap.Controls.Add(this.textBoxTimPhieuNhap_DSPN);
            this.panelDanhSachPhieuNhap.Controls.Add(this.buttonXoaPhieu);
            this.panelDanhSachPhieuNhap.Controls.Add(this.dataGridViewDSPN);
            this.panelDanhSachPhieuNhap.Controls.Add(this.buttonXemPhieu);
            this.panelDanhSachPhieuNhap.Controls.Add(this.labelTimPhieuNhap);
            this.panelDanhSachPhieuNhap.Controls.Add(this.labelDSPN);
            this.panelDanhSachPhieuNhap.Location = new System.Drawing.Point(140, 36);
            this.panelDanhSachPhieuNhap.Name = "panelDanhSachPhieuNhap";
            this.panelDanhSachPhieuNhap.Size = new System.Drawing.Size(896, 465);
            this.panelDanhSachPhieuNhap.TabIndex = 82;
            // 
            // textBoxTimPhieuNhap_DSPN
            // 
            this.textBoxTimPhieuNhap_DSPN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBoxTimPhieuNhap_DSPN.Location = new System.Drawing.Point(691, 7);
            this.textBoxTimPhieuNhap_DSPN.Name = "textBoxTimPhieuNhap_DSPN";
            this.textBoxTimPhieuNhap_DSPN.Size = new System.Drawing.Size(200, 30);
            this.textBoxTimPhieuNhap_DSPN.TabIndex = 89;
            this.textBoxTimPhieuNhap_DSPN.TextChanged += new System.EventHandler(this.textBoxTimPhieuNhap_DSPN_TextChanged);
            this.textBoxTimPhieuNhap_DSPN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTimPhieuNhap_DSPN_KeyPress);
            // 
            // buttonXoaPhieu
            // 
            this.buttonXoaPhieu.BackColor = System.Drawing.Color.Red;
            this.buttonXoaPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXoaPhieu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXoaPhieu.Location = new System.Drawing.Point(610, 423);
            this.buttonXoaPhieu.Name = "buttonXoaPhieu";
            this.buttonXoaPhieu.Size = new System.Drawing.Size(141, 39);
            this.buttonXoaPhieu.TabIndex = 94;
            this.buttonXoaPhieu.Text = "Xóa phiếu";
            this.buttonXoaPhieu.UseVisualStyleBackColor = false;
            this.buttonXoaPhieu.Click += new System.EventHandler(this.buttonXoaPhieu_Click);
            // 
            // dataGridViewDSPN
            // 
            this.dataGridViewDSPN.AllowDrop = true;
            this.dataGridViewDSPN.AllowUserToAddRows = false;
            this.dataGridViewDSPN.AllowUserToDeleteRows = false;
            this.dataGridViewDSPN.AllowUserToResizeColumns = false;
            this.dataGridViewDSPN.AllowUserToResizeRows = false;
            this.dataGridViewDSPN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDSPN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewDSPN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSPN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnNgayNhap,
            this.ColumnMaPhieu,
            this.ColumnNCC,
            this.ColumnTongPhieu});
            this.dataGridViewDSPN.Location = new System.Drawing.Point(5, 48);
            this.dataGridViewDSPN.MultiSelect = false;
            this.dataGridViewDSPN.Name = "dataGridViewDSPN";
            this.dataGridViewDSPN.ReadOnly = true;
            this.dataGridViewDSPN.RowHeadersVisible = false;
            this.dataGridViewDSPN.RowHeadersWidth = 51;
            this.dataGridViewDSPN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewDSPN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dataGridViewDSPN.RowTemplate.Height = 24;
            this.dataGridViewDSPN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSPN.Size = new System.Drawing.Size(887, 372);
            this.dataGridViewDSPN.TabIndex = 93;
            this.dataGridViewDSPN.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSPN_CellClick);
            // 
            // ColumnNgayNhap
            // 
            this.ColumnNgayNhap.DataPropertyName = "NgayNhap";
            this.ColumnNgayNhap.FillWeight = 91.90826F;
            this.ColumnNgayNhap.HeaderText = "Ngày nhập";
            this.ColumnNgayNhap.MinimumWidth = 6;
            this.ColumnNgayNhap.Name = "ColumnNgayNhap";
            this.ColumnNgayNhap.ReadOnly = true;
            this.ColumnNgayNhap.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnMaPhieu
            // 
            this.ColumnMaPhieu.DataPropertyName = "MaPhieu";
            this.ColumnMaPhieu.FillWeight = 70.58823F;
            this.ColumnMaPhieu.HeaderText = "Mã phiếu";
            this.ColumnMaPhieu.MinimumWidth = 6;
            this.ColumnMaPhieu.Name = "ColumnMaPhieu";
            this.ColumnMaPhieu.ReadOnly = true;
            this.ColumnMaPhieu.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnNCC
            // 
            this.ColumnNCC.DataPropertyName = "NCC";
            this.ColumnNCC.FillWeight = 137.8624F;
            this.ColumnNCC.HeaderText = "NCC";
            this.ColumnNCC.MinimumWidth = 6;
            this.ColumnNCC.Name = "ColumnNCC";
            this.ColumnNCC.ReadOnly = true;
            this.ColumnNCC.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // ColumnTongPhieu
            // 
            this.ColumnTongPhieu.DataPropertyName = "TongPhieu";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle6.Format = "C0";
            dataGridViewCellStyle6.NullValue = null;
            this.ColumnTongPhieu.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnTongPhieu.FillWeight = 99.64111F;
            this.ColumnTongPhieu.HeaderText = "Tổng phiếu";
            this.ColumnTongPhieu.MinimumWidth = 6;
            this.ColumnTongPhieu.Name = "ColumnTongPhieu";
            this.ColumnTongPhieu.ReadOnly = true;
            this.ColumnTongPhieu.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // buttonXemPhieu
            // 
            this.buttonXemPhieu.BackColor = System.Drawing.Color.Red;
            this.buttonXemPhieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonXemPhieu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonXemPhieu.Location = new System.Drawing.Point(753, 423);
            this.buttonXemPhieu.Name = "buttonXemPhieu";
            this.buttonXemPhieu.Size = new System.Drawing.Size(141, 39);
            this.buttonXemPhieu.TabIndex = 91;
            this.buttonXemPhieu.Text = "Xem phiếu";
            this.buttonXemPhieu.UseVisualStyleBackColor = false;
            this.buttonXemPhieu.Click += new System.EventHandler(this.buttonXemPhieu_Click);
            // 
            // labelTimPhieuNhap
            // 
            this.labelTimPhieuNhap.AutoSize = true;
            this.labelTimPhieuNhap.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTimPhieuNhap.Location = new System.Drawing.Point(631, 11);
            this.labelTimPhieuNhap.Name = "labelTimPhieuNhap";
            this.labelTimPhieuNhap.Size = new System.Drawing.Size(61, 26);
            this.labelTimPhieuNhap.TabIndex = 87;
            this.labelTimPhieuNhap.Text = "Tìm:";
            // 
            // labelDSPN
            // 
            this.labelDSPN.AutoSize = true;
            this.labelDSPN.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDSPN.ForeColor = System.Drawing.Color.DarkRed;
            this.labelDSPN.Location = new System.Drawing.Point(4, 6);
            this.labelDSPN.Name = "labelDSPN";
            this.labelDSPN.Size = new System.Drawing.Size(365, 32);
            this.labelDSPN.TabIndex = 87;
            this.labelDSPN.Text = "DANH SÁCH PHIẾU NHẬP";
            // 
            // timerTC
            // 
            this.timerTC.Interval = 1000;
            this.timerTC.Tick += new System.EventHandler(this.timerTC_Tick);
            // 
            // formNhapHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1038, 501);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.buttonDanhSachPhieuNhap);
            this.Controls.Add(this.buttonNhapHang);
            this.Controls.Add(this.panelNhapHang);
            this.Controls.Add(this.panelDanhSachPhieuNhap);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formNhapHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formNhapHang";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            this.panelNhapHang.ResumeLayout(false);
            this.panelNhapHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewThongTinSPNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCheckNH)).EndInit();
            this.panelDanhSachPhieuNhap.ResumeLayout(false);
            this.panelDanhSachPhieuNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSPN)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.Panel panelNhapHang;
        private System.Windows.Forms.Button buttonNhapHang;
        private System.Windows.Forms.Button buttonDanhSachPhieuNhap;
        private System.Windows.Forms.Panel panelDanhSachPhieuNhap;
        private System.Windows.Forms.Timer timerTC;
        private System.Windows.Forms.TextBox textBoxTimPhieu;
        private System.Windows.Forms.Label labelCheck;
        private System.Windows.Forms.Button buttonTimPhieu;
        private System.Windows.Forms.ComboBox comboBoxNVNhanHang;
        private System.Windows.Forms.TextBox textBoxMaNCC;
        private System.Windows.Forms.Label labelMaNCC;
        private System.Windows.Forms.DataGridView dataGridViewThongTinSPNhap;
        private System.Windows.Forms.Button buttonLuuPhieu;
        private System.Windows.Forms.PictureBox pictureBoxCheckNH;
        private System.Windows.Forms.TextBox textBoxTongPhieu;
        private System.Windows.Forms.Label labelThongTinSPNhap;
        private System.Windows.Forms.Label labelThongTinPhieuNhap;
        private System.Windows.Forms.Label labelNVLapPhieu;
        private System.Windows.Forms.TextBox textBoxDiaChiNCC;
        private System.Windows.Forms.TextBox textBoxSDTNCC;
        private System.Windows.Forms.Label labelTongPhieu;
        private System.Windows.Forms.TextBox textBoxMaPhieu;
        private System.Windows.Forms.Label labelNgayNhap;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayNhap;
        private System.Windows.Forms.Button buttonThemNCC;
        private System.Windows.Forms.ComboBox comboBoxNCC;
        private System.Windows.Forms.Label labelNVNhanHang;
        private System.Windows.Forms.Label labelDiaChiNCC;
        private System.Windows.Forms.Label labelSDTNCC;
        private System.Windows.Forms.Label labelNCC;
        private System.Windows.Forms.Label labelMaPhieu;
        private System.Windows.Forms.TextBox textBoxTimPhieuNhap_DSPN;
        private System.Windows.Forms.Label labelDSPN;
        private System.Windows.Forms.Label labelTimPhieuNhap;
        private System.Windows.Forms.Button buttonXemPhieu;
        private System.Windows.Forms.DataGridView dataGridViewDSPN;
        private System.Windows.Forms.Button buttonXoaPhieu;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNgayNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMaPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTongPhieu;
        private System.Windows.Forms.DataGridViewComboBoxColumn ColumnTenSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSL;
        private System.Windows.Forms.DataGridViewComboBoxColumn ColumnDanhMuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGiaNhap;
        private System.Windows.Forms.ComboBox comboBoxNhanVienLapPhieu;
    }
}