﻿namespace QUANLYBANQUANAO
{
    partial class formXacNhanToa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formXacNhanToa));
            this.panelThanhTieuDe = new System.Windows.Forms.Panel();
            this.labelTieuDeForm = new System.Windows.Forms.Label();
            this.pictureBoxIconThanhTieuDe = new System.Windows.Forms.PictureBox();
            this.buttonAn = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.labelAnDong = new System.Windows.Forms.Label();
            this.labelSDT1 = new System.Windows.Forms.Label();
            this.labelDiaChi = new System.Windows.Forms.Label();
            this.labelTenSap = new System.Windows.Forms.Label();
            this.labelSDT2 = new System.Windows.Forms.Label();
            this.labelSTK = new System.Windows.Forms.Label();
            this.labelDiaChiNH1 = new System.Windows.Forms.Label();
            this.labelDiaChiNH2 = new System.Windows.Forms.Label();
            this.labelChuSap = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonKetToa = new System.Windows.Forms.Button();
            this.listViewTraHang = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelTongMua = new System.Windows.Forms.Label();
            this.labelTongTra = new System.Windows.Forms.Label();
            this.labelTongMua_Text = new System.Windows.Forms.Label();
            this.labelTongTra_Text = new System.Windows.Forms.Label();
            this.labelKhachNo_Text = new System.Windows.Forms.Label();
            this.labelThanhToan_Text = new System.Windows.Forms.Label();
            this.labelSLSanPham_Text = new System.Windows.Forms.Label();
            this.labelNhanVienLapToa_Text = new System.Windows.Forms.Label();
            this.labelTongToaHang_Text = new System.Windows.Forms.Label();
            this.labelThanhToan = new System.Windows.Forms.Label();
            this.labelNhanVienLapToa = new System.Windows.Forms.Label();
            this.labelSLSanPham = new System.Windows.Forms.Label();
            this.labelTongToaHang = new System.Windows.Forms.Label();
            this.labelKhachNo = new System.Windows.Forms.Label();
            this.labelTenKhach_Text = new System.Windows.Forms.Label();
            this.labelTenKhach = new System.Windows.Forms.Label();
            this.labelSDT = new System.Windows.Forms.Label();
            this.labelSDT_Text = new System.Windows.Forms.Label();
            this.dataGridViewMua = new System.Windows.Forms.DataGridView();
            this.ColumnTenSP_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSL_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDonGia_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTT_Mua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTra = new System.Windows.Forms.DataGridView();
            this.ColumnTenSP_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSL_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DG_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TT_Tra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelNgay_Text = new System.Windows.Forms.Label();
            this.labelNgay = new System.Windows.Forms.Label();
            this.buttonIn = new System.Windows.Forms.Button();
            this.buttonLuuToa = new System.Windows.Forms.Button();
            this.columnHeaderTenSP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderThanhTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewMuaHang = new System.Windows.Forms.ListView();
            this.panelTrai = new System.Windows.Forms.Panel();
            this.panelPhai = new System.Windows.Forms.Panel();
            this.panelDuoi = new System.Windows.Forms.Panel();
            this.panelThanhTieuDe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTra)).BeginInit();
            this.SuspendLayout();
            // 
            // panelThanhTieuDe
            // 
            this.panelThanhTieuDe.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelThanhTieuDe.Controls.Add(this.labelTieuDeForm);
            this.panelThanhTieuDe.Controls.Add(this.pictureBoxIconThanhTieuDe);
            this.panelThanhTieuDe.Controls.Add(this.buttonAn);
            this.panelThanhTieuDe.Controls.Add(this.buttonX);
            this.panelThanhTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThanhTieuDe.Location = new System.Drawing.Point(0, 0);
            this.panelThanhTieuDe.MinimumSize = new System.Drawing.Size(535, 35);
            this.panelThanhTieuDe.Name = "panelThanhTieuDe";
            this.panelThanhTieuDe.Size = new System.Drawing.Size(620, 35);
            this.panelThanhTieuDe.TabIndex = 16;
            this.panelThanhTieuDe.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseDown);
            this.panelThanhTieuDe.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseMove);
            this.panelThanhTieuDe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panelThanhTieuDe_MouseUp);
            // 
            // labelTieuDeForm
            // 
            this.labelTieuDeForm.AutoSize = true;
            this.labelTieuDeForm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTieuDeForm.Location = new System.Drawing.Point(44, 6);
            this.labelTieuDeForm.Name = "labelTieuDeForm";
            this.labelTieuDeForm.Size = new System.Drawing.Size(251, 23);
            this.labelTieuDeForm.TabIndex = 91;
            this.labelTieuDeForm.Text = "XÁC NHẬN THANH TOÁN";
            // 
            // pictureBoxIconThanhTieuDe
            // 
            this.pictureBoxIconThanhTieuDe.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxIconThanhTieuDe.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxIconThanhTieuDe.Image")));
            this.pictureBoxIconThanhTieuDe.Location = new System.Drawing.Point(9, 3);
            this.pictureBoxIconThanhTieuDe.Name = "pictureBoxIconThanhTieuDe";
            this.pictureBoxIconThanhTieuDe.Size = new System.Drawing.Size(29, 29);
            this.pictureBoxIconThanhTieuDe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxIconThanhTieuDe.TabIndex = 50;
            this.pictureBoxIconThanhTieuDe.TabStop = false;
            // 
            // buttonAn
            // 
            this.buttonAn.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonAn.FlatAppearance.BorderSize = 0;
            this.buttonAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonAn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonAn.Location = new System.Drawing.Point(512, 1);
            this.buttonAn.Name = "buttonAn";
            this.buttonAn.Size = new System.Drawing.Size(55, 33);
            this.buttonAn.TabIndex = 49;
            this.buttonAn.Text = "___";
            this.buttonAn.UseVisualStyleBackColor = false;
            this.buttonAn.Click += new System.EventHandler(this.buttonAn_Click);
            this.buttonAn.MouseLeave += new System.EventHandler(this.buttonAn_MouseLeave);
            this.buttonAn.MouseHover += new System.EventHandler(this.buttonAn_MouseHover);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonX.FlatAppearance.BorderSize = 0;
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonX.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonX.Location = new System.Drawing.Point(566, 1);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(55, 34);
            this.buttonX.TabIndex = 48;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            this.buttonX.MouseLeave += new System.EventHandler(this.buttonX_MouseLeave);
            this.buttonX.MouseHover += new System.EventHandler(this.buttonX_MouseHover);
            // 
            // labelAnDong
            // 
            this.labelAnDong.AutoSize = true;
            this.labelAnDong.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelAnDong.Location = new System.Drawing.Point(82, 38);
            this.labelAnDong.Name = "labelAnDong";
            this.labelAnDong.Size = new System.Drawing.Size(455, 23);
            this.labelAnDong.TabIndex = 46;
            this.labelAnDong.Text = "TRUNG TÂM THƯƠNG MẠI DỊCH VỤ AN ĐÔNG";
            // 
            // labelSDT1
            // 
            this.labelSDT1.AutoSize = true;
            this.labelSDT1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT1.Location = new System.Drawing.Point(7, 133);
            this.labelSDT1.Name = "labelSDT1";
            this.labelSDT1.Size = new System.Drawing.Size(211, 22);
            this.labelSDT1.TabIndex = 49;
            this.labelSDT1.Text = "ĐT:  0903.972.674 (Mai)";
            // 
            // labelDiaChi
            // 
            this.labelDiaChi.AutoSize = true;
            this.labelDiaChi.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChi.Location = new System.Drawing.Point(7, 111);
            this.labelDiaChi.Name = "labelDiaChi";
            this.labelDiaChi.Size = new System.Drawing.Size(252, 22);
            this.labelDiaChi.TabIndex = 47;
            this.labelDiaChi.Text = "Sạp: C65-66 và C54-55 Lầu 1";
            // 
            // labelTenSap
            // 
            this.labelTenSap.AutoSize = true;
            this.labelTenSap.Font = new System.Drawing.Font("Modern No. 20", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenSap.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTenSap.Location = new System.Drawing.Point(107, 66);
            this.labelTenSap.Name = "labelTenSap";
            this.labelTenSap.Size = new System.Drawing.Size(401, 36);
            this.labelTenSap.TabIndex = 45;
            this.labelTenSap.Text = "LỢI DUNG (THIỆN VY)";
            // 
            // labelSDT2
            // 
            this.labelSDT2.AutoSize = true;
            this.labelSDT2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT2.Location = new System.Drawing.Point(51, 155);
            this.labelSDT2.Name = "labelSDT2";
            this.labelSDT2.Size = new System.Drawing.Size(170, 22);
            this.labelSDT2.TabIndex = 50;
            this.labelSDT2.Text = "0906.363.120 (Mai)";
            // 
            // labelSTK
            // 
            this.labelSTK.AutoSize = true;
            this.labelSTK.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSTK.Location = new System.Drawing.Point(403, 111);
            this.labelSTK.Name = "labelSTK";
            this.labelSTK.Size = new System.Drawing.Size(178, 22);
            this.labelSTK.TabIndex = 54;
            this.labelSTK.Text = "STK: 060072745445";
            // 
            // labelDiaChiNH1
            // 
            this.labelDiaChiNH1.AutoSize = true;
            this.labelDiaChiNH1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiNH1.Location = new System.Drawing.Point(376, 133);
            this.labelDiaChiNH1.Name = "labelDiaChiNH1";
            this.labelDiaChiNH1.Size = new System.Drawing.Size(232, 22);
            this.labelDiaChiNH1.TabIndex = 55;
            this.labelDiaChiNH1.Text = "NH.Sacombank Chi Nhánh";
            // 
            // labelDiaChiNH2
            // 
            this.labelDiaChiNH2.AutoSize = true;
            this.labelDiaChiNH2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelDiaChiNH2.Location = new System.Drawing.Point(413, 155);
            this.labelDiaChiNH2.Name = "labelDiaChiNH2";
            this.labelDiaChiNH2.Size = new System.Drawing.Size(162, 22);
            this.labelDiaChiNH2.TabIndex = 56;
            this.labelDiaChiNH2.Text = "Bình Đăng Quận 8";
            // 
            // labelChuSap
            // 
            this.labelChuSap.AutoSize = true;
            this.labelChuSap.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelChuSap.Location = new System.Drawing.Point(395, 178);
            this.labelChuSap.Name = "labelChuSap";
            this.labelChuSap.Size = new System.Drawing.Size(190, 22);
            this.labelChuSap.TabIndex = 57;
            this.labelChuSap.Text = "TỪ THỊ TUYẾT MAI";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(6, 346);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 25);
            this.label1.TabIndex = 58;
            this.label1.Text = "MUA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(6, 616);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 25);
            this.label6.TabIndex = 59;
            this.label6.Text = "TRẢ";
            // 
            // buttonKetToa
            // 
            this.buttonKetToa.BackColor = System.Drawing.Color.Red;
            this.buttonKetToa.Enabled = false;
            this.buttonKetToa.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonKetToa.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonKetToa.Location = new System.Drawing.Point(470, 834);
            this.buttonKetToa.Name = "buttonKetToa";
            this.buttonKetToa.Size = new System.Drawing.Size(143, 41);
            this.buttonKetToa.TabIndex = 60;
            this.buttonKetToa.Text = "Kết toa";
            this.buttonKetToa.UseVisualStyleBackColor = false;
            this.buttonKetToa.Click += new System.EventHandler(this.buttonKetToa_Click);
            // 
            // listViewTraHang
            // 
            this.listViewTraHang.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewTraHang.BackColor = System.Drawing.Color.Chocolate;
            this.listViewTraHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewTraHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewTraHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewTraHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewTraHang.HideSelection = false;
            this.listViewTraHang.HoverSelection = true;
            this.listViewTraHang.Location = new System.Drawing.Point(11, 644);
            this.listViewTraHang.MultiSelect = false;
            this.listViewTraHang.Name = "listViewTraHang";
            this.listViewTraHang.Size = new System.Drawing.Size(599, 188);
            this.listViewTraHang.TabIndex = 62;
            this.listViewTraHang.UseCompatibleStateImageBehavior = false;
            this.listViewTraHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Tên sản phẩm";
            this.columnHeader1.Width = 199;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "SL";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 50;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Đơn giá";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Thành tiền";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 100;
            // 
            // labelTongMua
            // 
            this.labelTongMua.AutoSize = true;
            this.labelTongMua.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongMua.ForeColor = System.Drawing.Color.Black;
            this.labelTongMua.Location = new System.Drawing.Point(332, 348);
            this.labelTongMua.Name = "labelTongMua";
            this.labelTongMua.Size = new System.Drawing.Size(115, 25);
            this.labelTongMua.TabIndex = 63;
            this.labelTongMua.Text = "Tổng mua:";
            // 
            // labelTongTra
            // 
            this.labelTongTra.AutoSize = true;
            this.labelTongTra.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTra.ForeColor = System.Drawing.Color.Black;
            this.labelTongTra.Location = new System.Drawing.Point(332, 616);
            this.labelTongTra.Name = "labelTongTra";
            this.labelTongTra.Size = new System.Drawing.Size(101, 25);
            this.labelTongTra.TabIndex = 64;
            this.labelTongTra.Text = "Tổng trả:";
            // 
            // labelTongMua_Text
            // 
            this.labelTongMua_Text.AutoSize = true;
            this.labelTongMua_Text.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongMua_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongMua_Text.Location = new System.Drawing.Point(453, 350);
            this.labelTongMua_Text.MaximumSize = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.MinimumSize = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.Name = "labelTongMua_Text";
            this.labelTongMua_Text.Size = new System.Drawing.Size(157, 23);
            this.labelTongMua_Text.TabIndex = 65;
            this.labelTongMua_Text.Text = "1000000000 VND";
            this.labelTongMua_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelTongTra_Text
            // 
            this.labelTongTra_Text.AutoSize = true;
            this.labelTongTra_Text.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongTra_Text.ForeColor = System.Drawing.Color.Black;
            this.labelTongTra_Text.Location = new System.Drawing.Point(453, 618);
            this.labelTongTra_Text.MaximumSize = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.MinimumSize = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.Name = "labelTongTra_Text";
            this.labelTongTra_Text.Size = new System.Drawing.Size(157, 23);
            this.labelTongTra_Text.TabIndex = 66;
            this.labelTongTra_Text.Text = "1000000000 VND";
            this.labelTongTra_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelKhachNo_Text
            // 
            this.labelKhachNo_Text.AutoSize = true;
            this.labelKhachNo_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo_Text.Location = new System.Drawing.Point(131, 308);
            this.labelKhachNo_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelKhachNo_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelKhachNo_Text.Name = "labelKhachNo_Text";
            this.labelKhachNo_Text.Size = new System.Drawing.Size(138, 25);
            this.labelKhachNo_Text.TabIndex = 86;
            this.labelKhachNo_Text.Text = "1000000000 ";
            // 
            // labelThanhToan_Text
            // 
            this.labelThanhToan_Text.AutoSize = true;
            this.labelThanhToan_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThanhToan_Text.Location = new System.Drawing.Point(476, 308);
            this.labelThanhToan_Text.MaximumSize = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.MinimumSize = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.Name = "labelThanhToan_Text";
            this.labelThanhToan_Text.Size = new System.Drawing.Size(134, 25);
            this.labelThanhToan_Text.TabIndex = 85;
            this.labelThanhToan_Text.Text = "Credit Card";
            this.labelThanhToan_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelSLSanPham_Text
            // 
            this.labelSLSanPham_Text.AutoSize = true;
            this.labelSLSanPham_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSanPham_Text.Location = new System.Drawing.Point(473, 273);
            this.labelSLSanPham_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelSLSanPham_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelSLSanPham_Text.Name = "labelSLSanPham_Text";
            this.labelSLSanPham_Text.Size = new System.Drawing.Size(138, 25);
            this.labelSLSanPham_Text.TabIndex = 84;
            this.labelSLSanPham_Text.Text = "100000 ";
            this.labelSLSanPham_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNhanVienLapToa_Text
            // 
            this.labelNhanVienLapToa_Text.AutoSize = true;
            this.labelNhanVienLapToa_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienLapToa_Text.Location = new System.Drawing.Point(167, 203);
            this.labelNhanVienLapToa_Text.Name = "labelNhanVienLapToa_Text";
            this.labelNhanVienLapToa_Text.Size = new System.Drawing.Size(127, 25);
            this.labelNhanVienLapToa_Text.TabIndex = 82;
            this.labelNhanVienLapToa_Text.Text = "tên nhân viên";
            // 
            // labelTongToaHang_Text
            // 
            this.labelTongToaHang_Text.AutoSize = true;
            this.labelTongToaHang_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaHang_Text.Location = new System.Drawing.Point(178, 273);
            this.labelTongToaHang_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelTongToaHang_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelTongToaHang_Text.Name = "labelTongToaHang_Text";
            this.labelTongToaHang_Text.Size = new System.Drawing.Size(138, 25);
            this.labelTongToaHang_Text.TabIndex = 83;
            this.labelTongToaHang_Text.Text = "1000000000 ";
            // 
            // labelThanhToan
            // 
            this.labelThanhToan.AutoSize = true;
            this.labelThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelThanhToan.ForeColor = System.Drawing.Color.DarkRed;
            this.labelThanhToan.Location = new System.Drawing.Point(339, 308);
            this.labelThanhToan.Name = "labelThanhToan";
            this.labelThanhToan.Size = new System.Drawing.Size(128, 25);
            this.labelThanhToan.TabIndex = 81;
            this.labelThanhToan.Text = "Thanh toán:";
            // 
            // labelNhanVienLapToa
            // 
            this.labelNhanVienLapToa.AutoSize = true;
            this.labelNhanVienLapToa.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNhanVienLapToa.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNhanVienLapToa.Location = new System.Drawing.Point(6, 203);
            this.labelNhanVienLapToa.Name = "labelNhanVienLapToa";
            this.labelNhanVienLapToa.Size = new System.Drawing.Size(157, 25);
            this.labelNhanVienLapToa.TabIndex = 79;
            this.labelNhanVienLapToa.Text = "Nhân viên lập: ";
            // 
            // labelSLSanPham
            // 
            this.labelSLSanPham.AutoSize = true;
            this.labelSLSanPham.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSLSanPham.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSLSanPham.Location = new System.Drawing.Point(339, 273);
            this.labelSLSanPham.Name = "labelSLSanPham";
            this.labelSLSanPham.Size = new System.Drawing.Size(152, 25);
            this.labelSLSanPham.TabIndex = 78;
            this.labelSLSanPham.Text = "SL (mua - trả):";
            // 
            // labelTongToaHang
            // 
            this.labelTongToaHang.AutoSize = true;
            this.labelTongToaHang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTongToaHang.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTongToaHang.Location = new System.Drawing.Point(6, 273);
            this.labelTongToaHang.Name = "labelTongToaHang";
            this.labelTongToaHang.Size = new System.Drawing.Size(155, 25);
            this.labelTongToaHang.TabIndex = 77;
            this.labelTongToaHang.Text = "Tổng toa hàng:";
            // 
            // labelKhachNo
            // 
            this.labelKhachNo.AutoSize = true;
            this.labelKhachNo.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelKhachNo.ForeColor = System.Drawing.Color.DarkRed;
            this.labelKhachNo.Location = new System.Drawing.Point(6, 308);
            this.labelKhachNo.Name = "labelKhachNo";
            this.labelKhachNo.Size = new System.Drawing.Size(112, 25);
            this.labelKhachNo.TabIndex = 80;
            this.labelKhachNo.Text = "Khách nợ:";
            // 
            // labelTenKhach_Text
            // 
            this.labelTenKhach_Text.AutoSize = true;
            this.labelTenKhach_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhach_Text.Location = new System.Drawing.Point(137, 238);
            this.labelTenKhach_Text.MaximumSize = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.MinimumSize = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.Name = "labelTenKhach_Text";
            this.labelTenKhach_Text.Size = new System.Drawing.Size(180, 25);
            this.labelTenKhach_Text.TabIndex = 88;
            this.labelTenKhach_Text.Text = "đinh trung hiếu";
            // 
            // labelTenKhach
            // 
            this.labelTenKhach.AutoSize = true;
            this.labelTenKhach.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelTenKhach.ForeColor = System.Drawing.Color.DarkRed;
            this.labelTenKhach.Location = new System.Drawing.Point(6, 238);
            this.labelTenKhach.Name = "labelTenKhach";
            this.labelTenKhach.Size = new System.Drawing.Size(119, 25);
            this.labelTenKhach.TabIndex = 87;
            this.labelTenKhach.Text = "Tên khách:";
            // 
            // labelSDT
            // 
            this.labelSDT.AutoSize = true;
            this.labelSDT.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSDT.Location = new System.Drawing.Point(339, 238);
            this.labelSDT.Name = "labelSDT";
            this.labelSDT.Size = new System.Drawing.Size(60, 25);
            this.labelSDT.TabIndex = 89;
            this.labelSDT.Text = "SĐT:";
            // 
            // labelSDT_Text
            // 
            this.labelSDT_Text.AutoSize = true;
            this.labelSDT_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelSDT_Text.Location = new System.Drawing.Point(472, 238);
            this.labelSDT_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.Name = "labelSDT_Text";
            this.labelSDT_Text.Size = new System.Drawing.Size(138, 25);
            this.labelSDT_Text.TabIndex = 90;
            this.labelSDT_Text.Text = "1234567891";
            this.labelSDT_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dataGridViewMua
            // 
            this.dataGridViewMua.AllowDrop = true;
            this.dataGridViewMua.AllowUserToAddRows = false;
            this.dataGridViewMua.AllowUserToDeleteRows = false;
            this.dataGridViewMua.AllowUserToResizeColumns = false;
            this.dataGridViewMua.AllowUserToResizeRows = false;
            this.dataGridViewMua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMua.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTenSP_Mua,
            this.ColumnSL_Mua,
            this.ColumnDonGia_Mua,
            this.ColumnTT_Mua});
            this.dataGridViewMua.Location = new System.Drawing.Point(130, 442);
            this.dataGridViewMua.Name = "dataGridViewMua";
            this.dataGridViewMua.RowHeadersVisible = false;
            this.dataGridViewMua.RowHeadersWidth = 51;
            this.dataGridViewMua.RowTemplate.Height = 24;
            this.dataGridViewMua.Size = new System.Drawing.Size(322, 150);
            this.dataGridViewMua.TabIndex = 91;
            this.dataGridViewMua.Visible = false;
            // 
            // ColumnTenSP_Mua
            // 
            this.ColumnTenSP_Mua.HeaderText = "Tên sản phẩm";
            this.ColumnTenSP_Mua.MinimumWidth = 6;
            this.ColumnTenSP_Mua.Name = "ColumnTenSP_Mua";
            this.ColumnTenSP_Mua.Width = 125;
            // 
            // ColumnSL_Mua
            // 
            this.ColumnSL_Mua.HeaderText = "Số lượng";
            this.ColumnSL_Mua.MinimumWidth = 6;
            this.ColumnSL_Mua.Name = "ColumnSL_Mua";
            this.ColumnSL_Mua.Width = 125;
            // 
            // ColumnDonGia_Mua
            // 
            this.ColumnDonGia_Mua.HeaderText = "Đơn giá";
            this.ColumnDonGia_Mua.MinimumWidth = 6;
            this.ColumnDonGia_Mua.Name = "ColumnDonGia_Mua";
            this.ColumnDonGia_Mua.Width = 125;
            // 
            // ColumnTT_Mua
            // 
            this.ColumnTT_Mua.HeaderText = "Thành tiền";
            this.ColumnTT_Mua.MinimumWidth = 6;
            this.ColumnTT_Mua.Name = "ColumnTT_Mua";
            this.ColumnTT_Mua.Width = 125;
            // 
            // dataGridViewTra
            // 
            this.dataGridViewTra.AllowDrop = true;
            this.dataGridViewTra.AllowUserToAddRows = false;
            this.dataGridViewTra.AllowUserToDeleteRows = false;
            this.dataGridViewTra.AllowUserToResizeColumns = false;
            this.dataGridViewTra.AllowUserToResizeRows = false;
            this.dataGridViewTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTenSP_Tra,
            this.ColumnSL_Tra,
            this.DG_Tra,
            this.TT_Tra});
            this.dataGridViewTra.Location = new System.Drawing.Point(113, 692);
            this.dataGridViewTra.Name = "dataGridViewTra";
            this.dataGridViewTra.RowHeadersVisible = false;
            this.dataGridViewTra.RowHeadersWidth = 51;
            this.dataGridViewTra.RowTemplate.Height = 24;
            this.dataGridViewTra.Size = new System.Drawing.Size(294, 120);
            this.dataGridViewTra.TabIndex = 92;
            this.dataGridViewTra.Visible = false;
            // 
            // ColumnTenSP_Tra
            // 
            this.ColumnTenSP_Tra.HeaderText = "Tên sản phẩm";
            this.ColumnTenSP_Tra.MinimumWidth = 6;
            this.ColumnTenSP_Tra.Name = "ColumnTenSP_Tra";
            this.ColumnTenSP_Tra.Width = 125;
            // 
            // ColumnSL_Tra
            // 
            this.ColumnSL_Tra.HeaderText = "Số lượng";
            this.ColumnSL_Tra.MinimumWidth = 6;
            this.ColumnSL_Tra.Name = "ColumnSL_Tra";
            this.ColumnSL_Tra.Width = 125;
            // 
            // DG_Tra
            // 
            this.DG_Tra.HeaderText = "Đơn giá";
            this.DG_Tra.MinimumWidth = 6;
            this.DG_Tra.Name = "DG_Tra";
            this.DG_Tra.Width = 125;
            // 
            // TT_Tra
            // 
            this.TT_Tra.HeaderText = "Thành tiền";
            this.TT_Tra.MinimumWidth = 6;
            this.TT_Tra.Name = "TT_Tra";
            this.TT_Tra.Width = 125;
            // 
            // labelNgay_Text
            // 
            this.labelNgay_Text.AutoSize = true;
            this.labelNgay_Text.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay_Text.Location = new System.Drawing.Point(472, 203);
            this.labelNgay_Text.MaximumSize = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.MinimumSize = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.Name = "labelNgay_Text";
            this.labelNgay_Text.Size = new System.Drawing.Size(138, 25);
            this.labelNgay_Text.TabIndex = 94;
            this.labelNgay_Text.Text = "22/04/1999";
            this.labelNgay_Text.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelNgay
            // 
            this.labelNgay.AutoSize = true;
            this.labelNgay.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelNgay.ForeColor = System.Drawing.Color.DarkRed;
            this.labelNgay.Location = new System.Drawing.Point(339, 203);
            this.labelNgay.Name = "labelNgay";
            this.labelNgay.Size = new System.Drawing.Size(102, 25);
            this.labelNgay.TabIndex = 93;
            this.labelNgay.Text = "Ngày lập:";
            // 
            // buttonIn
            // 
            this.buttonIn.BackColor = System.Drawing.Color.Red;
            this.buttonIn.Enabled = false;
            this.buttonIn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonIn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonIn.Location = new System.Drawing.Point(324, 834);
            this.buttonIn.Name = "buttonIn";
            this.buttonIn.Size = new System.Drawing.Size(143, 41);
            this.buttonIn.TabIndex = 95;
            this.buttonIn.Text = "In";
            this.buttonIn.UseVisualStyleBackColor = false;
            this.buttonIn.Click += new System.EventHandler(this.buttonIn_Click);
            // 
            // buttonLuuToa
            // 
            this.buttonLuuToa.BackColor = System.Drawing.Color.Red;
            this.buttonLuuToa.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.buttonLuuToa.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonLuuToa.Location = new System.Drawing.Point(175, 834);
            this.buttonLuuToa.Name = "buttonLuuToa";
            this.buttonLuuToa.Size = new System.Drawing.Size(143, 41);
            this.buttonLuuToa.TabIndex = 96;
            this.buttonLuuToa.Text = "Lưu toa";
            this.buttonLuuToa.UseVisualStyleBackColor = false;
            this.buttonLuuToa.Click += new System.EventHandler(this.buttonLuuToa_Click);
            // 
            // columnHeaderTenSP
            // 
            this.columnHeaderTenSP.Text = "Tên sản phẩm";
            this.columnHeaderTenSP.Width = 199;
            // 
            // columnHeaderSoLuong
            // 
            this.columnHeaderSoLuong.Text = "SL";
            this.columnHeaderSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderSoLuong.Width = 50;
            // 
            // columnHeaderDonGia
            // 
            this.columnHeaderDonGia.Text = "Đơn giá";
            this.columnHeaderDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderDonGia.Width = 100;
            // 
            // columnHeaderThanhTien
            // 
            this.columnHeaderThanhTien.Text = "Thành tiền";
            this.columnHeaderThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeaderThanhTien.Width = 100;
            // 
            // listViewMuaHang
            // 
            this.listViewMuaHang.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewMuaHang.BackColor = System.Drawing.Color.Khaki;
            this.listViewMuaHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewMuaHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTenSP,
            this.columnHeaderSoLuong,
            this.columnHeaderDonGia,
            this.columnHeaderThanhTien});
            this.listViewMuaHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.listViewMuaHang.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listViewMuaHang.HideSelection = false;
            this.listViewMuaHang.HoverSelection = true;
            this.listViewMuaHang.Location = new System.Drawing.Point(11, 374);
            this.listViewMuaHang.MultiSelect = false;
            this.listViewMuaHang.Name = "listViewMuaHang";
            this.listViewMuaHang.Size = new System.Drawing.Size(599, 231);
            this.listViewMuaHang.TabIndex = 51;
            this.listViewMuaHang.UseCompatibleStateImageBehavior = false;
            this.listViewMuaHang.View = System.Windows.Forms.View.Details;
            // 
            // panelTrai
            // 
            this.panelTrai.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelTrai.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTrai.Location = new System.Drawing.Point(0, 35);
            this.panelTrai.Name = "panelTrai";
            this.panelTrai.Size = new System.Drawing.Size(6, 850);
            this.panelTrai.TabIndex = 97;
            // 
            // panelPhai
            // 
            this.panelPhai.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelPhai.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelPhai.Location = new System.Drawing.Point(614, 35);
            this.panelPhai.Name = "panelPhai";
            this.panelPhai.Size = new System.Drawing.Size(6, 850);
            this.panelPhai.TabIndex = 98;
            // 
            // panelDuoi
            // 
            this.panelDuoi.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelDuoi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDuoi.Location = new System.Drawing.Point(6, 879);
            this.panelDuoi.Name = "panelDuoi";
            this.panelDuoi.Size = new System.Drawing.Size(608, 6);
            this.panelDuoi.TabIndex = 99;
            // 
            // formXacNhanToa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(620, 885);
            this.Controls.Add(this.panelDuoi);
            this.Controls.Add(this.panelPhai);
            this.Controls.Add(this.panelTrai);
            this.Controls.Add(this.buttonLuuToa);
            this.Controls.Add(this.buttonIn);
            this.Controls.Add(this.labelNgay_Text);
            this.Controls.Add(this.labelNgay);
            this.Controls.Add(this.labelSLSanPham);
            this.Controls.Add(this.labelSDT_Text);
            this.Controls.Add(this.labelSDT);
            this.Controls.Add(this.labelTenKhach_Text);
            this.Controls.Add(this.labelTenKhach);
            this.Controls.Add(this.labelKhachNo_Text);
            this.Controls.Add(this.labelThanhToan_Text);
            this.Controls.Add(this.labelSLSanPham_Text);
            this.Controls.Add(this.labelNhanVienLapToa_Text);
            this.Controls.Add(this.labelTongToaHang_Text);
            this.Controls.Add(this.labelThanhToan);
            this.Controls.Add(this.labelKhachNo);
            this.Controls.Add(this.labelNhanVienLapToa);
            this.Controls.Add(this.labelTongToaHang);
            this.Controls.Add(this.labelTongTra_Text);
            this.Controls.Add(this.labelTongMua_Text);
            this.Controls.Add(this.labelTongTra);
            this.Controls.Add(this.labelTongMua);
            this.Controls.Add(this.listViewTraHang);
            this.Controls.Add(this.buttonKetToa);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelChuSap);
            this.Controls.Add(this.labelDiaChiNH2);
            this.Controls.Add(this.labelDiaChiNH1);
            this.Controls.Add(this.labelSTK);
            this.Controls.Add(this.listViewMuaHang);
            this.Controls.Add(this.labelAnDong);
            this.Controls.Add(this.labelSDT2);
            this.Controls.Add(this.labelSDT1);
            this.Controls.Add(this.labelDiaChi);
            this.Controls.Add(this.labelTenSap);
            this.Controls.Add(this.panelThanhTieuDe);
            this.Controls.Add(this.dataGridViewTra);
            this.Controls.Add(this.dataGridViewMua);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formXacNhanToa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TOA";
            this.panelThanhTieuDe.ResumeLayout(false);
            this.panelThanhTieuDe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIconThanhTieuDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelThanhTieuDe;
        private System.Windows.Forms.Button buttonAn;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Label labelAnDong;
        private System.Windows.Forms.Label labelSDT1;
        private System.Windows.Forms.Label labelDiaChi;
        private System.Windows.Forms.Label labelTenSap;
        private System.Windows.Forms.Label labelSDT2;
        private System.Windows.Forms.Label labelSTK;
        private System.Windows.Forms.Label labelDiaChiNH1;
        private System.Windows.Forms.Label labelDiaChiNH2;
        private System.Windows.Forms.Label labelChuSap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonKetToa;
        private System.Windows.Forms.PictureBox pictureBoxIconThanhTieuDe;
        private System.Windows.Forms.ListView listViewTraHang;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label labelTongMua;
        private System.Windows.Forms.Label labelTongTra;
        private System.Windows.Forms.Label labelTongMua_Text;
        private System.Windows.Forms.Label labelTongTra_Text;
        private System.Windows.Forms.Label labelKhachNo_Text;
        private System.Windows.Forms.Label labelThanhToan_Text;
        private System.Windows.Forms.Label labelSLSanPham_Text;
        private System.Windows.Forms.Label labelNhanVienLapToa_Text;
        private System.Windows.Forms.Label labelTongToaHang_Text;
        private System.Windows.Forms.Label labelThanhToan;
        private System.Windows.Forms.Label labelNhanVienLapToa;
        private System.Windows.Forms.Label labelSLSanPham;
        private System.Windows.Forms.Label labelTongToaHang;
        private System.Windows.Forms.Label labelKhachNo;
        private System.Windows.Forms.Label labelTenKhach_Text;
        private System.Windows.Forms.Label labelTenKhach;
        private System.Windows.Forms.Label labelSDT;
        private System.Windows.Forms.Label labelSDT_Text;
        private System.Windows.Forms.Label labelTieuDeForm;
        private System.Windows.Forms.DataGridView dataGridViewMua;
        private System.Windows.Forms.DataGridView dataGridViewTra;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenSP_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSL_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDonGia_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTT_Mua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTenSP_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSL_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn DG_Tra;
        private System.Windows.Forms.DataGridViewTextBoxColumn TT_Tra;
        private System.Windows.Forms.Label labelNgay_Text;
        private System.Windows.Forms.Label labelNgay;
        private System.Windows.Forms.Button buttonIn;
        private System.Windows.Forms.Button buttonLuuToa;
        private System.Windows.Forms.ColumnHeader columnHeaderTenSP;
        private System.Windows.Forms.ColumnHeader columnHeaderSoLuong;
        private System.Windows.Forms.ColumnHeader columnHeaderDonGia;
        private System.Windows.Forms.ColumnHeader columnHeaderThanhTien;
        private System.Windows.Forms.ListView listViewMuaHang;
        private System.Windows.Forms.Panel panelTrai;
        private System.Windows.Forms.Panel panelPhai;
        private System.Windows.Forms.Panel panelDuoi;
    }
}